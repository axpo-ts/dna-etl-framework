SELECT "{pass_value}";  -- noqa
