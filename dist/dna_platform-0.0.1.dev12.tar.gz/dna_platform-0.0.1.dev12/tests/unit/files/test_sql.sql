SELECT
    id AS _id,
    1 AS test_col
FROM test
