SELECT id AS _id, 1 AS $col FROM $table
