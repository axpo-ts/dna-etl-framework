SELECT * FROM {source_table_name};  -- noqa
