from data_platform.data_model.bronze.jao.auction import auction_table
from data_platform.data_model.bronze.jao.bids import bids_table
