# CPD-OFF - duplication of this class into a notebook is deliberate
import time
from collections.abc import Callable
from typing import ClassVar

from data_platform.common import Task
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.ingestion.ingestion import (
    GetTimeBlocksTask,
    RewriteJsonFileFromIndexToRecordsTask,
    SetDatabricksParameterTask,
    SetDeltaLoadParametersBulkTask,
)
from data_platform.tasks.reader.api.http.databricks_lpi import DatabricksGroupManager
from data_platform.tasks.reader.api.http.mdlm import MdlmApiReaderTask
from data_platform.tasks.reader.api.http.mds import MdsBearerApiBulkReaderWriterTask
from data_platform.tasks.reader.api.http.meteomatics import MeteomaticsApiReaderTask
from data_platform.tasks.reader.api.http.orca import (
    OrcaBearerApiReaderTask,
)
from data_platform.tasks.reader.api.http.request_reader import RequestsApiReaderTask
from data_platform.tasks.reader.api.http.tennet import TennetMeritOrderApiReaderTask, TennetMeritOrderIterateApiTask
from data_platform.tasks.reader.file import SimpleBatchFileReaderTask, SimpleStreamingFileReaderTask
from data_platform.tasks.reader.sql import SimpleBatchWatermarkReaderTask, SimpleSQLTableReaderTask
from data_platform.tasks.reader.table import (
    SimpleBatchReaderTask,
    SimpleStreamingTableReaderTask,
    SimpleTableReaderTask,
)
from data_platform.tasks.reference.reference_mapping import (
    ApplyReferenceMappingTask,
)
from data_platform.tasks.schema.schema import CreateSchemaCommentsTask, CreateSchemaTask
from data_platform.tasks.schema.table.column.column import (
    CreateColumnCommentsTask,
    CreateColumnTagsTask,
)
from data_platform.tasks.schema.table.table import (
    CreateMetadataTableTask,
    CreateTableCommentTask,
    CreateTableFromDataFrameTask,
    CreateTableTagsTask,
    CreateTableTask,
)
from data_platform.tasks.schema.volume.volume import CreateVolumeTask
from data_platform.tasks.secrets.secrets import GetSecretTask
from data_platform.tasks.transform.apply_pyspark import ApplyPysparkTask
from data_platform.tasks.transform.apply_sql import ApplySQLTask
from data_platform.tasks.transform.dataframe import (
    IncrementalTablesReaderTask,
    JoinDataFrameTask,
    UnionByNameDataFrameTask,
)
from data_platform.tasks.writer.sql import BatchSQLWriterTask, StreamingSQLWriterTask
from data_platform.tasks.writer.table import (
    CloneTableTask,
    SelectiveOverwriteTask,
    SimpleBatchUpsertChangesTask,
    SimpleBatchWriterTask,
    SimpleStreamingUpsertChangesTask,
    SimpleStreamingWriterTask,
    SimpleType2MergeTask,
)
from data_platform.tasks.writer.volume.volume import (
    JsonToVolumeWriterTask,
    ObjectToVolumeWriterTask,
    ZipCSVObjectToVolumeWriterTask,
)

TASKS = [
    SimpleStreamingWriterTask,
    SimpleBatchWriterTask,
    SimpleStreamingFileReaderTask,
    SimpleStreamingTableReaderTask,
    SimpleBatchReaderTask,
    SimpleBatchFileReaderTask,
    StreamingSQLWriterTask,
    BatchSQLWriterTask,
    CreateSchemaTask,
    CreateSchemaCommentsTask,
    CreateMetadataTableTask,
    ApplySQLTask,
    CloneTableTask,
    RequestsApiReaderTask,
    SimpleTableReaderTask,
    SimpleSQLTableReaderTask,
    MdsBearerApiBulkReaderWriterTask,
    CreateVolumeTask,
    GetSecretTask,
    CreateTableTask,
    CreateColumnCommentsTask,
    CreateColumnTagsTask,
    GetTimeBlocksTask,
    SelectiveOverwriteTask,
    SetDatabricksParameterTask,
    JsonToVolumeWriterTask,
    ObjectToVolumeWriterTask,
    MeteomaticsApiReaderTask,
    OrcaBearerApiReaderTask,
    ApplyPysparkTask,
    JoinDataFrameTask,
    UnionByNameDataFrameTask,
    SimpleBatchUpsertChangesTask,
    SimpleStreamingUpsertChangesTask,
    CreateTableFromDataFrameTask,
    RewriteJsonFileFromIndexToRecordsTask,
    SimpleBatchWatermarkReaderTask,
    ZipCSVObjectToVolumeWriterTask,
    SetDeltaLoadParametersBulkTask,
    CreateTableCommentTask,
    CreateTableTagsTask,
    MdlmApiReaderTask,
    DatabricksGroupManager,
    SimpleType2MergeTask,
    ApplyReferenceMappingTask,
    TennetMeritOrderApiReaderTask,
    TennetMeritOrderIterateApiTask,
    IncrementalTablesReaderTask,
]


def build_task(task_conf: Configuration, rank: str) -> tuple[ETLTask, Configuration]:
    """Build a task and its configuration based on the task configuration and rank.

    Parameters:
        task_conf (Configuration): The task configuration.
        rank (str): The rank or identifier for the task.

    Returns:
        Tuple[Task, Configuration]: A tuple containing the task instance and its configuration.
    """
    task_name = task_conf.get_string("task_name")
    if not task_name:
        raise NotImplementedError("Task name %s has not been implemented", task_name)
    task_class = TaskRegistry.tasks.get(task_name)
    if not task_class:
        raise KeyError(f"Task is not defined: {task_name}")
    task: ETLTask = task_class()
    task.id = rank
    return task, task_conf


def build_tasks(tasks_conf: Configuration) -> list[tuple[ETLTask, Configuration]]:
    """Build a list of tasks and their configurations based on the input tasks configuration.

    Parameters:
        tasks_conf (Configuration): The tasks configuration.

    Returns:
        List[Tuple[Task, Configuration]]: A list of tuples containing task instances and their configurations.
    """
    tasks_conf = Configuration({str(rank): value for rank, value in tasks_conf.as_dict().items()})
    TaskRegistry.init_tasks()
    return list(build_task(tasks_conf.get_tree(rank), rank) for rank in sorted(tasks_conf.as_dict().keys()))


class TaskRegistry:
    """Registry for available tasks.

    This class serves as a registry for available tasks, allowing them to be looked up by their task name.
    """

    tasks: ClassVar[dict[str, Callable]] = {}

    @classmethod
    def init_tasks(cls) -> None:
        """Initialize the task registry with available tasks.

        This method initializes the task registry by populating it with available task classes.
        """
        if not cls.tasks:
            cls.tasks = {task.task_name: task for task in TASKS}


class TaskRunnerError(Exception):
    """Task Runner exception.

    A class to handle different types of exceptions that may occur in the task runner execution
    """


def run_task(task_with_config: tuple[ETLTask, Configuration], task_context: TaskContext) -> None:
    """Execute a task with its configuration within the provided task context.

    Parameters:
        task_with_config (Tuple[Task, Configuration]): A tuple containing a task instance and its configuration.
        task_context (TaskContext): The task context in which the task should be executed.
    """
    (task, task_configuration) = task_with_config
    try:
        task.execute(context=task_context, conf=task_configuration)  # type: ignore[attr-defined]
    except Exception as e:
        raise TaskRunnerError("error on ETL task") from e


def execute(tasks: list[tuple[ETLTask, Configuration]], task_context: TaskContext) -> None:
    """Execute a list of tasks with their configurations within the provided task context.

    Parameters:
        tasks (List[Tuple[Task, Configuration]]): A list of tuples containing task instances and their configurations.
        task_context (TaskContext): The task context in which the tasks should be executed.
    """
    for task in tasks:
        run_task(task, task_context)


class TaskRunner(Task):
    """Task Runner for executing a sequence of tasks.

    This class represents a Task Runner that can execute a sequence of tasks defined in a configuration.

    Examples of tasks it can run:
    - SimpleStreamingWriterTask: Writes streaming data to a table in a specified destination in the datalake
    - SimpleBatchWriterTask: Writes batch data to a table in a specified destination in the datalake.
    - SimpleStreamingTableReaderTask: Reads streaming data from a data source.
    - SimpleBatchReaderTask: Reads batch data from a data source, enforcing a schema, usually reading bronze and so on.
    - SimpleBatchFileReaderTask: Reads batch data from a file, not enforcing a schema, usually for ingesting raw data.

    """

    def launch(self) -> None:
        """Launch the Task Runner.

        This method launches the Task Runner and executes a sequence of tasks based on the provided configuration.
        """
        self.logger.info("Starting Task Runner")
        start_time = time.time()
        tasks_conf = Configuration(self.conf["tasks"])
        self.logger.info(tasks_conf.as_dict())
        tasks = build_tasks(tasks_conf)
        context = TaskContext(configuration=tasks_conf, spark=self.spark, logger=self._prepare_logger())
        self.logger.info(f"Start time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(start_time))}")
        execute(tasks=tasks, task_context=context)
        end_time = time.time()
        self.logger.info(f"End time: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(end_time))}")
        execution_time = end_time - start_time
        self.logger.info(f"Execution time: {execution_time} seconds")


def entrypoint() -> None:  # pragma: no cover
    """Launch the Task Runner.

    This method launches the Task Runner and executes a sequence of tasks based on the provided configuration.
    """
    task = TaskRunner()
    task.launch()


if __name__ == "__main__":
    entrypoint()

# CPD-ON - duplication of this class into a notebook is deliberate
