# data_platform/etl/extract/http/volue_ems.py
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

from data_platform.etl.extract.http.async_http_api_client import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin


@dataclass(kw_only=True)
class VolueEmsApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Volue EMS API client for fetching production data."""

    context: Any
    credentials: Any

    start: datetime
    end: datetime

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url: str = "https://ems.energymarketservices.volue.com/ExternalData/DataGroups"
    task_name: str = field(init=False, default="EmsApiClient")

    def __post_init__(self) -> None:
        """Postinit."""
        super().__post_init__()
        self._register_endpoints()

    @staticmethod
    def _get_intervals(start: datetime, end: datetime, days_per_chunk: int) -> list[tuple[datetime, datetime]]:
        if days_per_chunk < 1:
            raise ValueError("days_per_chunk must be at least 1")

        intervals: list[tuple[datetime, datetime]] = []
        s = start
        delta = timedelta(days=days_per_chunk)

        while s < end:
            e = min(s + delta, end)
            intervals.append((s, e))
            s = e

        return intervals

    def _register_endpoints(self) -> None:
        self._endpoints = {
            "data_groups": EndpointDescriptor(
                url=f"{self._base_url}",
                build_param_chunks=lambda: [""],
                build_params=lambda chunk: {},
            )
        }

    def _register_data_group_endpoints(self, data_groups: list[str]) -> None:
        for dg in data_groups:
            self._endpoints[dg] = EndpointDescriptor(
                url=f"{self._base_url}/{dg}",
                build_param_chunks=lambda start=self.start, end=self.end: self._get_intervals(start, end, 1),
                build_params=lambda chunk: {
                    "start": chunk[0].strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "end": chunk[1].strftime("%Y-%m-%dT%H:%M:%SZ"),
                },
            )

    def get_data_groups(self, **ovr: Any) -> Any:
        """Fetch all data groups."""
        result = self._execute_endpoint("data_groups", **ovr)[0]
        self._collected_responses = []
        self._register_data_group_endpoints(result)
        return result

    def get_data(self, data_group: str, **ovr: Any) -> Any:
        """Fetch requested data for a specific data group."""
        result = self._execute_endpoint(data_group, **ovr)
        self._collected_responses = []
        return result
