from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import requests

from data_platform.etl.auth.certificate_utils import (
    CertificatePair,
    cleanup_temp_files,
    create_temp_certificate_files,
    parse_pem_certificate,
)
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin
from data_platform.etl.extract.http.sync_http_api_client import SyncHttpApiClient


@dataclass(kw_only=True)
class RteApiClient(SyncHttpApiClient, EndpointExecutorMixin):
    """RTE API client for fetching data using client certificates."""

    context: Any
    file_volume: Any
    # secret_scope: str
    # cert_secret_key: str
    rte_certs: Any
    base_url: str = "https://digital.iservices.rte-france.com/pki"
    month: str = "2025-03"
    eic_code: str = "12XEGL-H-------0"

    _cert_pair: CertificatePair = field(init=False, repr=False)
    _cert_file_path: str = field(init=False, default="", repr=False)
    _key_file_path: str = field(init=False, default="", repr=False)
    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    task_name: str = field(init=False, default="RteApiClient")

    def __post_init__(self) -> None:
        """Initialize the RTE API client."""
        super().__post_init__()
        self._setup_certificates()
        self._register_endpoints()

    def _setup_certificates(self) -> None:
        """Retrieve certificates from key vault and create temporary files."""
        try:
            # Get certificate content from Databricks secrets
            cert_content = self.rte_certs.get_certificate()

            # Parse the certificate content using our utility
            self._cert_pair = parse_pem_certificate(cert_content)

            # Create temporary files for the certificate and key
            self._cert_file_path, self._key_file_path = create_temp_certificate_files(self._cert_pair)

            self.context.logger.info("Successfully retrieved and parsed certificates from key vault")

        except Exception as e:
            self.context.logger.error(f"Failed to setup certificates: {e}")
            raise

    def _register_endpoints(self) -> None:
        """Register endpoints for RTE API calls."""
        self._endpoints = {
            "afrr_energy_activation_invoicing": EndpointDescriptor(
                url=f"{self.base_url}/aFRR_reserve/v1/activated_aFRR_per_entity",
                overrides={"params": {"month": self.month, "eic_code": self.eic_code}},
                get_file_name=lambda chunk: f"/afrr_energy_activation_invoicing_{chunk.get('month', self.month)}.json",
            ),
            "afrr_fcr_invoicing": EndpointDescriptor(
                url=f"{self.base_url}/FCR_aFRR_monthly_data/v1/valorisation",
                overrides={"params": {"month": self.month, "eic_code": self.eic_code}},
                get_file_name=lambda chunk: f"/afrr_fcr_invoicing_{chunk.get('month', self.month)}.json",
            ),
        }

    def _do_request(self, *, params: dict[str, Any] | None, payload: dict[str, Any] | None = None) -> Any:
        """Override the base request method to use client certificates."""
        try:
            # Use the endpoint_url set by the endpoint executor
            url = self.endpoint_url

            # Log the request details for debugging
            self.context.logger.info(f"Making request to: {url}")
            self.context.logger.info(f"Request parameters: {params}")

            # Make request with client certificate using the temporary files
            response = requests.get(
                url,
                cert=(self._cert_file_path, self._key_file_path),
                params=params,
                timeout=self.timeout_sec,
                verify=self.verify,
            )

            # Check response status
            if response.status_code == 200:
                self.context.logger.info(f"Request successful: {url}")
                return response
            else:
                self.context.logger.error(f"Request failed with status {response.status_code}: {response.text}")
                response.raise_for_status()

        except Exception as e:
            self.context.logger.error(f"Request failed: {e}")
            raise

    def get_afrr_energy_activation_invoicing(self, **ovr: Any) -> Any:
        """Fetch aFRR energy activation invoicing data."""
        return self._execute_endpoint("afrr_energy_activation_invoicing", **ovr)

    def get_afrr_fcr_invoicing(self, **ovr: Any) -> Any:
        """Fetch aFRR FCR invoicing data."""
        return self._execute_endpoint("afrr_fcr_invoicing", **ovr)

    def get_file_name(self, chunk: Any | None = None) -> str:
        """Override to resolve method signature conflict."""
        return super().get_file_name(chunk)

    def handle_response(self, response_data: Any, chunk: Any | None = None) -> Any:
        """Override to resolve method signature conflict."""
        return super().handle_response(response_data, chunk=chunk)

    def __del__(self) -> None:
        """Clean up temporary certificate files."""
        try:
            cleanup_temp_files(self._cert_file_path, self._key_file_path)
        except Exception:
            pass  # Ignore cleanup errors
