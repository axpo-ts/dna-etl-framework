from __future__ import annotations

import json
import time
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any, Protocol, runtime_checkable

from data_platform.data_model import FileVolumeIdentifier
from data_platform.etl.auth.oauth import BaseOauth
from data_platform.etl.auth.token_provider import TokenProvider
from data_platform.etl.core import TaskContext
from data_platform.etl.core.retry import RetryConfig, wrapper_retry
from data_platform.etl.etl_task import ETLTask

"""Unified API reader module - **duplication-free configuration**."""


@runtime_checkable
class _HttpResponseLike(Protocol):
    """Subset of *httpx.Response* attributes used by the readers."""

    def json(self) -> Any: ...

    @property  # type: ignore[override]
    def text(self) -> str: ...

    @property  # type: ignore[override]
    def content(self) -> bytes: ...

    def raise_for_status(self) -> None: ...


type HttpResponse = _HttpResponseLike

################################################################################
# Base reader (sync / async agnostic)
################################################################################


@dataclass(slots=True)
class BaseHttpApiClient(ETLTask):
    """Shared functionality for HTTP reader tasks.

    Args:
        context: Orchestrator context (logger, metrics, Spark, ...).
        endpoint_url: Fully-qualified API endpoint. Mandatory.
        headers: Optional static headers applied to **all** requests.
        credentials: OAuth credentials dataclass (Basic or Azure). ``None``
            means *unauthenticated* requests.
        watermark_number_of_days: Historical look-back window (default 7).
        response_content_type: *"json"* | *"text"* | *"content"*.
        timeout_sec: Total request timeout (connect + read) in seconds.
        retry_*: Tenacity retry configuration knobs.
        max_workers: Concurrency limit for the async reader.
    """

    # -- end-user knobs ---------------------------------------------------------
    context: TaskContext
    endpoint_url: str = None  # Fully qualified URL to the API endpoint
    params: dict[str, Any] | None = None
    headers: dict[str, str] | None = None
    credentials: TokenProvider | None = None  # credentials from auth providers
    datetime_window: tuple[datetime, datetime] | None = None
    chunk_size_days: int = -1  # if chunking applies the response will be a list
    lookback: timedelta = timedelta()  # value to subtract from the start date
    lookahead: timedelta = timedelta(days=1)  # value to add to the end date
    datetime_name_params: tuple[str, str] | None = None  # (from, to) parameter names
    response_content_type: str = "json"  # "json" | "text" | "content"
    retry_cfg: RetryConfig = field(default_factory=RetryConfig)  # retry configuration
    verify: bool = True  # TLS validation
    timeout_sec: float = 10.0  # HTTP request timeout
    raise_exception: bool = True  # raise on failed chunks
    file_volume: str | FileVolumeIdentifier | None = None  # Used to identify the volume path
    full_load: bool = False  # If True, use now as end date, start from window start
    min_start_datetime: datetime | None = None  # Used to clamp the start date
    max_end_datetime: datetime | None = None  # Used to clamp the end date
    # -- polling knobs ----------------------------------------------------------
    poll_on_empty: bool = False
    poll_interval_sec: float = 30.0  # wait between empty responses
    poll_timeout_sec: float = 300.0  # overall max time per request

    # -- internal state (NOT init kwargs) --------------------------------------
    _failed_chunks: list[Any] = field(init=False, default_factory=list)
    _access_token: str | None = field(init=False, default=None)
    _window_start: datetime | None = field(init=False, default=None)
    _window_end: datetime | None = field(init=False, default=None)
    _window_needs_update: bool = field(init=False, default=True)  # ⇒ date window cache is stale; recompute before using
    _response_kind: str = field(init=False)
    _collected_responses: list[Any] = field(init=False, default_factory=list)

    task_name: str = field(init=False, default="BaseHttpApiClient")

    # -------------------------------------------------------------------------
    # post-init setup
    # -------------------------------------------------------------------------
    def __post_init__(self) -> None:
        """Post-initialization setup for BaseHttpApiClient."""
        self._access_token = None
        self.headers = self.headers or {}
        self.params = self.params or {}
        self._window_needs_update = True  # flag to make the calculation of the window lazy

        # TODO This doesn't work
        if self.full_load and self.poll_on_empty:
            self.context.logger.warning(
                "full_load=True and poll_on_empty=True is not allowed. Turning off poll_on_empty."
            )
            self.poll_on_empty = False
        # OAuth ---------------------------------------------------------------
        if self.credentials:
            if isinstance(self.credentials, BaseOauth):
                self._setup_oauth(self.credentials)

    def _ensure_window(self) -> None:
        """Rebuild the window if it is marked dirty."""
        if not self._window_needs_update:
            return

        self._init_window(
            datetime_name_params=self.datetime_name_params,
            datetime_window=self.datetime_window,
            lookback=self.lookback,
            lookahead=self.lookahead,
        )
        self._window_needs_update = False

    def _init_window(
        self,
        *,
        datetime_name_params: tuple[str, str] | None,
        datetime_window: tuple[datetime | date | str, datetime | date | str] | None,
        lookback: timedelta,
        lookahead: timedelta,
    ) -> None:
        """Priority order.

        -------------
        1. *datetime_window* argument
        2. Two matching keys already present in self.params
        3. Fallback on (now-lookback, now+lookahead)
        """
        # TODO - review if not set datetime_name_params not set what happens?
        if not datetime_name_params:
            self._window_start = self._window_end = None
            return

        self._datetime_params_from, self._datetime_params_to = datetime_name_params

        raw_window = datetime_window or (
            self.params.get(self._datetime_params_from),
            self.params.get(self._datetime_params_to),
        )

        self._window_start, self._window_end = self._resolve_window(
            window_start_end=raw_window,
            lookback=lookback,
            lookahead=lookahead,
        )

    # ------------------------------------------------------------------
    # OAuth helpers
    # ------------------------------------------------------------------
    def _setup_oauth(self, creds: BaseOauth) -> None:
        """Fetch / reuse token and set *Authorization* header."""
        if not self._access_token:
            self._access_token = creds.fetch_token(timeout=self.timeout_sec)
        self.headers["Authorization"] = f"Bearer {self._access_token}"

    @property
    def _volume_path(self) -> str:
        """Return the volume path for the chunk.

        Args:
            path (str): The base path for the volume.
            chunk (Any): The chunk for which data was fetched.

        Returns:
            str: The full volume path.
        """
        if not self.file_volume:
            raise ValueError("file_volume must be set to determine the volume path")

        if isinstance(self.file_volume, FileVolumeIdentifier):
            return self._full_base_source_filename_of(self.file_volume)

    @property
    def retry(self) -> Any:
        """Return a per-instance *tenacity* retry wrapper."""
        return wrapper_retry(self.retry_cfg)

    def _ensure_valid_token(self) -> None:
        """Make sure the Authorization header contains a *currently-valid*.

        bearer token. If the cached token is about to expire, fetch_token()
        will transparently refresh it.
        """
        if not isinstance(self.credentials, BaseOauth):
            return

        token = self.credentials.fetch_token(timeout=self.timeout_sec, verify=self.verify)
        if token != self._access_token:
            self._access_token = token
            self.headers["Authorization"] = f"Bearer {token}"

            # if the subclass already created a Client / AsyncClient, keep it in sync
            try:
                self._session.headers["Authorization"] = f"Bearer {token}"
            except AttributeError:
                pass

    # ------------------------------------------------------------------
    # Overridable hooks
    # ------------------------------------------------------------------
    @staticmethod
    def _to_datetime(x: datetime | date | str) -> datetime:
        """Return *x* as a datetime (date → midnight)."""
        if isinstance(x, datetime):
            return x
        if isinstance(x, date):
            return datetime.combine(x, time.min)
        if isinstance(x, str):
            try:
                # Assume ISO 8601 format (YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS)
                return datetime.fromisoformat(x) if x else None
            except ValueError as exc:
                raise ValueError(f"String '{x}' is not a valid ISO-8601 date or datetime") from exc

        raise TypeError(f"window elements must be datetime, date, or ISO string; {type(x).__name__}")

    def _validate_window(self, start: datetime, end: datetime) -> None:
        """Validation.

        ──────────
        1. start ≤ end
        2. Window inside [min_start_datetime, max_end_datetime] whenever those are provided.
        """
        if start > end:
            raise ValueError(f"{self._datetime_params_from}: {start} is after {self._datetime_params_to}: {end}")

        if self.min_start_datetime and start < self.min_start_datetime:
            raise ValueError(f"Window start {start} is before min_start_datetime {self.min_start_datetime}")

        if self.max_end_datetime and end > self.max_end_datetime:
            raise ValueError(f"Window end {end} is after max_end_datetime {self.max_end_datetime}")

    def _resolve_window(
        self,
        *,
        window_start_end: tuple[datetime | date, datetime | date] | None,
        lookback: timedelta,
        lookahead: timedelta,
    ) -> tuple[
        datetime, datetime
    ]:  # Figure it out what to do based on min_start_datetime, max_end_datetime, and full_load.
        """Return the effective (start, end) datetime window.

        Decision grid (highest precedence first)
        ----------
        1. full_load=True ─► min/max bounds override each side independently
                          └► missing *end* ⇒ now + lookahead

        2. full_load=False ─► both start & end passed → return them
                           └► otherwise fallback  → (now-wm, now+lookahead)

        """
        now = datetime.now()

        # --- 0. normalise user inputs ---------------------------------- #
        raw_start, raw_end = window_start_end or (None, None)
        start = self._to_datetime(raw_start)
        end = self._to_datetime(raw_end)

        # --- 1. full-load branch --------------------------------------- #
        if self.full_load:
            start = self.min_start_datetime or start
            end = self.max_end_datetime or end

            if start is None:
                raise ValueError(
                    f"full_load=True requires either '{self._datetime_params_from}' or 'min_start_datetime'"
                )
            if end is None:
                end = now + lookahead

        # --- 2. incremental branch ------------------------------------- #
        elif start is None or end is None:
            start = now - lookback
            end = now + lookahead

        self._validate_window(start, end)
        return start, end

    def _fmt_date(self, dt: datetime) -> str:
        """Return YYYY-MM-DD formatted date string."""
        return dt.strftime("%Y-%m-%d")

    # ------------------------------------------------------------------
    # Polling helpers (sync & async variants call the same predicate)
    # ------------------------------------------------------------------
    @staticmethod
    def _is_empty_payload(payload: Any) -> bool:
        """Heuristic - treat [], {}, '' or None as *no data*."""
        return payload in (None, "", [], {})

    def build_param_chunks(self) -> list[dict[str, Any]]:
        """Build one params-dict per chunk.

        Defines what to fetch

        Each dict merges:
          * the caller-supplied static `self.params`
          * the per-chunk date range under `self._date_param_from` /
            `self._date_param_to`.
        """
        # Lazily create the date window
        self._ensure_window()

        # 1️⃣ no explicit window → just return the static params
        if self._window_start is None or self._window_end is None:
            return [self.params or {}]  # no date range, return the params as is

        # 2️⃣ special flag: <1  ⇒  *one* chunk for the whole window
        if self.chunk_size_days < 1:
            p = deepcopy(self.params or {})
            p[self._datetime_params_from] = self._fmt_date(self._window_start)
            p[self._datetime_params_to] = self._fmt_date(self._window_end)
            return [p]

        # 3️⃣ normal chunking: split the window into chunks
        start, end = self._window_start, self._window_end  # always datetime

        chunks: list[dict[str, Any]] = []
        cursor = start

        while cursor < end:
            chunk_end = min(cursor + timedelta(days=self.chunk_size_days), end)

            p = deepcopy(self.params or {})  # keep user-supplied keys safe
            p[self._datetime_params_from] = self._fmt_date(cursor)
            p[self._datetime_params_to] = self._fmt_date(chunk_end)

            chunks.append(p)
            cursor = chunk_end

        return chunks

    def build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        """Defines how to talk to the endpoint for a specific endpoint."""
        return chunk

    def build_payload(self, chunk: dict[str, Any]) -> dict[str, Any]:
        """Build the payload."""
        return chunk

    def handle_response(self, response_data: Any, *, chunk: Any | None = None) -> Any:
        """Shape raw API payload into desired record (identity by default)."""
        return response_data

    def get_file_name(self, chunk: Any | None = None) -> str:
        """Return the file name for the chunk.

        Args:
            chunk (Any): The chunk for which data was fetched.

        Returns:
            str: The file name.
        """
        ...

    def _save(self, response_data: Any, *, chunk: Any | None = None) -> None:
        """Write the fetched data to a volume or collect it for return.

        Args:
            response_data (Any): The fetched data.
            chunk (Any): The chunk for which data was fetched.
        """
        if self.file_volume is not None:
            volume_path = self._volume_path
            file_name = self.get_file_name(chunk=chunk)
            self.context.dbutils.fs.mkdirs(volume_path)
            full_path = volume_path + file_name
            self.context.dbutils.fs.put(full_path, json.dumps(response_data), overwrite=True)
            self.context.logger.info(f"Data written successfully to file: {full_path}")
        else:
            # Collect responses for return when file_volume is not set
            self._collected_responses.append(response_data)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _extract_content(self, response: HttpResponse) -> Any:
        kind = self.response_content_type.lower()
        if kind == "text":
            return response.text
        if kind == "content":
            return response.content
        try:
            return response.json()
        except Exception as exc:  # pragma: no cover
            raise ValueError("Non-JSON response but 'json' response_content_type") from exc

    # ------------------------------------------------------------------
    # Abstract execute
    # ------------------------------------------------------------------

    def execute(self) -> None | list[Any] | Any:
        """Run the task (to be implemented by subclasses).

        Returns:
            - If ``file_volume`` is set (data are written to files):
                - self._collected_responses: None
                - Value returned: ``None``
                - Why: ``_save()`` stores on DBFS, so nothing is kept in memory.
            - If ``file_volume`` is not set and only one chunk:
                - self._collected_responses: ["payload"]
                - Value returneda: "payload"
                - Why: Helper unwraps the single element for convenience.
            - If ``file_volume`` is not set and chunking enabled:
                - self._collected_responses: ["payload-1", ...]
                - Value returned: ["payload-1", ...]
                - Why: One list chunk per chunk is appended to the result.
        """
        raise NotImplementedError
