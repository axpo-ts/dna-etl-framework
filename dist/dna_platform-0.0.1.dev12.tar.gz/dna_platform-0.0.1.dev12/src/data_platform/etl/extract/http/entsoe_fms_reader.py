from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any

import requests

from data_platform.etl.extract.http import SyncHttpApiClient


@dataclass(kw_only=True)
class EntsoeReader(SyncHttpApiClient):
    """ENTSO-E File Library API client for downloading CSV files from specific folders."""

    username: str
    password: str
    folder_path: str
    table_name: str
    full_load: bool = False
    page_size: int = 1  # Default: download only the latest file
    base_url: str = "https://fms.tp.entsoe.eu"
    auth_url: str = "https://keycloak.tp.entsoe.eu/realms/tp/protocol/openid-connect/token"
    volume: Any = None
    token_renew_margin_sec: int = 60

    _access_token: str | None = field(init=False, default=None)
    _files_info: dict[str, dict] = field(init=False, default_factory=dict)
    _request_count: int = field(init=False, default=0)
    _token_expiry_ts: float | None = field(init=False, default=None)
    task_name: str = field(init=False, default="EntsoeReader")

    def __post_init__(self) -> None:
        """Post-initialization to authenticate and set endpoints."""
        # Set rate limiting based on load type
        if self.full_load:
            self._request_delay = 1.0  # 1 seconds for full load (60 req/min)
            self._page_size = 10
            self.context.logger.info(f"Full load mode: page_size={self._page_size}, delay={self._request_delay}s")
        else:
            self._request_delay = 2.5  # 2.5 seconds for incremental (24 req/min)
            self._page_size = self.page_size
            self.context.logger.info(f"Incremental mode: page_size={self._page_size}, delay={self._request_delay}s")

        self.endpoint_url = f"{self.base_url}/listFolder"
        self.response_content_type = "json"
        self.http_method = "POST"
        self.file_volume = None

        super().__post_init__()
        self._authenticate()

    def _authenticate(self) -> None:
        """Get OAuth bearer token from ENTSO-E and record token lifetime.

        Uses Keycloak's expires_in (seconds) to compute a local refresh timestamp
        and updates Authorization header.
        """
        payload = {
            "client_id": "tp-fms-public",
            "grant_type": "password",
            "username": self.username,
            "password": self.password,
        }

        try:
            response = requests.post(self.auth_url, data=payload, timeout=30)
            response.raise_for_status()
            data = response.json()
            self._access_token = data.get("access_token")
            expires_in = data.get("expires_in")

            if not self._access_token:
                raise ValueError("Failed to obtain access token from ENTSO-E")

            # Compute proactive refresh time using monotonic clock
            if isinstance(expires_in, int) and expires_in > 0:
                refresh_in = max(1.0, float(expires_in) - float(self.token_renew_margin_sec))
                self._token_expiry_ts = time.monotonic() + refresh_in
                self.context.logger.info(
                    f"Authenticated to ENTSO-E. expires_in={expires_in}s, refreshing in ~{int(refresh_in)}s"
                )
            else:
                self._token_expiry_ts = None
                self.context.logger.info("Authenticated to ENTSO-E. expires_in not provided.")

            self.headers = self.headers or {}
            self.headers["Authorization"] = f"Bearer {self._access_token}"

        except Exception as e:
            self.context.logger.error(f"Authentication failed: {e}")
            raise

    def _ensure_valid_token(self) -> None:
        """Refresh the access token if the locally tracked expiry time has passed."""
        try:
            if self._token_expiry_ts is None:
                return
            if time.monotonic() >= self._token_expiry_ts:
                self.context.logger.info("Access token reached refresh threshold. Refreshing…")
                self._authenticate()
        except Exception as e:
            self.context.logger.error(f"Token refresh failed: {e}")
            raise

    def _apply_rate_limiting(self) -> None:
        """Apply rate limiting between API requests."""
        if self._request_count > 0:  # Skip delay for first request
            time.sleep(self._request_delay)
        self._request_count += 1

    def build_param_chunks(self) -> list[dict[str, Any]]:
        """Build parameter chunks - single chunk for incremental, multiple for full load."""
        if not self.full_load:
            return [{"page_index": 0}]

        # For full load, we'll determine pages dynamically in handle_response
        return [{"page_index": 0}]

    def build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        """Build parameters for ENTSO-E API request."""
        return {}

    def build_payload(self, chunk: dict[str, Any]) -> dict[str, Any]:
        """Build the JSON payload for listing files."""
        return {
            "path": self.folder_path,
            "sorterList": [{"key": "lastUpdatedTimestamp", "ascending": False}],  # Lastly updated files first
            "pageInfo": {"pageIndex": chunk["page_index"], "pageSize": self._page_size},
        }

    def handle_response(self, response_data: Any, *, chunk: dict | None = None) -> list[str]:
        """Process the file list response and download files."""
        try:
            if self.full_load:
                return self._handle_full_load_response(response_data, chunk)
            else:
                return self._handle_incremental_response(response_data)

        except Exception as e:
            self.context.logger.error(f"Failed to process file list response: {e}")
            raise

    def _handle_incremental_response(self, response_data: Any) -> list[str]:
        """Handle response for incremental load - download specified page_size files."""
        content_items = response_data.get("contentItemList", [])
        if not content_items:
            self.context.logger.warning(f"No files found in folder: {self.folder_path}")
            return []

        self.context.logger.info(f"Found {len(content_items)} files in folder")
        return self._download_files(content_items)

    def _handle_full_load_response(self, response_data: Any, chunk: dict) -> list[str]:
        """Handle response for full load - iterate through all pages."""
        all_downloaded_files = []
        current_page = chunk["page_index"]

        while True:
            # Apply rate limiting before each list request (except first)
            if current_page > 0:
                self._apply_rate_limiting()
                self._ensure_valid_token()

                # Make additional list request for next page
                payload = {
                    "path": self.folder_path,
                    "sorterList": [{"key": "lastUpdatedTimestamp", "ascending": False}],
                    "pageInfo": {"pageIndex": current_page, "pageSize": self._page_size},
                }

                headers = {"Authorization": f"Bearer {self._access_token}", "Content-Type": "application/json"}
                response = requests.post(self.endpoint_url, headers=headers, data=json.dumps(payload), timeout=60)
                response.raise_for_status()
                response_data = response.json()

            content_items = response_data.get("contentItemList", [])
            if not content_items:
                break

            self.context.logger.info(f"Processing page {current_page}: {len(content_items)} files")

            # Download files from current page
            downloaded_files = self._download_files(content_items)
            all_downloaded_files.extend(downloaded_files)

            # Check if we have more pages
            if len(content_items) < self._page_size:
                break  # Last page

            current_page += 1

        self.context.logger.info(f"Full load complete: {len(all_downloaded_files)} files downloaded")
        return all_downloaded_files

    def _download_files(self, content_items: list) -> list[str]:
        """Download files from content items list."""
        downloaded_files = []

        for item in content_items:
            filename = item.get("name")
            if not filename:
                continue

            self._files_info[filename] = {
                "size": item.get("size"),
                "originalSize": item.get("originalSize"),
                "lastUpdatedTimestamp": item.get("lastUpdatedTimestamp"),
            }

            try:
                csv_content = self._download_file(filename)
                self._save_csv_file(filename, csv_content)
                downloaded_files.append(filename)

            except Exception as e:
                self.context.logger.error(f"Failed to download {filename}: {e}")
                if self.raise_exception:
                    raise
                continue

        return downloaded_files

    def _download_file(self, filename: str) -> str:
        """Download a specific file using ENTSO-E API with rate limiting."""
        # Apply rate limiting before each download
        self._apply_rate_limiting()
        self._ensure_valid_token()

        url = f"{self.base_url}/downloadFileContent"
        file_info = self._files_info[filename]
        payload = {
            "folder": self.folder_path,
            "filename": filename,
            "lastUpdateTimestamp": file_info["lastUpdatedTimestamp"],
            "topLevelFolder": self.folder_path.split("/")[1]
            if self.folder_path.startswith("/")
            else self.folder_path.split("/")[0],
            "downloadAsZip": False,
        }

        headers = {"Authorization": f"Bearer {self._access_token}", "Content-Type": "application/json"}
        response = requests.post(url, headers=headers, data=json.dumps(payload), timeout=60)
        response.raise_for_status()

        self.context.logger.info(f"Downloaded {filename} ({len(response.text)} chars)")
        return response.text

    def _save_csv_file(self, filename: str, content: str) -> None:
        """Save CSV content to volume using the provided volume identifier."""
        if self.volume:
            # Use the provided volume identifier
            volume_path = self.context.full_file_name(self.volume)
        else:
            # Fallback to the old method for backward compatibility
            volume_catalog = f"{self.context.catalog_prefix}staging"
            volume_schema = f"{self.context.schema_prefix}entsoe"
            volume_path = f"/Volumes/{volume_catalog}/{volume_schema}/{self.table_name}"

        self.context.dbutils.fs.mkdirs(volume_path)

        if not volume_path.endswith("/"):
            volume_path += "/"

        # Use the original filename as-is from ENTSO-E API
        csv_filename = filename
        full_path = volume_path + csv_filename

        try:
            self.context.dbutils.fs.put(full_path, content, overwrite=True)
            self.context.logger.info(f"Saved CSV file: {full_path}")
        except Exception as e:
            self.context.logger.error(f"Failed to save file {full_path}: {e}")
            raise

    def get_file_name(self, chunk: Any | None = None) -> str:
        """Return file name - not used in this implementation."""
        return ""
