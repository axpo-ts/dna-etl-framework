from __future__ import annotations

import io
import time
import xml.etree.ElementTree as ET
import zipfile
from collections.abc import Iterator, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

import pyspark.sql.functions as f
import requests
from entsoe import EntsoeRawClient
from entsoe.mappings import PROCESSTYPE, lookup_area
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType, StructField, StructType
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from data_platform.etl.core.task_context import TaskContext


@dataclass(slots=True)
class DocumentBundle:
    """Represents one XML file extracted from a nested archive.

    Attributes:
        archive_name: Original inner ZIP filename for tracking and deduplication.

    Examples:
        - 'mFRR_BE_20231008T1600Z-20231008T2200Z.zip' (historical)
        - 'currentData' (recent data marker)
        - 'archivedData/mFRR_BE_20250717T2200Z-20250718T0200Z.zip' (hybrid)
        xml_name: Original XML filename inside archive.

    Examples:
        - '001-BALANCING_ENERGY_BIDS_202507212200-202507232200.xml'
        - 'Up_Standard mFRR SA,DA_None_Available_001.xml'
        content: XML text content.
    """

    archive_name: str
    xml_name: str
    content: str


@dataclass(kw_only=True)
class ExtendedEntsoeClient:
    """Unified ENTSO-E web API client for balancing energy bids.

    Handles three archive patterns:
    1. Historical: archives.zip → inner ZIPs → XMLs
    2. Recent: outer.zip → XMLs directly
    3. Hybrid: outer.zip → archivedData.zip + currentData.zip → XMLs

    All methods support automatic date range chunking to handle large historical
    loads and avoid API timeouts.

    Args:
        context: Task execution context (for logging, Spark, secrets).
        api_key: ENTSO-E security token.
        base_url: Base REST URL for ENTSO-E Transparency Platform.
        timeout_sec: HTTP timeout per request.
        default_chunk_days: Default chunk size for date ranges.
        max_retries: Maximum number of retry attempts for failed requests.
        backoff_factor: Backoff multiplier between retries (seconds).
        max_offset: Maximum offset value for pagination (default 4800).
    """

    context: TaskContext
    api_key: str
    base_url: str = "https://web-api.tp.entsoe.eu/api"
    timeout_sec: int = 180
    default_chunk_days: int = 10
    max_retries: int = 3
    backoff_factor: float = 1.0
    max_offset: int = 4800

    _raw_client: EntsoeRawClient = field(init=False)
    _session: requests.Session = field(init=False)
    _last_zip_bytes: bytes | None = field(init=False, default=None)

    def __post_init__(self) -> None:
        """Initialize underlying entsoe-py client and configure retry session."""
        self._raw_client = EntsoeRawClient(api_key=self.api_key)
        self._setup_retry_session()
        self.context.logger.info(
            f"Initialized ExtendedEntsoeClient with default chunk size of {self.default_chunk_days} days "
            f"and retry configuration (max_retries={self.max_retries}, backoff_factor={self.backoff_factor})"
        )

    def __enter__(self) -> ExtendedEntsoeClient:
        """Enter context manager and return self for use in 'with' statements.

        Returns:
            The ExtendedEntsoeClient instance.
        """
        return self

    def __exit__(self, exc_type: type[BaseException] | None, exc_val: BaseException | None, exc_tb: Any) -> None:
        """Exit context manager and clean up resources.

        Closes the HTTP session if it exists.

        Args:
            exc_type: Exception type if an exception was raised.
            exc_val: Exception value if an exception was raised.
            exc_tb: Exception traceback if an exception was raised.
        """
        if self._session:
            self._session.close()

    def _setup_retry_session(self) -> None:
        self._session = requests.Session()

        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=self.backoff_factor,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["GET"],
            raise_on_redirect=True,
            raise_on_status=False,
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self._session.mount("https://", adapter)

        self.context.logger.debug(
            f"Configured session with retry strategy: "
            f"total={self.max_retries}, backoff_factor={self.backoff_factor}, "
            f"status_forcelist=[408, 429, 500, 502, 503, 504]"
        )

    def fetch_raw_xml(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str = "A47",
        document_type: str = "A37",
        business_type: str = "B74",
        chunk_days: int | None = None,
    ) -> list[str]:
        """Fetch raw XML documents from ENTSO-E API with automatic date range chunking.

        Splits large date ranges into smaller chunks to avoid API timeouts and rate limits.
        For small date ranges or when chunk_days exceeds the total period, makes a single request.
        Includes automatic retry logic with exponential backoff for failed requests.

        Args:
            country_code: Country code or Area name (e.g. 'BE', 'DE_LU').
            period_start: Start timestamp in format yyyyMMddHHmm.
            period_end: End timestamp in format yyyyMMddHHmm.
            process_type: Process type code (A46, A47, A51).
            document_type: Document type code. Defaults to A37 (Reserve bid document).
            business_type: Business type code. Defaults to B74 (Offer).
            chunk_days: Number of days per chunk. If None, uses default_chunk_days.

        Returns:
            Combined list of raw XML text documents from all chunks.

        Raises:
            ValueError: If process_type is invalid or date format is incorrect.
            requests.HTTPError: If any API request fails after all retries.

        Example:
            >>> # Fetch 3 months of data in 10-day chunks (default) with retry
            >>> client = ExtendedEntsoeClient(context=ctx, api_key="key")
            >>> xml_docs = client.fetch_raw_xml(
            ...     country_code="BE", period_start="202501010000", period_end="202504010000"
            ... )
        """
        if chunk_days is None:
            chunk_days = self.default_chunk_days

        try:
            start_dt = datetime.strptime(period_start, "%Y%m%d%H%M")
            end_dt = datetime.strptime(period_end, "%Y%m%d%H%M")
        except ValueError as e:
            raise ValueError(f"Invalid date format (expected yyyyMMddHHmm): {e}") from e

        if start_dt >= end_dt:
            raise ValueError(f"Start date {period_start} must be before end date {period_end}")

        if process_type not in PROCESSTYPE:
            raise ValueError(f"Invalid process_type '{process_type}'. Valid options: {', '.join(PROCESSTYPE.keys())}")

        process_type_description = PROCESSTYPE[process_type]
        total_days = (end_dt - start_dt).days

        if total_days <= chunk_days:
            self.context.logger.info(
                f"Fetching {total_days} days in single request for {country_code} - "
                f"{process_type} ({process_type_description})"
            )
            return self._fetch_single_chunk(
                country_code=country_code,
                period_start=period_start,
                period_end=period_end,
                process_type=process_type,
                document_type=document_type,
                business_type=business_type,
            )

        self.context.logger.info(
            f"Fetching {total_days} days of data in {chunk_days}-day chunks "
            f"for {country_code} - {process_type} ({process_type_description})"
        )

        chunks = self._generate_date_chunks(period_start, period_end, chunk_days)
        self.context.logger.info(f"Split date range into {len(chunks)} chunks")

        all_xml_documents: list[str] = []
        failed_chunks: list[tuple[str, str]] = []

        for idx, (chunk_start, chunk_end) in enumerate(chunks, 1):
            chunk_start_str = chunk_start.strftime("%Y%m%d%H%M")
            chunk_end_str = chunk_end.strftime("%Y%m%d%H%M")

            self.context.logger.info(f"Processing chunk {idx}/{len(chunks)}: {chunk_start_str} to {chunk_end_str}")

            try:
                chunk_documents = self._fetch_single_chunk(
                    country_code=country_code,
                    period_start=chunk_start_str,
                    period_end=chunk_end_str,
                    process_type=process_type,
                    document_type=document_type,
                    business_type=business_type,
                )

                all_xml_documents.extend(chunk_documents)

                self.context.logger.info(
                    f"Chunk {idx}/{len(chunks)} successful: {len(chunk_documents)} documents retrieved"
                )
                if idx < len(chunks):
                    time.sleep(1)

            except requests.HTTPError as e:
                if e.response and e.response.status_code == 400:
                    self.context.logger.warning(
                        f"No data available for chunk {idx}/{len(chunks)}: {chunk_start_str} to {chunk_end_str}"
                    )
                else:
                    self.context.logger.error(f"Failed to fetch chunk {idx}/{len(chunks)}: {e}")
                    failed_chunks.append((chunk_start_str, chunk_end_str))

            except Exception as e:
                self.context.logger.error(f"Unexpected error for chunk {idx}/{len(chunks)}: {e}")
                failed_chunks.append((chunk_start_str, chunk_end_str))

        self.context.logger.info(
            f"Chunked fetch completed: {len(all_xml_documents)} total documents retrieved "
            f"from {len(chunks) - len(failed_chunks)}/{len(chunks)} successful chunks"
        )

        if failed_chunks:
            self.context.logger.warning(
                f"Failed chunks ({len(failed_chunks)}): {', '.join([f'{start}-{end}' for start, end in failed_chunks])}"
            )

        return all_xml_documents

    def _generate_date_chunks(
        self,
        period_start: str,
        period_end: str,
        chunk_days: int,
    ) -> list[tuple[datetime, datetime]]:
        start_dt = datetime.strptime(period_start, "%Y%m%d%H%M")
        end_dt = datetime.strptime(period_end, "%Y%m%d%H%M")

        chunks: list[tuple[datetime, datetime]] = []
        current_start = start_dt

        while current_start < end_dt:
            current_end = min(current_start + timedelta(days=chunk_days), end_dt)
            chunks.append((current_start, current_end))
            current_start = current_end

        return chunks

    def _fetch_single_chunk(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str,
        document_type: str,
        business_type: str,
    ) -> list[str]:
        process_type_description = PROCESSTYPE[process_type]

        # Use entsoe-py's lookup_area to get EIC code
        area = lookup_area(country_code)
        connecting_domain = area.code

        self.context.logger.debug(
            f"API request: country={country_code} ({connecting_domain}), "
            f"process_type={process_type} ({process_type_description}), "
            f"period={period_start}-{period_end}"
        )

        all_documents = self._fetch_with_pagination(
            connecting_domain=connecting_domain,
            period_start=period_start,
            period_end=period_end,
            process_type=process_type,
            document_type=document_type,
            business_type=business_type,
            process_type_description=process_type_description,
        )

        if self._needs_hourly_fallback(all_documents):
            self.context.logger.warning(
                f"Document limit exceeded for period {period_start}-{period_end}, falling back to hourly chunking"
            )
            return self._fetch_with_hourly_chunks(
                country_code=country_code,
                period_start=period_start,
                period_end=period_end,
                process_type=process_type,
                document_type=document_type,
                business_type=business_type,
            )

        return all_documents

    def _fetch_with_pagination(
        self,
        connecting_domain: str,
        period_start: str,
        period_end: str,
        process_type: str,
        document_type: str,
        business_type: str,
        process_type_description: str,
    ) -> list[str]:
        all_documents: list[str] = []
        offset = 0
        has_more_documents = True

        while has_more_documents and offset <= self.max_offset:
            params = {
                "documentType": document_type,
                "businessType": business_type,
                "processType": process_type,
                "connecting_Domain": connecting_domain,
                "periodStart": period_start,
                "periodEnd": period_end,
                "storageType": "archive",
                "securityToken": self.api_key,
            }

            if offset > 0:
                params["offset"] = offset

            try:
                resp = self._session.get(self.base_url, params=params, timeout=self.timeout_sec)

                if hasattr(resp, "raw") and hasattr(resp.raw, "retries") and resp.raw.retries:
                    retries_obj = resp.raw.retries
                    if hasattr(retries_obj, "history") and retries_obj.history:
                        retry_count = len(retries_obj.history)
                        self.context.logger.info(
                            f"Request succeeded after {retry_count} retry attempt(s) for "
                            f"{process_type} ({process_type_description}), offset={offset}"
                        )

                # Check for 400 errors that might be acknowledgment documents
                if resp.status_code == 400:
                    try:
                        xml_documents = self._extract_all_xml_from_response(resp)
                        if xml_documents and any(self._is_acknowledgment_document(xml) for xml in xml_documents):
                            all_documents.extend(xml_documents)
                            return all_documents
                    except Exception:
                        pass

                resp.raise_for_status()

                xml_documents = self._extract_all_xml_from_response(resp)

                if not xml_documents:
                    has_more_documents = False
                    break

                page_needs_continuation = self._check_pagination_needed(xml_documents)

                all_documents.extend(xml_documents)

                self.context.logger.info(
                    f"Fetched {len(xml_documents)} documents at offset={offset} "
                    f"for {process_type} ({process_type_description})"
                )

                if page_needs_continuation and offset + 100 <= self.max_offset:
                    offset += 100
                    time.sleep(0.5)
                else:
                    has_more_documents = False

            except requests.exceptions.RetryError as e:
                self.context.logger.error(
                    f"Max retries ({self.max_retries}) exceeded for {process_type} "
                    f"({process_type_description}) at offset={offset}: {e}"
                )
                raise requests.HTTPError(f"API request failed after {self.max_retries} retries") from e
            except requests.exceptions.ConnectionError as e:
                self.context.logger.error(
                    f"Connection error after retries for {process_type} "
                    f"({process_type_description}) at offset={offset}: {e}"
                )
                raise
            except requests.exceptions.Timeout as e:
                self.context.logger.error(
                    f"Timeout after retries for {process_type} ({process_type_description}) at offset={offset}: {e}"
                )
                raise
            except requests.HTTPError as e:
                self.context.logger.error(
                    f"API request failed for {process_type} ({process_type_description}) at offset={offset}: {e}"
                )
                raise
            except Exception as e:
                self.context.logger.error(
                    f"Failed to fetch XML for {process_type} ({process_type_description}) at offset={offset}: {e}"
                )
                raise

        if offset > self.max_offset:
            self.context.logger.warning(
                f"Reached maximum offset ({self.max_offset}) for {process_type} ({process_type_description}), "
                f"some documents may be missing"
            )

        self.context.logger.info(
            f"Completed pagination: fetched {len(all_documents)} total documents "
            f"for {process_type} ({process_type_description})"
        )

        return all_documents

    def _check_pagination_needed(self, xml_documents: list[str]) -> bool:
        for xml_text in xml_documents:
            if self._is_acknowledgment_document(xml_text):
                try:
                    root = ET.fromstring(xml_text)
                    ns = {"ns": root.tag.split("}")[0].strip("{")} if "}" in root.tag else {}
                    path_reason_text = ".//ns:Reason/ns:text" if ns else ".//Reason/text"

                    for reason_elem in root.findall(path_reason_text, ns):
                        if reason_elem.text and "exceeds the allowed maximum (100)" in reason_elem.text:
                            return True
                except ET.ParseError:
                    continue

        return False

    def _needs_hourly_fallback(self, xml_documents: list[str]) -> bool:
        for xml_text in xml_documents:
            if self._is_acknowledgment_document(xml_text):
                try:
                    root = ET.fromstring(xml_text)
                    ns = {"ns": root.tag.split("}")[0].strip("{")} if "}" in root.tag else {}
                    path_reason_text = ".//ns:Reason/ns:text" if ns else ".//Reason/text"

                    for reason_elem in root.findall(path_reason_text, ns):
                        if reason_elem.text and "BALANCING_ENERGY_BIDS_R3" in reason_elem.text:
                            if "exceeds the allowed maximum" in reason_elem.text:
                                return True
                except ET.ParseError:
                    continue

        return False

    def _fetch_with_hourly_chunks(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str,
        document_type: str,
        business_type: str,
    ) -> list[str]:
        process_type_description = PROCESSTYPE[process_type]
        area = lookup_area(country_code)
        connecting_domain = area.code

        start_dt = datetime.strptime(period_start, "%Y%m%d%H%M")
        end_dt = datetime.strptime(period_end, "%Y%m%d%H%M")

        chunk_hours = 12
        hourly_chunks: list[tuple[datetime, datetime]] = []
        current_hour = start_dt
        while current_hour < end_dt:
            next_hour = min(current_hour + timedelta(hours=chunk_hours), end_dt)
            hourly_chunks.append((current_hour, next_hour))
            current_hour = next_hour

        self.context.logger.info(
            f"Using hourly chunking: {len(hourly_chunks)} hours for {country_code} - "
            f"{process_type} ({process_type_description})"
        )

        all_documents: list[str] = []

        for idx, (chunk_start, chunk_end) in enumerate(hourly_chunks, 1):
            chunk_start_str = chunk_start.strftime("%Y%m%d%H%M")
            chunk_end_str = chunk_end.strftime("%Y%m%d%H%M")

            try:
                self.context.logger.debug(
                    f"Processing hourly chunk {idx}/{len(hourly_chunks)}: {chunk_start_str} to {chunk_end_str}"
                )

                hourly_documents = self._fetch_with_pagination(
                    connecting_domain=connecting_domain,
                    period_start=chunk_start_str,
                    period_end=chunk_end_str,
                    process_type=process_type,
                    document_type=document_type,
                    business_type=business_type,
                    process_type_description=process_type_description,
                )

                all_documents.extend(hourly_documents)

                if idx < len(hourly_chunks):
                    time.sleep(0.5)

            except Exception as e:
                self.context.logger.error(f"Failed to fetch hourly chunk {idx}/{len(hourly_chunks)}: {e}")
                continue

        self.context.logger.info(
            f"Hourly chunking completed: {len(all_documents)} total documents from {len(hourly_chunks)} hourly chunks"
        )

        return all_documents

    def query_balancing_energy_bids(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str = "A47",
        document_type: str = "A37",
        business_type: str = "B74",
        chunk_days: int | None = None,
        as_dataframe: bool = False,
        typed_columns: bool = False,
    ) -> list[dict[str, Any]] | DataFrame:
        """Fetch and parse balancing energy bids with automatic chunking and optional DataFrame conversion.

        This is the main method for fetching bid data. It handles large date ranges by automatically
        chunking requests, and can optionally convert results to DataFrame for immediate use.

        Args:
            country_code: Country code or Area name (e.g. 'BE', 'DE_LU').
            period_start: Start timestamp in format yyyyMMddHHmm.
            period_end: End timestamp in format yyyyMMddHHmm.
            process_type: Process type code. Defaults to A47 (mFRR).
                A46 = Replacement Reserve (RR)
                A47 = Manual Frequency Restoration Reserve (mFRR)
                A51 = Automatic Frequency Restoration Reserve (aFRR)
            document_type: Document type code. Defaults to A37.
            business_type: Business type code. Defaults to B74.
            chunk_days: Number of days per chunk. If None, uses default_chunk_days.
            as_dataframe: If True, returns DataFrame instead of list of records.
            typed_columns: If True and as_dataframe=True, applies type casting to numeric/timestamp columns.

        Returns:
            List of normalized bid records, or DataFrame if as_dataframe=True.

        Raises:
            ValueError: If process_type is invalid or date format is incorrect.
            requests.HTTPError: If API request fails.

        Example:
            >>> # Fetch 2 months of data and get DataFrame directly
            >>> client = ExtendedEntsoeClient(context=ctx, api_key="key")
            >>> df = client.query_balancing_energy_bids(
            ...     country_code="BE",
            ...     period_start="202501010000",
            ...     period_end="202503010000",
            ...     chunk_days=10,
            ...     as_dataframe=True,
            ...     typed_columns=True,
            ... )
            >>> df.write.mode("overwrite").saveAsTable("bronze.entsoe.bids")
        """
        xml_documents = self.fetch_raw_xml(
            country_code=country_code,
            period_start=period_start,
            period_end=period_end,
            process_type=process_type,
            document_type=document_type,
            business_type=business_type,
            chunk_days=chunk_days,
        )

        all_records: list[dict[str, Any]] = []

        for idx, xml_text in enumerate(xml_documents, start=1):
            try:
                records = self._parse_balancing_bids_xml(xml_text)
                all_records.extend(records)
            except Exception as e:
                self.context.logger.error(f"Failed to parse document {idx}/{len(xml_documents)}: {e}")
                continue

        process_type_description = PROCESSTYPE[process_type]
        self.context.logger.info(
            f"Successfully parsed {len(all_records)} total bid records "
            f"for {process_type} ({process_type_description}) "
            f"from {len(xml_documents)} documents"
        )

        if as_dataframe:
            return self.to_dataframe(all_records, typed=typed_columns)

        return all_records

    def query_balancing_energy_bids_streaming(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str = "A47",
        document_type: str = "A37",
        business_type: str = "B74",
        chunk_days: int | None = None,
    ) -> Iterator[DataFrame]:
        """Yield DataFrames for each chunk as an iterator for true streaming processing.

        This method allows processing large date ranges without loading all data into memory.
        Each chunk can be processed and written before fetching the next.

        Args:
            country_code: Country code or Area name.
            period_start: Start timestamp in format yyyyMMddHHmm.
            period_end: End timestamp in format yyyyMMddHHmm.
            process_type: Process type code.
            document_type: Document type code.
            business_type: Business type code.
            chunk_days: Days per chunk. If None, uses default_chunk_days.

        Yields:
            DataFrame for each chunk with metadata columns added.

        Example:
            >>> # Process 6 months of data chunk by chunk
            >>> for chunk_df in client.query_balancing_energy_bids_streaming(
            ...     country_code="BE", period_start="202501010000", period_end="202507010000", chunk_days=5
            ... ):
            ...     # Process and write each chunk immediately
            ...     chunk_df.write.mode("append").saveAsTable("bronze.entsoe.bids")
        """
        if chunk_days is None:
            chunk_days = self.default_chunk_days

        chunks = self._generate_date_chunks(period_start, period_end, chunk_days)

        for idx, (chunk_start, chunk_end) in enumerate(chunks, 1):
            try:
                chunk_start_str = chunk_start.strftime("%Y%m%d%H%M")
                chunk_end_str = chunk_end.strftime("%Y%m%d%H%M")

                self.context.logger.info(f"Fetching chunk {idx}/{len(chunks)}: {chunk_start_str} to {chunk_end_str}")

                xml_documents = self._fetch_single_chunk(
                    country_code=country_code,
                    period_start=chunk_start_str,
                    period_end=chunk_end_str,
                    process_type=process_type,
                    document_type=document_type,
                    business_type=business_type,
                )

                chunk_records: list[dict[str, Any]] = []
                for xml_text in xml_documents:
                    try:
                        records = self._parse_balancing_bids_xml(xml_text)
                        chunk_records.extend(records)
                    except Exception as e:
                        self.context.logger.warning(f"Failed to parse XML in chunk {idx}: {e}")
                        continue

                if chunk_records:
                    chunk_df = self.to_dataframe(chunk_records)

                    yield chunk_df

                if idx < len(chunks):
                    time.sleep(1)

            except Exception as e:
                self.context.logger.error(f"Failed to process chunk {idx}: {e}")
                continue

    def fetch_raw_archived_xml(
        self,
        country_code: str,
        period_start: str,
        period_end: str,
        process_type: str = "A47",
        document_type: str = "A37",
        business_type: str = "B74",
    ) -> list[DocumentBundle]:
        """Fetch raw response and preserve inner archive + xml filenames.

        Returns:
            List of DocumentBundle for stable downstream naming & deduplication.
        """
        xml_documents = self.fetch_raw_xml(
            country_code=country_code,
            period_start=period_start,
            period_end=period_end,
            process_type=process_type,
            document_type=document_type,
            business_type=business_type,
            chunk_days=self.default_chunk_days,
        )

        if self._last_zip_bytes is None:
            bundles: list[DocumentBundle] = []
            for i, xml_text in enumerate(xml_documents, start=1):
                archive_identifier = f"api_response_{period_start}_{period_end}"
                bundles.append(
                    DocumentBundle(
                        archive_name=archive_identifier,
                        xml_name=f"document_{i:04d}.xml",
                        content=xml_text,
                    )
                )
            return bundles

        return self._extract_archived_documents(self._last_zip_bytes)

    def to_dataframe(
        self,
        records: Sequence[Mapping[str, Any]],
        typed: bool = False,
    ) -> DataFrame:
        """Convert list of mapping records to Spark DataFrame.

        Args:
            records: Input records from parsed XML.
            typed: If True, applies type inference and casting to numeric/timestamp columns.

        Returns:
            Spark DataFrame with all string columns (typed=False) or typed columns (typed=True).

        Example:
            >>> # Get untyped DataFrame (all strings)
            >>> df = client.to_dataframe(records)
            >>>
            >>> # Get typed DataFrame (numeric and timestamp columns cast)
            >>> df_typed = client.to_dataframe(records, typed=True)
        """
        if not records:
            self.context.logger.warning("No records to convert to DataFrame")
            schema = StructType([StructField("empty", StringType(), True)])
            return self.context.spark.createDataFrame([], schema=schema)

        all_keys: set[str] = set()
        for record in records:
            all_keys.update(record.keys())

        schema_fields = [StructField(key, StringType(), True) for key in sorted(all_keys)]
        schema = StructType(schema_fields)

        normalized_records: list[dict[str, str | None]] = []
        for record in records:
            normalized = {key: str(record[key]) if record.get(key) is not None else None for key in sorted(all_keys)}
            normalized_records.append(normalized)

        df = self.context.spark.createDataFrame(normalized_records, schema=schema)

        self.context.logger.info(f"Created DataFrame with {df.count()} rows and {len(schema_fields)} columns")

        if not typed:
            return df

        numeric_columns = [
            "document_revision_number",
            "point_position",
            "quantity",
            "energy_price",
        ]

        timestamp_columns = [
            "created_datetime",
            "reserve_bid_period_start",
            "reserve_bid_period_end",
            "period_start",
            "period_end",
            "validity_period_start",
            "validity_period_end",
        ]

        df_typed = df
        for col_name in numeric_columns:
            if col_name in df.columns:
                df_typed = df_typed.withColumn(
                    col_name,
                    f.when(f.col(col_name).isNotNull(), f.col(col_name).cast("double")),
                )

        for col_name in timestamp_columns:
            if col_name in df.columns:
                df_typed = df_typed.withColumn(
                    col_name,
                    f.when(
                        f.col(col_name).isNotNull(),
                        f.to_timestamp(f.col(col_name), "yyyy-MM-dd'T'HH:mm:ss'Z'"),
                    ),
                )

        self.context.logger.info("Applied type casting to numeric and timestamp columns")

        return df_typed

    def _extract_all_xml_from_response(self, response: requests.Response) -> list[str]:
        content = response.content
        self._last_zip_bytes = None

        if content[:2] == b"PK":
            # ZIP archive detected
            self._last_zip_bytes = content
            bundles = self._extract_archived_documents(content)
            return [b.content for b in bundles]

        try:
            return [content.decode("utf-8")]
        except UnicodeDecodeError:
            for enc in ("utf-8-sig", "iso-8859-1", "windows-1252"):
                try:
                    return [content.decode(enc)]
                except UnicodeDecodeError:
                    continue
            raise ValueError("Unable to decode response content as XML")

    def _extract_archived_documents(self, zip_content: bytes) -> list[DocumentBundle]:
        """Extract XML files from nested ZIP archives.

        Handles three ENTSO-E archive patterns:

        **Pattern 1: Historical (>90 days)**
        ```
        archives.zip
        ├── mFRR_BE_20231008T1600Z-20231008T2200Z.zip
        │   └── Up_Specific_None_NIL_001.xml
        └── mFRR_BE_20231008T1000Z-20231008T1400Z.zip
            └── Up_Specific_None_NIL_001.xml
        ```

        **Pattern 2: Recent (<90 days)**
        ```
        Balancing Energy Bids [GL EB 12.3.B,C]_202507242200-202507252200.zip
        └── 001-BALANCING_ENERGY_BIDS_202507242200-202507252200.xml
        ```

        **Pattern 3: Hybrid (transition period)**
        ```
        Balancing Energy Bids [GL EB 12.3.B&C]_202507172200-202507202045.zip
        ├── archivedData.zip
        │   └── mFRR_BE_20250717T2200Z-20250718T0200Z.zip
        │       └── Up_Standard mFRR SA,DA_None_Available_001.xml
        └── currentData.zip
            └── 001-BALANCING_ENERGY_BIDS_202507202000-202507202045.xml
        ```

        Args:
            zip_content: Raw ZIP file bytes from ENTSO-E API.

        Returns:
            List of DocumentBundle with preserved archive/xml names for deduplication.

        Raises:
            ValueError: If no XML files found in any layer.
        """
        result: list[DocumentBundle] = []

        try:
            with zipfile.ZipFile(io.BytesIO(zip_content)) as outer_zip:
                outer_files = outer_zip.namelist()
                self.context.logger.debug(f"Outer ZIP contains {len(outer_files)} entries: {outer_files}")

                for outer_entry_name in outer_files:
                    outer_entry_bytes = outer_zip.read(outer_entry_name)

                    if outer_entry_name.endswith("/"):
                        continue

                    # Case 1: Entry is a ZIP (could be inner archives or hybrid layer)
                    if outer_entry_name.endswith(".zip") and outer_entry_bytes[:2] == b"PK":
                        self.context.logger.debug(f"Processing nested ZIP: {outer_entry_name}")
                        is_hybrid_layer = outer_entry_name.lower() in [
                            "archiveddata.zip",
                            "currentdata.zip",
                        ]

                        try:
                            with zipfile.ZipFile(io.BytesIO(outer_entry_bytes)) as inner_zip:
                                inner_files = inner_zip.namelist()
                                self.context.logger.debug(
                                    f"  Inner ZIP '{outer_entry_name}' contains {len(inner_files)} entries"
                                )

                                for inner_entry_name in inner_files:
                                    if inner_entry_name.endswith("/"):
                                        continue

                                    inner_entry_bytes = inner_zip.read(inner_entry_name)

                                    # Case 1a: Another nested ZIP (hybrid archivedData pattern)
                                    if inner_entry_name.endswith(".zip") and inner_entry_bytes[:2] == b"PK":
                                        self.context.logger.debug(
                                            f"    Processing doubly-nested ZIP: {inner_entry_name}"
                                        )
                                        result.extend(
                                            self._extract_deeply_nested_zip(
                                                inner_entry_bytes,
                                                parent_archive=f"{outer_entry_name}/{inner_entry_name}",
                                            )
                                        )

                                    # Case 1b: XML file directly in inner ZIP
                                    elif inner_entry_name.lower().endswith(".xml"):
                                        xml_text = self._decode_xml_bytes(inner_entry_bytes, inner_entry_name)
                                        if is_hybrid_layer:
                                            archive_name = f"{outer_entry_name}/{inner_entry_name}"
                                        else:
                                            archive_name = outer_entry_name

                                        result.append(
                                            DocumentBundle(
                                                archive_name=archive_name,
                                                xml_name=inner_entry_name,
                                                content=xml_text,
                                            )
                                        )

                        except zipfile.BadZipFile:
                            self.context.logger.warning(f"Skipped bad nested ZIP: {outer_entry_name}")
                            continue

                    # Case 2: XML directly in outer ZIP (recent pattern)
                    elif outer_entry_name.lower().endswith(".xml"):
                        self.context.logger.debug(f"Processing direct XML: {outer_entry_name}")
                        xml_text = self._decode_xml_bytes(outer_entry_bytes, outer_entry_name)
                        result.append(
                            DocumentBundle(
                                archive_name="currentData",
                                xml_name=outer_entry_name,
                                content=xml_text,
                            )
                        )

                    else:
                        self.context.logger.debug(f"Skipped unsupported file type: {outer_entry_name}")
                        continue

            if not result:
                raise ValueError("No XML files found inside ZIP archives")

            self.context.logger.info(f"Extracted {len(result)} XML documents from nested archives")
            return result

        except zipfile.BadZipFile as e:
            self.context.logger.error(f"Invalid outer ZIP archive: {e}")
            raise ValueError("Response appears to be ZIP but cannot be extracted") from e
        except Exception as e:
            self.context.logger.error(f"Nested archive extraction failed: {e}")
            raise

    def _extract_deeply_nested_zip(self, zip_bytes: bytes, parent_archive: str) -> list[DocumentBundle]:
        result: list[DocumentBundle] = []

        try:
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as deep_zip:
                for xml_name in deep_zip.namelist():
                    if xml_name.endswith("/"):
                        continue

                    if xml_name.lower().endswith(".xml"):
                        xml_bytes = deep_zip.read(xml_name)
                        xml_text = self._decode_xml_bytes(xml_bytes, xml_name)

                        result.append(
                            DocumentBundle(
                                archive_name=parent_archive,
                                xml_name=xml_name,
                                content=xml_text,
                            )
                        )
                        self.context.logger.debug(f"Extracted XML: {xml_name}")

        except zipfile.BadZipFile:
            self.context.logger.warning(f"Skipped bad deeply-nested ZIP: {parent_archive}")

        return result

    def _decode_xml_bytes(self, data: bytes, name: str) -> str:
        for enc in ("utf-8", "utf-8-sig", "iso-8859-1", "windows-1252"):
            try:
                return data.decode(enc)
            except UnicodeDecodeError:
                continue

        self.context.logger.warning(f"Failed to decode {name}; using latin-1 fallback")
        return data.decode("latin-1", errors="ignore")

    def _is_acknowledgment_document(self, xml_text: str) -> bool:
        try:
            root = ET.fromstring(xml_text)

            # Check for Acknowledgement_MarketDocument root tag
            if "Acknowledgement_MarketDocument" in root.tag:
                return True

            # Check for Reason code 999 (no data available)
            ns = {"ns": root.tag.split("}")[0].strip("{")} if "}" in root.tag else {}
            path_reason_code = ".//ns:Reason/ns:code" if ns else ".//Reason/code"

            for rc in root.findall(path_reason_code, ns):
                if rc.text and rc.text.strip() == "999":
                    return True

        except ET.ParseError:
            return False

        return False

    def _parse_balancing_bids_xml(self, xml_text: str) -> list[dict[str, Any]]:
        try:
            root = ET.fromstring(xml_text)
            ns = {"ns": root.tag.split("}")[0].strip("{")}

            self.context.logger.debug(f"Parsing XML with namespace: {ns['ns']}, root tag: {root.tag}")

            doc_data = self._extract_document_fields(root, ns)

            bid_records: list[dict[str, Any]] = []
            time_series_list = root.findall(".//ns:Bid_TimeSeries", ns)

            if not time_series_list:
                self.context.logger.warning("No Bid_TimeSeries found in document")
                return []

            for ts in time_series_list:
                ts_data = self._extract_timeseries_fields(ts, ns)

                periods = self._extract_period_data(ts, ns)

                if not periods:
                    record = {**doc_data, **ts_data}
                    bid_records.append(record)
                else:
                    for period in periods:
                        record = {**doc_data, **ts_data, **period}
                        bid_records.append(record)

            return bid_records

        except ET.ParseError as e:
            self.context.logger.error(f"XML parsing failed: {e}")
            self.context.logger.error(f"XML preview: {xml_text[:500]}")
            raise
        except Exception as e:
            self.context.logger.error(f"Failed to parse balancing bids XML: {e}")
            raise

    def _extract_document_fields(self, root: ET.Element, ns: dict[str, str]) -> dict[str, Any]:
        return {
            "document_mrid": self._get_text(root, ".//ns:mRID", ns),
            "document_revision_number": self._get_text(root, ".//ns:revisionNumber", ns),
            "document_type": self._get_text(root, ".//ns:type", ns),
            "process_type": self._get_text(root, ".//ns:process.processType", ns),
            "sender_mrid": self._get_text(root, ".//ns:sender_MarketParticipant.mRID", ns),
            "sender_role": self._get_text(root, ".//ns:sender_MarketParticipant.marketRole.type", ns),
            "receiver_mrid": self._get_text(root, ".//ns:receiver_MarketParticipant.mRID", ns),
            "receiver_role": self._get_text(root, ".//ns:receiver_MarketParticipant.marketRole.type", ns),
            "created_datetime": self._get_text(root, ".//ns:createdDateTime", ns),
            "reserve_bid_period_start": self._get_text(root, ".//ns:reserveBid_Period.timeInterval/ns:start", ns),
            "reserve_bid_period_end": self._get_text(root, ".//ns:reserveBid_Period.timeInterval/ns:end", ns),
            "domain_mrid": self._get_text(root, ".//ns:domain.mRID", ns),
            "subject_participant_mrid": self._get_text(root, ".//ns:subject_MarketParticipant.mRID", ns),
            "subject_participant_role": self._get_text(root, ".//ns:subject_MarketParticipant.marketRole.type", ns),
        }

    def _extract_timeseries_fields(self, ts_elem: ET.Element, ns: dict[str, str]) -> dict[str, Any]:
        reason_codes = [
            r.find("ns:code", ns).text for r in ts_elem.findall(".//ns:Reason", ns) if r.find("ns:code", ns) is not None
        ]
        reason_texts = [
            r.find("ns:text", ns).text for r in ts_elem.findall(".//ns:Reason", ns) if r.find("ns:text", ns) is not None
        ]

        return {
            "bid_mrid": self._get_text(ts_elem, ".//ns:mRID", ns),
            "auction_mrid": self._get_text(ts_elem, ".//ns:auction.mRID", ns),
            "business_type": self._get_text(ts_elem, ".//ns:businessType", ns),
            "acquiring_domain_mrid": self._get_text(ts_elem, ".//ns:acquiring_Domain.mRID", ns),
            "connecting_domain_mrid": self._get_text(ts_elem, ".//ns:connecting_Domain.mRID", ns),
            "cancelled_ts": self._get_text(ts_elem, ".//ns:cancelledTS", ns),
            "quantity_measure_unit": self._get_text(ts_elem, ".//ns:quantity_Measure_Unit.name", ns),
            "currency_unit": self._get_text(ts_elem, ".//ns:currency_Unit.name", ns),
            "price_measure_unit": self._get_text(ts_elem, ".//ns:price_Measure_Unit.name", ns),
            "divisible": self._get_text(ts_elem, ".//ns:divisible", ns),
            "linked_bids_identification": self._get_text(ts_elem, ".//ns:linkedBidsIdentification", ns),
            "multipart_bid_identification": self._get_text(ts_elem, ".//ns:multipartBidIdentification", ns),
            "exclusive_bids_identification": self._get_text(ts_elem, ".//ns:exclusiveBidsIdentification", ns),
            "status": self._get_text(ts_elem, ".//ns:status/ns:value", ns),
            "flow_direction": self._get_text(ts_elem, ".//ns:flowDirection.direction", ns),
            "standard_market_product_type": self._get_text(
                ts_elem, ".//ns:standard_MarketProduct.marketProductType", ns
            ),
            "original_market_product_type": self._get_text(
                ts_elem, ".//ns:original_MarketProduct.marketProductType", ns
            ),
            "validity_period_start": self._get_text(ts_elem, ".//ns:validity_Period.timeInterval/ns:start", ns),
            "validity_period_end": self._get_text(ts_elem, ".//ns:validity_Period.timeInterval/ns:end", ns),
            "reason_codes": ",".join(reason_codes) if reason_codes else None,
            "reason_texts": ",".join(reason_texts) if reason_texts else None,
        }

    def _extract_period_data(self, ts_elem: ET.Element, ns: dict[str, str]) -> list[dict[str, Any]]:
        periods: list[dict[str, Any]] = []

        for period in ts_elem.findall(".//ns:Period", ns):
            period_start = self._get_text(period, ".//ns:timeInterval/ns:start", ns)
            period_end = self._get_text(period, ".//ns:timeInterval/ns:end", ns)
            resolution = self._get_text(period, ".//ns:resolution", ns)

            for point in period.findall(".//ns:Point", ns):
                point_data = {
                    "period_start": period_start,
                    "period_end": period_end,
                    "resolution": resolution,
                    "point_position": self._get_text(point, ".//ns:position", ns),
                    "quantity": self._get_text(point, ".//ns:quantity.quantity", ns),
                    "energy_price": self._get_text(point, ".//ns:energy_Price.amount", ns),
                }
                periods.append(point_data)

        return periods

    def _get_text(self, element: ET.Element, path: str, ns: dict[str, str]) -> str | None:
        found = element.find(path, ns)
        return found.text if found is not None else None
