# data_platform/etl/extract/http/montel.py
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from data_platform.etl.extract.http.async_http_api_client import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin
from data_platform.etl.extract.http.sync_http_api_client import SyncHttpApiClient


@dataclass(kw_only=True)
class MontelApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Montel API client for fetching OHLCV data and trades.

    This client supports fetching data for multiple symbols and date ranges.
    """

    context: Any
    credentials: Any
    symbols: list[str]
    from_dts: list[datetime]
    to_dts: list[datetime]

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url: str = "https://api.montelnews.com/"

    task_name: str = field(init=False, default="MontelApiClient")

    def __post_init__(self) -> None:
        """Validate input lengths, set default headers and register endpoint descriptors after initialization."""
        self.headers = (self.headers or {}) | {"Accept-Encoding": "deflate"}
        # safety check like the old reader
        if len(self.symbols) != len(self.from_dts) or len(self.symbols) != len(self.to_dts):
            raise ValueError("symbols, from_dts and to_dts must have the same length")
        super().__post_init__()
        self._register_endpoints()

    def _build_chunks_func(self) -> list[dict[str, Any]]:
        return [{"symbolKey": s, "from_dt": f, "to_dt": t} for s, f, t in zip(self.symbols, self.from_dts, self.to_dts)]

    def _register_endpoints(self) -> None:
        self._endpoints = {
            "ohlcv": EndpointDescriptor(
                url=f"{self._base_url}derivatives/ohlc/get",
                build_param_chunks=self._build_chunks_func,
                build_params=lambda chunk: {
                    "symbolKey": chunk["symbolKey"],
                    "fields": [
                        "Date",
                        "Open",
                        "High",
                        "Low",
                        "Close",
                        "Settlement",
                        "Volume",
                        "OpenInterest",
                        "ContractName",
                    ],
                    "fromDate": chunk["from_dt"],
                    "toDate": chunk["to_dt"],
                    "sortType": "Ascending",
                    "insertElementsWhenDataMissing": "Never",
                    "continuous": False,
                },
            ),
            "trades": EndpointDescriptor(
                url=f"{self._base_url}derivatives/trade/get",
                build_param_chunks=self._build_chunks_func,
                build_params=lambda chunk: {
                    "symbolKey": chunk["symbolKey"],
                    "fromTime": chunk["from_dt"],
                    "toTime": chunk["to_dt"],
                    "sortType": "Ascending",
                },
            ),
        }

    def get_ohlcv(self, **ovr: Any) -> Any:
        """Fetch OHLCV data for specified symbols and date ranges."""
        return self._execute_endpoint("ohlcv", **ovr)

    def get_trades(self, **ovr: Any) -> Any:
        """Fetch trade data for specified symbols and date ranges."""
        return self._execute_endpoint("trades", **ovr)

    def get_metadata(self, fetch_expired: bool = False, **ovr: Any) -> Any:
        """Fetch metadata for active or expired contracts."""
        key = "metadata_expired" if fetch_expired else "metadata"
        return self._execute_endpoint(key, **ovr)


@dataclass(kw_only=True)
class MontelMetadataApiClient(SyncHttpApiClient):
    """Blocking reader for Montel contract metadata.

    • Uses **SyncHttpApiClient** → a single, blocking HTTP/1.1 request
    • Endpoint chosen by `fetch_expired` flag (same as legacy code)
    • No chunking or custom params needed  the default GET without a
      query-string returns the entire JSON payload, identical to the old
      implementation.
    """

    # --- business flag --------------------------------------------------------
    fetch_expired: bool = False  # active vs. expired contracts
    # endpoint_url is computed in __post_init__
    _base_url: str = "https://api.montelnews.com/derivatives/"
    endpoint_url: str = field(init=False, repr=False)
    task_name: str = field(init=False, default="MontelMetadataApiClient")

    def __post_init__(self) -> None:
        """Initialize the Montel metadata reader with headers and endpoint URL."""
        # choose the correct endpoint
        self.endpoint_url = (
            f"{self._base_url}getmetadataforexpiredcontracts"
            if self.fetch_expired
            else f"{self._base_url}getmetadataforactivecontracts"
        )

        # Montel expects deflate compression (same as async client)
        self.headers = (self.headers or {}) | {"Accept-Encoding": "deflate"}

        super().__post_init__()
