# data_platform/etl/extract/http/nordpool.py
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any, ClassVar

from data_platform.etl.extract.http import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin


@dataclass(kw_only=True)
class NordpoolApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Base Client for Nordpool API endpoints.

    Handles password-grant authentication and generates one request per day.
    Includes day-ahead listener functionality for spot price Clients.
    """

    file_volume: Any = None  # override the default volume for file output
    full_load: bool = False
    chunk_size_days: int = 1  # one request per day
    lookahead: timedelta = timedelta(days=1)  # default T+1 “to” date
    datetime_name_params: tuple[str, str] = ("from_date", "to_date")
    flow_based_domain: str = "Core"

    task_name: str = field(init=False, default="NordpoolApiClient")

    # Nordpool area constants
    _AREAS: ClassVar[list[str]] = [
        "NO1",
        "NO2",
        "NO3",
        "NO4",
        "NO5",
        "SE1",
        "SE2",
        "SE3",
        "SE4",
        "SE",
        "DK1",
        "DK2",
        "FI",
        "EE",
        "LV",
        "LT",
    ]

    def __post_init__(self) -> None:
        """Initialize the Nordpool API client."""
        # add gzip header and run parent post-init (creates the httpx session)
        self.headers = {**(self.headers or {}), "Accept-Encoding": "gzip"}

        super().__post_init__()  # vital: triggers mix-in hook
        self._register_endpoints()

    # ------------------------------------------------------------------
    @staticmethod
    def _is_empty_payload(payload: Any) -> bool:
        if not payload or not isinstance(payload, list):
            return True
        return payload[0].get("status") == "Missing"

    # ── endpoint registry ----------------------------------------------------
    def _register_endpoints(self) -> None:
        """Define all Nordpool endpoints once."""
        self._endpoints = {
            "spot": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/Auction/Prices/ByAreas",
                overrides={"poll_on_empty": True, "poll_interval_sec": 60, "poll_timeout_sec": 3600},
                build_param_chunks=self._build_param_chunks,
                build_params=self._spot_build_params,
            ),
            "volume": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/Auction/Volumes/ByAreas",
                build_param_chunks=self._build_param_chunks,
                build_params=self._volume_build_params,
            ),
            "system_price": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/System/Price",
                build_param_chunks=self._build_param_chunks,
                build_params=self._system_price_build_params,
            ),
            "turnover": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/System/Turnover",
                build_param_chunks=self._build_param_chunks,
                build_params=self._turnover_build_params,
            ),
            "flow": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/Auction/Flows/ByAreas",
                overrides={
                    "lookahead": timedelta(days=0),
                    "min_start_datetime": datetime(1999, 5, 10, 0, 0, 0),
                    "max_end_datetime": datetime(2024, 11, 1, 0, 0, 0),
                },
                build_param_chunks=self._build_param_chunks,
                build_params=self._flow_build_params,
            ),
            "physical_flow": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/Auction/ScheduledPhysicalFlows/ByAreas",
                overrides={
                    "poll_on_empty": True,
                    "poll_interval_sec": 60,
                    "poll_timeout_sec": 5400,  # 90 minutes to catch very varying data arrival times
                    "min_start_datetime": datetime(2024, 10, 1, 0, 0, 0),
                },
                build_param_chunks=self._build_param_chunks,
                build_params=self._physical_build_params,
            ),
            "flow_based_constraints": EndpointDescriptor(
                url="https://data-api.nordpoolgroup.com/api/v2/Auction/FlowBasedConstraints/ByDomain",
                overrides={
                    "min_start_datetime": datetime(2024, 6, 14, 0, 0, 0),
                },
                build_param_chunks=self._build_param_chunks,
                build_params=self._flow_based_constraints_build_params,
                get_file_name=self._flow_based_constraints_get_file_name,  # ✅ Add custom file naming
            ),
        }

    @staticmethod
    def _as_date(value: date | datetime | None) -> date:
        """Return *value* as a `date` object.

        Falls back to today's date when *value* is None.
        """
        if value is None:
            return datetime.today().date()
        return value.date() if isinstance(value, datetime) else value

    def _build_param_chunks(self) -> list[dict[str, Any]]:
        """Generate one item per day in the date range."""
        # refresh the date window *after* the endpoint overrides were applied
        self._ensure_window()
        start = self._as_date(self._window_start)
        end = self._as_date(self._window_end or self._default_to_date())
        return [{"date": (start + timedelta(days=i)).strftime("%Y-%m-%d")} for i in range((end - start).days + 1)]

    def _default_to_date(self) -> datetime:
        return datetime.now() + self.lookahead

    def get_file_name(self, chunk: dict[str, Any]) -> str:
        """yyyy/mm/dd/XXX_yyyymmdd.json under the configured volume."""
        d = datetime.fromisoformat(chunk["date"])
        clean_date = chunk["date"].replace("-", "")
        return f"/Year={d:%Y}/Month={d:%m}/Day={d:%d}/{self.file_volume.name}_{clean_date}.json"

    def _common_area_params(self) -> str:
        return ",".join(self._AREAS)

    def build_params(self) -> dict[str, Any]:
        """Return endpoint-specific parameters (to be overridden)."""
        return {}

    def _spot_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {
            "date": chunk["date"],
            "market": "DayAhead",
            "currency": "EUR",
            "areas": self._common_area_params(),
        }

    def _volume_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {
            "date": chunk["date"],
            "market": "DayAhead",
            "areas": self._common_area_params(),
        }

    def _system_price_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {"date": chunk["date"], "currency": "EUR"}

    def _turnover_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {"date": chunk["date"]}

    def _flow_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {
            "date": chunk["date"],
            "market": "DayAhead",
            "areas": self._common_area_params(),
        }

    def _physical_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {
            "date": chunk["date"],
            "market": "DayAhead",
            "areas": self._common_area_params(),
        }

    def _flow_based_constraints_build_params(self, chunk: dict[str, Any]) -> dict[str, Any]:
        return {
            "date": chunk["date"],
            "market": "DayAhead",
            "flowBasedDomain": self.flow_based_domain,
        }

    def _flow_based_constraints_get_file_name(self, chunk: dict[str, Any]) -> str:
        """Generate domain-specific file names for flow-based constraints.

        Creates file names in format: flow_based_constraints_core_yyyymmdd.json

        Args:
            chunk: Date chunk containing the date to query.

        Returns:
            Domain-specific file path with year/month/day partitioning.
        """
        d = datetime.fromisoformat(chunk["date"])
        clean_date = chunk["date"].replace("-", "")
        domain_suffix = self.flow_based_domain.lower()

        return f"/Year={d:%Y}/Month={d:%m}/Day={d:%d}/{self.file_volume.name}_{domain_suffix}_{clean_date}.json"

    def get_spot(self, **ovr: Any) -> Any:
        """Get day-ahead spot prices for all configured areas.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for spot prices.
        """
        return self._execute_endpoint("spot", **ovr)

    def get_volume(self, **ovr: Any) -> Any:
        """Get day-ahead volume data for all configured areas.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for volume data.
        """
        return self._execute_endpoint("volume", **ovr)

    def get_system_price(self, **ovr: Any) -> Any:
        """Get system price data for the specified date.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for system prices.
        """
        return self._execute_endpoint("system_price", **ovr)

    def get_turnover(self, **ovr: Any) -> Any:
        """Get system turnover data for the specified date.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for system turnover.
        """
        return self._execute_endpoint("turnover", **ovr)

    def get_flow(self, **ovr: Any) -> Any:
        """Get day-ahead flow data for all configured areas.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for flow data.
        """
        if not self.full_load:
            self.context.logger.warning("Flow data is not available for partial loads, use full_load=True to fetch it.")
        else:
            return self._execute_endpoint("flow", **ovr)

    def get_physical_flow(self, **ovr: Any) -> Any:
        """Get scheduled physical flows for all configured areas.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for physical flows.
        """
        return self._execute_endpoint("physical_flow", **ovr)

    def get_flow_based_constraints(self, **ovr: Any) -> Any:
        """Get flow-based constraints data for the specified domain and date.

        Args:
            **ovr: Optional overrides for the endpoint execution (e.g., timeout_sec).

        Returns:
            Any: The response from the Nordpool API for flow-based constraints.
        """
        return self._execute_endpoint("flow_based_constraints", **ovr)
