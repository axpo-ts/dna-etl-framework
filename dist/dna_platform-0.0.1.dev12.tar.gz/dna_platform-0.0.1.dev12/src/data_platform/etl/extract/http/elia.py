import json
from datetime import datetime, timedelta
from typing import Any, cast

from requests import Response

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig, EliaApiReaderConfig
from data_platform.tasks.reader.api.http.request_reader import JsonResponseApiReaderTask, RequestsApiReaderTask


class EliaApiReaderExportTask(RequestsApiReaderTask):
    """Task for reading data from the Elia API and saving it to a specified volume.

    Attributes:
        task_name (str): The name of the task.
    """

    task_name = "EliaApiReaderExportTask"
    verify = True

    def __init__(self) -> None:
        """Initialize the EliaApiReaderExportTask with the configuration dataclass."""
        super().__init__()
        self.dataclass = EliaApiReaderConfig

    def prepare_request(self, context: TaskContext, conf: BaseApiReaderConfig) -> dict:
        """Prepare the payload for the API request.

        Args:
            context (TaskContext): The context for task execution.
            conf (Configuration): The configuration containing API parameters.

        Returns:
            dict: A dictionary representing the payload for the API request.
        """
        _conf = cast(EliaApiReaderConfig, conf)
        api_parameters = _conf.api_parameters or {}
        self.validate_parameters(api_parameters)

        # Extract parameters
        dataset_id = api_parameters["dataset_id"]
        data_format = _conf.file_format

        # Construct the URL
        url = f"{_conf.api_url}/{dataset_id}/exports/{data_format}"
        _conf.api_url = url  # Update the api_url in the configuration

        return {}

    def prepare_params(self, context: TaskContext, conf: BaseApiReaderConfig, params: dict | None = None) -> dict:
        """Prepare additional parameters for the API request.

        Args:
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing API parameters.
            params (dict | None): Optional initial parameters to be extended.

        Returns:
            dict: A dictionary of additional parameters for the API request.
        """
        _conf = cast(EliaApiReaderConfig, conf)
        api_parameters = _conf.api_parameters or {}
        params = params or {}

        days = int(api_parameters.get("delta_load_window_days", 0))
        column_to_filter = api_parameters["column_to_filter"]
        where_clause = self.create_where_clause(column_to_filter, days)
        select_columns = api_parameters.get("select_clause", "")
        params["where"] = where_clause
        if select_columns:
            params["select"] = select_columns

        return params

    def extract_content(self, context: TaskContext, conf: BaseApiReaderConfig, response: Response) -> object:
        """Extract the content from the API response.

        Args:
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing API parameters.
            response (Response): The HTTP response object from the API request.

        Returns:
            object: The extracted content from the response if successful.

        Raises:
            ValueError: If the API request fails with a non-200 status code.
        """
        if response.status_code == 200:
            return response.content
        else:
            context.logger.error(f"Failed to retrieve data: {response.status_code} - {response.text}")
            raise ValueError(f"API request failed with status code {response.status_code}")

    def validate_parameters(self, api_parameters: dict) -> None:
        """Validate required API parameters.

        Args:
            api_parameters (dict): The API parameters to validate.

        Raises:
            ValueError: If any required parameters are missing.
        """
        required_keys = ["dataset_id", "column_to_filter", "delta_load_window_days"]
        missing_keys = [key for key in required_keys if key not in api_parameters]
        if missing_keys:
            raise ValueError(f"Missing required API parameters: {', '.join(missing_keys)}")

    def create_where_clause(self, column: str, days: int) -> str:
        """Create the 'where' clause for the API request.

        Args:
            column (str): The column to filter.
            days (int): The number of days for the date filter.

        Returns:
            str: The constructed 'where' clause.
        """
        filter_date = datetime.now() - timedelta(days=days)
        return f"{column}>'{filter_date.strftime('%Y-%m-%d')}'"

    def save_to_volume(self, content: Any, context: TaskContext, conf: BaseApiReaderConfig) -> None:
        """Save the API response content to a CSV file in the specified volume.

        Args:
            content (Any): The raw content from the API response.
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing storage path.

        Returns:
            None
        """
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

        file_path = f"{conf.volume_storage_path}/records_{timestamp}.{conf.file_format}"
        with open(file_path, "wb") as file:
            file.write(content)
        context.logger.info(f"CSV file saved to {file_path}")


class EliaMetadataApiReaderTask(JsonResponseApiReaderTask):
    """Task for reading metadata from the Elia API and saving it to a specified volume."""

    task_name = "EliaMetadataApiReaderTask"
    verify = True

    def __init__(self) -> None:
        """Initialize the EliaMetadataApiReaderTask with the configuration dataclass."""
        super().__init__()
        self.dataclass = EliaApiReaderConfig

    def prepare_request(self, context: TaskContext, conf: BaseApiReaderConfig) -> dict:
        """Prepare the payload for the API request."""
        _conf = cast(EliaApiReaderConfig, conf)
        api_parameters = _conf.api_parameters or {}

        # Extract dataset_id
        dataset_id = api_parameters.get("dataset_id", "")

        # Construct the URL for metadata endpoint
        url = f"{_conf.api_url}/{dataset_id}?timezone=UTC&include_links=false&include_app_metas=false"
        _conf.api_url = url  # Update the api_url in the configuration

        return {}

    def save_to_volume(self, content: Any, context: TaskContext, conf: BaseApiReaderConfig) -> None:
        """Save the API response content to a JSON file in the specified volume."""
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")

        file_path = f"{conf.volume_storage_path}/metadata_{timestamp}.json"
        with open(file_path, "w") as file:
            json.dump(content, file, indent=2)
        context.logger.info(f"Metadata JSON file saved to {file_path}")
