import json
from collections.abc import Collection

import dlt
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as f
from pyspark.sql.functions import *  # noqa
from pyspark.sql.window import *  # noqa

spark = SparkSession.builder.getOrCreate()


def get_dlt_config(dq_config_path: str) -> Collection[dict[str, str]]:
    """Get DQ Rules Config."""
    try:
        with open(f"{dq_config_path}") as f:
            dlt_config = json.loads(f.read())
            return dlt_config
    except Exception:
        return [{"Tag": "dummy", "Table": "dummy", "Schema": "dummy", "Enabled": False}]


def get_dq_rules(tag: str, schema: str, table: str, dq_config: Collection[dict[str, str]]) -> dict[str, str]:
    """Get the data quality rules from a table/config.

    Args:
        spark (SparkSession): The Spark session to use for executing the query.
        tag (str): tag to match
        schema (str): schema to match
        table (str): table to match
        dq_config (dict[]): Dictionary format of data quality rules

    Returns:
            dict: dictionary of rules that matched the tag
            List: Expressions (if any)
    """
    rules = {}
    # df = spark.read.table(f'catalog.schema.table') --Can be refactored to read the rules from a table
    df = spark.createDataFrame(dq_config)
    expressions = []
    for row in df.filter(
        (f.trim(f.col("Tag")) == tag)
        & (f.trim(f.col("Table")) == table)
        & (f.trim(f.col("Schema")) == schema)
        & f.col("Enabled")
    ).collect():
        if all(text in row["Constraint"] for text in ["Expression", "Constraint"]):
            rules[row["Name"]] = eval(row["Constraint"]).get("Constraint")
            expressions.append(eval(row["Constraint"]).get("Expression"))
        else:
            rules[row["Name"]] = row["Constraint"]
    return rules, expressions


def generate_table_id(df: DataFrame, primary_keys: list) -> DataFrame:
    """Generates a new DataFrame with a 'table_id' column based on the hash of primary keys or all table columns.

    Args:
        df (DataFrame): Source datafarme to apply the table_id.
        primary_keys (list): The primary key's defined for the table.

    Returns:
        DataFrame: A new DataFrame with 'table_id' column, starting from the maximum 'table_id'+1 in the target table.
    """
    df = df.withColumn(
        "table_id", (abs(hash(*primary_keys)) if primary_keys else abs(hash(*df.columns))).cast("bigint")
    )

    return df.drop(*[cols for cols in df.columns if "_drop_" in cols])


def create_dlt_table_and_apply_dq_rules(
    source_table: str,
    dlt_config: dict[str, str],
    table_schema_ddl: str,
    primary_keys: list,
    create_tgt_table: bool = True,
) -> None:
    """Create a Delta Live Table (DLT) from the source table while applying dq rules.

    Args:
        source_table (str): Name of the source table to read data from.
        dlt_config (dict[]): dlt config dictionary which has info about tablem, schema, catalog, dq file path etc.
        table_schema_ddl (str): Schema of the table with Comments and Primary Keys
        primary_keys (list): The primary key's defined for the table.
        create_tgt_table (bool): An optional parameter to create target table as Mview.

    Returns:
        None
    """
    dq_config = get_dlt_config(dlt_config["dq_config_path"])
    valid_rules = get_dq_rules("valid", dlt_config["target_table_schema"], dlt_config["target_table_name"], dq_config)
    drop_rules = get_dq_rules("drop", dlt_config["target_table_schema"], dlt_config["target_table_name"], dq_config)

    rules_expressions = valid_rules[1] + drop_rules[1]

    @dlt.table(name=dlt_config["target_table_name"] + "_dq_checks", temporary=True)
    @dlt.expect_all(valid_rules[0])
    @dlt.expect_all_or_drop(drop_rules[0])
    def dq_table() -> None:
        df = spark.read.table(source_table)
        if rules_expressions:
            df = df.select(*df.columns, *[eval(exp) for exp in rules_expressions])
        return df

    if create_tgt_table:

        @dlt.table(
            name=dlt_config["target_table_name"],
            comment=dlt_config["comment"],
            table_properties=dlt_config["table_properties"],
            schema=table_schema_ddl,
        )
        def table() -> None:
            df = spark.read.table(f"LIVE.{dlt_config['target_table_name']}_dq_checks")
            df = generate_table_id(df, primary_keys)
            return df
