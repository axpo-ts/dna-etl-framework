# Databricks notebook source
# MAGIC %md
# MAGIC ### Configuration

# COMMAND ----------

import json
import sys
from collections.abc import Collection

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
# allow data_platform to be imported
sys.path.append(f"{spark.conf.get('workspace_root_path')}files/src")

from data_platform.notebooks.dlt_functions import create_table_ddl  # noqa: E402
from data_platform.notebooks.gld_data_quality_rules import create_dlt_table_and_apply_dq_rules  # noqa: E402

# COMMAND ----------
catalog_prefix = spark.conf.get("catalog_prefix")
schema_prefix = spark.conf.get("schema_prefix")
dlt_config_path = spark.conf.get("dlt_config")
dq_config_path = spark.conf.get("dq_config")
target_table_schema = spark.conf.get("target_table_schema")

# COMMAND ----------


def get_dlt_config(dlt_config_path: str) -> Collection[dict[str, str]]:
    """Get DLT Config."""
    with open(f"{dlt_config_path}") as f:
        dlt_config = json.loads(f.read())
        return dlt_config


def get_table_ddl(_config: dict[str, str], source_table_name: str) -> tuple[str, list[str]]:
    """Get Table Schema DDL which adds Schema, Comments along with Primary Keys as list."""
    primary_keys = _config.get("primary_keys", "")
    return create_table_ddl(
        spark, primary_keys=primary_keys, target_table=f"{_config['target_table_name']}", src_table=source_table_name
    )


# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------

dlt_config = get_dlt_config(dlt_config_path)
for _config in dlt_config:
    """ Preparing source data  """
    source_table_name = f"""
        {catalog_prefix}{_config["source_catalog_name"]}.{schema_prefix}{_config["source_schema_name"]}.{_config["source_table_name"]}
    """

    table_ddl_str, primary_keys = get_table_ddl(_config, source_table_name)
    _config["target_table_schema"] = target_table_schema
    _config["dq_config_path"] = dq_config_path
    create_dlt_table_and_apply_dq_rules(source_table_name, _config, table_ddl_str, primary_keys)
