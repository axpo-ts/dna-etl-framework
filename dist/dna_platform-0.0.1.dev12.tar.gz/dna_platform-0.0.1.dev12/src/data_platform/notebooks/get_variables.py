# Databricks notebook source
import yaml
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

config_path = dbutils.widgets.get("variable_file")  # type: ignore # noqa: F821


# COMMAND ----------

config = yaml.safe_load(open(config_path))

# COMMAND ----------

for _key in config:
    print(_key)
    # Set the task values
    dbutils.jobs.taskValues.set(_key, config[_key])  # type: ignore # noqa: F821

# COMMAND ----------
