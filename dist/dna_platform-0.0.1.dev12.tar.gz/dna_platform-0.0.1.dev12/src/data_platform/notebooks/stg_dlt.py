# Databricks notebook source
# MAGIC %md
# MAGIC ### Configuration

# COMMAND ----------

import json
from collections.abc import Collection

import dlt
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# COMMAND ----------
catalog_prefix = spark.conf.get("catalog_prefix")
schema_prefix = spark.conf.get("schema_prefix")
dlt_config_path = spark.conf.get("dlt_config")
workspace_root_path = spark.conf.get("workspace_root_path")
source_catalog = spark.conf.get("source_catalog")

# COMMAND ----------


def get_dlt_config(dlt_config_path: str) -> Collection[dict[str, str]]:
    """Get DLT Config."""
    with open(f"{dlt_config_path}") as f:
        dlt_config = json.loads(f.read())
        return dlt_config


def get_sql_query(workspace_root_path: str, sql_file_path: str) -> str:
    """Get SQL Query."""
    with open(f"{workspace_root_path}{sql_file_path}") as f:
        sql_file_path = f.read()
        return sql_file_path


# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------


def create_dlt_table(dlt_config: dict[str, str]) -> None:  # noqa: D417
    """Create a Delta Live Table (DLT) from the source table.

    Args:
        table_name (str): Name of the DLT table to create.
        source_table (str): Name of the source table to read data from.

    Returns:
        None
    """
    # Get sql query to be used
    sql_query = get_sql_query(workspace_root_path, _config["sql_file_path"])

    # inject source catalog into sql
    sql_query = sql_query.replace("source_catalog", source_catalog)
    print(f"sql query = {sql_query}")

    @dlt.table(
        name=_config["target_table_name"], comment=_config["comment"], table_properties=_config["table_properties"]
    )
    @dlt.expect_all_or_drop(_config["data_quality_rules"])
    def table() -> None:
        return spark.sql(sql_query)


dlt_config = get_dlt_config(dlt_config_path)
for _config in dlt_config:
    create_dlt_table(_config)
