# Databricks notebook source
# MAGIC %md
# MAGIC ### Configuration

# COMMAND ----------

import json
import sys
from collections.abc import Collection

import dlt
from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()
# allow data_platform to be imported
sys.path.append(f"{spark.conf.get('workspace_root_path')}files/src")
from data_platform.notebooks.dlt_functions import create_table_ddl, execute_sql_script  # noqa: E402
from data_platform.notebooks.gld_data_quality_rules import generate_table_id  # noqa: E402

spark = SparkSession.builder.getOrCreate()

# COMMAND ----------

catalog_prefix = spark.conf.get("catalog_prefix")
schema_prefix = spark.conf.get("schema_prefix")
dlt_config_path = spark.conf.get("dlt_config")
target_table_schema = spark.conf.get("target_table_schema")
sql_file = spark.conf.get("sql_file")

# COMMAND ----------

# MAGIC %md
# MAGIC ### Functions

# COMMAND ----------


def get_dlt_config(dlt_config_path: str) -> Collection[dict[str, str]]:
    """Get DLT Config."""
    with open(f"{dlt_config_path}") as f:
        dlt_config = json.loads(f.read())
        return dlt_config


# COMMAND ----------


def create_dlt_table_with_lpi_row_filter(
    table_name: str,
    source_table: str,
    table_comment: str | None,
    table_schema: str | None,
    row_filter: str | None,
    primary_keys: list | None,
) -> None:
    """Create a Delta Live Table (DLT) from the source table.

    Args:
        table_name (str): Name of the DLT table to create.
        source_table (str): Name of the source table to read data from.
        table_comment (str): Table comment to describe the table.
        table_schema (str): Schema of the DLT materialized View.
        row_filter (str): Allows you to apply a row level filter to table definition.
        primary_keys (list): The primary key's defined for the table.

    Returns:
        None
    """

    @dlt.table(name=table_name, comment=table_comment, schema=table_schema, row_filter=row_filter)
    def table() -> None:
        df = spark.read.table(source_table)
        df = generate_table_id(df, primary_keys if primary_keys is not None else [])
        return df


# COMMAND ----------


# Get the DLT configuration from the specified path
dlt_config = get_dlt_config(dlt_config_path)

# Iterate over each configuration in the DLT config
for _config in dlt_config:
    """ Preparing source data  """

    # Prepare environment configuration with catalog and schema prefixes
    env_config = {"catalog_prefix": catalog_prefix, "schema_prefix": schema_prefix}

    # Merge environment config with SQL parameters from the pipeline config
    sql_params = {**env_config, **_config["pipeline_config"]["sql_params"]}  # type: ignore

    # Execute the SQL script with the provided parameters and get the source data as a DataFrame
    df_src_data = execute_sql_script(spark, sql_file=sql_file, params=sql_params)

    # Get the target table name from the configuration
    source_table_name = _config["target_table_name"]

    # Create or replace a temporary view with the source data
    df_src_data.createOrReplaceTempView(source_table_name)

    # Get the primary keys from the configuration, if any
    primary_keys_str = _config.get("primary_keys", "")

    # Create the table DDL and extract primary keys
    table_ddl_str, primary_keys = create_table_ddl(
        spark,
        primary_keys=primary_keys_str,
        target_table=f"{_config['target_table_name']}",
        src_table=source_table_name,
    )

    # Initialize the LPI filter as None
    lpi_filter = None

    # Apply LPI row filter
    lpi_filter = f"ROW FILTER {catalog_prefix}gold.{schema_prefix}weather.fx_row_filter_license ON (license)"

    # Create the Delta Live Table with the LPI row filter
    create_dlt_table_with_lpi_row_filter(
        _config["target_table_name"],
        source_table_name,
        _config["comment"],
        table_ddl_str,  # type: ignore
        lpi_filter,
        primary_keys,
    )
