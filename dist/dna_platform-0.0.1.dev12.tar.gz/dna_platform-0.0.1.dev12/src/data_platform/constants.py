from pathlib import Path

from pyspark.sql import types

metadata_table_schema = """
            id BIGINT,
            schema STRING,
            table_name STRING,
            dataset_name STRING,
            is_discoverable BOOLEAN DEFAULT TRUE,
            provider STRING,
            created_at STRING,
            source STRING,
            description STRING,
            source_type STRING,
            sector STRING,
            sub_sector STRING,
            covered_geographies STRING,
            data_owner STRING,
            data_steward STRING,
            data_classification STRING,
            last_update STRING,
            updated_by STRING,
            search_content STRING
            """


def get_src_root() -> Path:
    """Get the root directory of the source code.

    Returns:
        Path: The root directory of the source code.
    """
    return Path(__file__).parent.parent.parent


PACKAGE_VARS = "data_platform.vars"
PACKAGE_SQL = "data_platform.sql"

VALIDATION_DATA_STRUCTURE = types.StructType(
    [
        types.StructField("column", types.StringType(), True),
        types.StructField("dimension", types.StringType(), True),
        types.StructField("expectation_name", types.StringType(), True),
        types.StructField("priority", types.StringType(), True),
        types.StructField("status", types.StringType(), False),
        types.StructField("expectation_type", types.StringType(), False),
        types.StructField("unexpected_count", types.IntegerType(), False),
        types.StructField("element_count", types.IntegerType(), False),
        types.StructField("unexpected_percent", types.FloatType(), False),
        types.StructField("percent", types.FloatType(), False),
    ]
)

# Extend the base schema with additional fields
VALIDATION_TABLE_STRUCTURE = VALIDATION_DATA_STRUCTURE.add("timestamp", types.TimestampType(), True).add(
    "table_name", types.StringType(), True
)
