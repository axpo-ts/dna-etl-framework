from pyspark.sql import DataFrame

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.writer.config.dataclasses import BatchSQLWriterTaskConfig, StreamingSQLWriterTaskConfig
from data_platform.tasks.writer.utils import WriterUtilities


class StreamingSQLWriterTask(ETLTask):
    """Task for applying a SQL writer query to a streaming dataset.

    This class represents a task that uses a SQL query to write a streaming dataset to an output table based on
    the provided configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[StreamingSQLWriterTaskConfig]): The configuration dataclass.
    """

    task_name = "StreamingSQLWriterTask"
    dataclass = StreamingSQLWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the StreamingSQLWriterTask.

        Fetches data from the task context as a dataframe and then uses the provided SQL Query to stream that data to
        an output table.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.

        """
        _conf = self.start_task(context, conf)
        # Set the dataframe to view name
        context.logger.info("running Upsert To Delta")

        # Fetch the DataFrame from the task context
        df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)

        # Check if DataFrame is loaded and log its schema and row count
        if df is not None:
            context.logger.info("DataFrame successfully retrieved from task context.")
            context.logger.info(f"Task Context DataFrame schema: {df.schema}")
        else:
            context.logger.error("DataFrame retrieval failed from task context.")
            raise ValueError("No DataFrame found in task context with the specified namespace and key.")

        query = WriterUtilities.build_query(context, _conf)

        # Function to perform upserts using foreachBatch
        def upsert_to_delta(micro_batch_output_df: DataFrame, batch_id) -> None:  # noqa: ANN001
            # Set the dataframe to view name
            micro_batch_output_df.createOrReplaceTempView(_conf.df_alias)
            context.logger.info(f"Micro Batch DataFrame schema: {micro_batch_output_df.schema}")
            context.spark.sql(query)

        WriterUtilities.write_df_with_function(context, _conf, df, upsert_to_delta)


class BatchSQLWriterTask(ETLTask):
    """Task for applying a SQL writer query to a dataset.

    This class represents a task that uses a SQL query to write a batch dataset to an output table based on the provided
    configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[BatchSQLWriterTaskConfig]): The configuration dataclass.
    """

    task_name = "BatchSQLWriterTask"
    dataclass = BatchSQLWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the BatchSQLWriterTask.

        Fetches data from the task context as a dataframe and then uses the provided SQL Query to write that data to
        an output table.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.

        """
        # Set the dataframe to view name
        _conf = self.start_task(context, conf)

        df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
        df.createOrReplaceTempView(_conf.df_alias)
        query = WriterUtilities.build_query(context, _conf)
        context.spark.sql(query)  # type: ignore
