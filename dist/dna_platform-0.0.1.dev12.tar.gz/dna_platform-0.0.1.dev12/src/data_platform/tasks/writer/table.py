import pyspark.sql.functions as f  # noqa: I001
from delta import DeltaTable
from data_platform.tasks.utils import CatalogUtilities
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.writer.config.dataclasses import (
    CloneTableTaskConfig,
    SimpleStreamingUpsertConfig,
    SimpleStreamingWriteConfig,
)


from pyspark.sql import DataFrame

from data_platform.tasks.writer.utils import WriterUtilities
from data_platform.etl.transform.transform import add_audit_cols_snake_case


class SimpleBatchWriterTask(ETLTask):
    """Task for writing batch data to an output table, usually delta format.

    This class represents a task that writes batch data to an output table based on the provided configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleStreamingWriteConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the SimpleBatchWriterTask by writing the input DataFrame
            to the specified output table in the datalake.

    """

    task_name: str = "SimpleBatchWriterTask"
    dataclass = SimpleStreamingWriteConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchWriterTask.

        Writes extracts data from the task context as a dataframe and then writes that data to a table.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        # get final table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        # write data to table
        context.logger.info(f"Writing the dataframe to table: {table_name}")
        df: DataFrame = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)
        (df.write.format(_conf._format).mode(_conf.output_mode).options(**_conf.writer_options).saveAsTable(table_name))

        # updating the metadata
        context.logger.info("Updating the metadata")


class SimpleStreamingWriterTask(ETLTask):
    """Task for writing streaming data to an output table.

    This class represents a task that writes streaming data to an output table based on the provided configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleStreamingWriteConfig]): The configuration dataclass.
    """

    task_name = "SimpleStreamingWriterTask"
    dataclass = SimpleStreamingWriteConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleStreamingWriterTask.

        Extracts data from the task context as a dataframe and writes it to a table as a stream.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        # Construct the final table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)
        context.logger.info(f"Target table: {table_name}")

        # Retrieve the DataFrame from the task context
        df: DataFrame = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)

        # Initialize streaming writer
        base_write = df.writeStream.format(_conf._format).options(**_conf.writer_options)

        # Apply partitioning if specified
        partition_cols = _conf.writer_options.get("partition_cols")
        if partition_cols:
            base_write = base_write.partitionBy(partition_cols)

        # Log and execute the write operation
        context.logger.info(f"Writing the dataframe to {table_name} using format {_conf._format}")

        if _conf._format == "delta":
            context.logger.info(">>>>>>>>>>>> Writing to Delta")
            base_write.trigger(availableNow=True).outputMode(_conf.output_mode).toTable(table_name).awaitTermination()

        elif _conf._format == "memory":
            context.logger.info(">>>>>>>>>>>> Writing to Memory")
            base_write = base_write.queryName(f"q_{_conf.table_name}")
            base_write.trigger(availableNow=True).outputMode(_conf.output_mode).start().awaitTermination()

            # Create or replace the temporary view
            df.createOrReplaceTempView(f"vw_{_conf.table_name}")


class SimpleBatchUpsertChangesTask(ETLTask):
    """Task for upserting batch data to a delta table.

    This class handles the upserting of batch data into an output Delta table.
    If `use_append` is set to True, it identifies:
    - New records (where `created_at` equals `updated_at`) and inserts them.
    - Updated records (where `created_at` does not equal `updated_at`) and performs an upsert operation on those.

    If `use_append` is set to False, the task performs a simple merge.

    Attributes:
        task_name (str): The name of the task.
        dataclass (SimpleStreamingUpsertConfig): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the SimpleBatchWriterTask by writing the input DataFrame
            to the specified output table in the datalake.

    Note:
        Ensure to use `use_append` only if the records being promoted from source to target do not use
        the default `watermark_days: x`, as this parameter always promotes those records.

    """

    task_name: str = "SimpleBatchUpsertChangesTask"
    dataclass = SimpleStreamingUpsertConfig

    def _upsert_records(
        self, target: DeltaTable, source_df: DataFrame, update_columns: list[str], conf: SimpleStreamingUpsertConfig
    ) -> None:
        """Perform the upsert operation on the target table.

        Args:
            target: The target Delta table.
            source_df: The DataFrame containing records to upsert.
            update_columns: The list of columns to update.
            conf: Configuration dataclass.
        """
        insert_mapping_dict = {f"t.{col}": f"s.{col}" for col in source_df.columns if col not in [*conf.ignore_columns]}

        (
            target.alias("t")
            .merge(source_df.alias("s"), " AND ".join(f"t.{col} = s.{col}" for col in conf.primary_keys))
            .whenMatchedUpdate(
                f.expr(" OR ".join(f"t.{col} IS DISTINCT FROM s.{col}" for col in update_columns)),
                set={col: f"s.{col}" for col in [*update_columns, *conf.updated_columns]},
            )
            .whenNotMatchedInsert(values={k: f.col(v) for k, v in insert_mapping_dict.items()})
            .execute()
        )

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchUpsertChangesTask.

        Extracts data from the task context as a dataframe and then upsert it to a delta table.
        It only add modified rows as well as new rows.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        target = CatalogUtilities.get_target_deltatable(context, _conf)
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        # find the columns that need updating
        update_columns = WriterUtilities.build_update_column_list(
            target, [*_conf.primary_keys, *_conf.created_columns, *_conf.updated_columns, *_conf.ignore_columns]
        )
        context.logger.info(f"List of columns to update: {update_columns}")

        # get the dataframe from the task context
        source_df = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)
        writer_options = dict(getattr(_conf, "writer_options", {}) or {})
        merge_schema_option = writer_options.get("mergeSchema")
        auto_merge_original: str | None = None
        try:
            if merge_schema_option is not None:
                auto_merge_original = context.spark.conf.get("spark.databricks.delta.schema.autoMerge.enabled", None)
                context.spark.conf.set(
                    "spark.databricks.delta.schema.autoMerge.enabled", str(merge_schema_option).lower()
                )
            if _conf.drop_duplicates:
                context.logger.info(f"dropping duplicates based on primary keys: {_conf.primary_keys}")
                source_df = source_df.dropDuplicates([*_conf.primary_keys])
            if _conf.use_append:
                new_records_df = source_df.filter(source_df.created_at == source_df.updated_at)
                updated_records_df = source_df.filter(source_df.created_at != source_df.updated_at)

                new_records_df = add_audit_cols_snake_case(df=new_records_df, logger=context.logger)
                updated_records_df = add_audit_cols_snake_case(df=updated_records_df, logger=context.logger)

                if not new_records_df.isEmpty():
                    context.logger.info(f"Inserting new records to {table_name}")
                    write_builder = new_records_df.write.format("delta").mode("append")
                    if writer_options:
                        write_builder = write_builder.options(**writer_options)
                    write_builder.saveAsTable(table_name)
                    context.spark.catalog.refreshTable(table_name)

                if not updated_records_df.isEmpty():
                    context.logger.info(f"Updating records to {target} table")
                    # Reload DeltaTable object to ensure we pick up latest transaction log state
                    target = CatalogUtilities.get_target_deltatable(context, _conf)
                    self._upsert_records(target, updated_records_df, update_columns, _conf)
            else:
                context.logger.info(f"Performing a simple merge into {target} table")
                self._upsert_records(target, source_df, update_columns, _conf)
        finally:
            if merge_schema_option is not None:
                if auto_merge_original is None:
                    context.spark.conf.unset("spark.databricks.delta.schema.autoMerge.enabled")
                else:
                    context.spark.conf.set("spark.databricks.delta.schema.autoMerge.enabled", auto_merge_original)


class SelectiveOverwriteTask(ETLTask):
    """Task for Select overwrite batch data to a delta table.

    This class represents a task that Selectively orverwrite data based on expression to an output delta table.
    It overwrites on Partition Boundaries, so the Table should have been Partitioned.

    Attributes:
        task_name (str): The name of the task.
        dataclass (SimpleStreamingWriteConfig): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the SelectiveOverwriteTask by overwriting the input DataFrame
            data to the specified output table in the datalake.

    """

    task_name: str = "SelectiveOverwriteTask"
    dataclass = SimpleStreamingWriteConfig

    def write_to_target_table(
        self, df: DataFrame, mode: str, table_name: str, partition_col: str, replace_clause: str = ""
    ) -> None:
        """Execute the write_to_target_table.

        Function that can be reused to write into table based on condition.

        Attributes:
            df (DataFrame): Data to write into table.
            mode (str): Append/overwrite mode.
            table_name (str) : Table to write into.
            partition_cols (str) : Any Partition Columns for the table.
            replace_clause (str) : Clause to selectively overwrite.

        """
        write_operation = df.write.mode(mode).format("delta")
        if partition_col:
            write_operation = write_operation.partitionBy(partition_col)
        if replace_clause:
            write_operation = write_operation.option("replaceWhere", replace_clause)
        write_operation.saveAsTable(table_name)

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SelectiveOverwriteTask.

        Extracts data from the task context as a dataframe and then overwrite selectively it to a delta table.
        It only overwrites the rows matching the expression specified in replaceWhere.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        # get final table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        # write data to table
        context.logger.info(f"Upserting the dataframe to table: {table_name}")

        # get the dataframe from the task context
        source_df = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)

        partition_cols = ""
        if "partition_cols" in _conf.writer_options and _conf.writer_options.get("partition_cols"):
            if "partition_expression" in _conf.writer_options and _conf.writer_options.get("partition_expression"):
                partition_cols = _conf.writer_options["partition_cols"]
                source_df = source_df.withColumn(partition_cols, f.expr(_conf.writer_options["partition_expression"]))

        predicate_cols_list = partition_cols.split(",")

        if context.spark.catalog.tableExists(table_name) and (
            (not context.spark.read.table(table_name).head(1)) or (not source_df.head(1))
        ):
            context.logger.info("Appending into Table if Source Dataframe or Target Table are Empty")
            self.write_to_target_table(source_df, "append", table_name, partition_cols)

        else:
            if any(element == "" for element in predicate_cols_list) > 1:
                context.logger.info(f"Predicate Columns to replace seems empty: {predicate_cols_list}")
                raise ValueError("Predicate Columns to replace on the table is empty.")

            replace_where = " OR ".join(
                [
                    "(" + " AND ".join([f"{col}='{i[col]}'" for col in predicate_cols_list]) + ")"
                    for i in source_df.select(*predicate_cols_list).dropDuplicates(predicate_cols_list).collect()
                ]
            )
            context.logger.info(f"replace where expression: {replace_where}")
            self.write_to_target_table(source_df, _conf.output_mode, table_name, partition_cols, replace_where)


class SimpleStreamingUpsertChangesTask(ETLTask):
    """Task for upserting stream data to a delta table.

    This class represents a task that upserts batch data to an output delta table.

    Attributes:
        task_name (str): The name of the task.
        dataclass (SimpleStreamingUpsertConfig): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the SimpleBatchWriterTask by writing the input DataFrame
            to the specified output table in the datalake.

    """

    task_name: str = "SimpleStreamingUpsertChangesTask"
    dataclass = SimpleStreamingUpsertConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleStreamingUpsertChangesTask.

        Extracts data from the task context as a dataframe and then upsert it to a delta table.
        It only add modified rows as well as new rows.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        # CPD-OFF - ignore to distinguish between streaming and batch methods
        _conf = self.start_task(context, conf)

        target = CatalogUtilities.get_target_deltatable(context, _conf)

        # find columns that need updating
        update_columns = WriterUtilities.build_update_column_list(
            target, [*_conf.primary_keys, *_conf.created_columns, *_conf.updated_columns, *_conf.ignore_columns]
        )
        # Considers the Target columns to insert into delta table
        insert_columns = target.toDF().columns

        context.logger.info(f"List of columns to update: {update_columns}")
        # CPD-ON - ignore to distinguish between streaming and batch methods

        # def microbatch function to upsert the data
        def upsert_to_delta(micro_batch_df: DataFrame, batch_id: int) -> None:
            if _conf.drop_duplicates:
                micro_batch_df = micro_batch_df.dropDuplicates([*_conf.primary_keys])

            context.logger.info(f"Micro batch id: {batch_id}")
            # CPD-OFF - excluding from copy paste detection - query is different
            (
                target.alias("t")
                .merge(micro_batch_df.alias("s"), " AND ".join(f"t.{col} = s.{col}" for col in _conf.primary_keys))
                .whenMatchedUpdate(
                    f.expr(" OR ".join(f"t.{col} IS DISTINCT FROM s.{col}" for col in update_columns)),
                    set={col: f"s.{col}" for col in [*update_columns, *_conf.updated_columns]},
                )
                .whenNotMatchedInsert(
                    values={col: f"s.{col}" for col in insert_columns if col not in [*_conf.ignore_columns]}
                )
                .execute()
            )
            # CPD-ON - resume copy paste detection

        # get the dataframe from the task context
        df = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)

        WriterUtilities.write_df_with_function(context, _conf, df, upsert_to_delta)


class CloneTableTask(ETLTask):
    """Task for creating a clone table.

    This class represents a task that uses a SQL query to clone
    a source table to a target location based on the provided configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[CloneTableTaskConfig]): The configuration dataclass.
    """

    task_name = "CloneTableTask"
    dataclass = CloneTableTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the CloneTableTask.

        Builds a SQL query using the configuration data to clone the desired table.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.

        """
        # Set the dataframe to view name
        _conf = self.start_task(context, conf)

        # get final table name
        source_table_name = CatalogUtilities.build_table_name(
            _conf.source_catalog, _conf.source_schema_name, _conf.source_table_name
        )

        target_table_name = CatalogUtilities.build_table_name(
            _conf.target_catalog, _conf.target_schema_name, _conf.target_table_name
        )

        query = f"CREATE OR REPLACE TABLE {target_table_name} {_conf.clone_type} CLONE {source_table_name}"

        if _conf.table_properties:
            table_properties_sql = (
                " TBLPROPERTIES("
                + ", ".join(
                    [f"{k}='{v}'" if isinstance(v, str) else f"{k}={v}" for k, v in _conf.table_properties.items()]
                )
                + ")"
            )
            query += table_properties_sql

        if _conf.location:
            location_sql = f" LOCATION {_conf.location}"
            query += location_sql

        context.spark.sql(query)
        # insert_metadata(_conf=_conf, context=context) #TODO: review this


class SimpleType2MergeTask(ETLTask):
    """Task for performing merge into Type 2 delta table.

    Attributes:
    task_name (str): The name of the task.
    dataclass (SimpleStreamingUpsertConfig): The configuration dataclass.

    Methods:
    execute(self, context: TaskContext, conf: Configuration):
        Execute the SimpleType2MergeTask by mering the input DataFrame
        to the specified output table in the datalake.
    upsert_existing(source_df: DataFrame, target_df: DataFrame) -> None:
        Function for inserting new records and setting currency of matching records to False
    insert_new(source_df: DataFrame, target_df: DataFrame) -> None:
        Function for inserting new current version of matching records where data is different.
    """

    task_name: str = "SimpleType2MergeTask"
    dataclass = SimpleStreamingUpsertConfig

    def upsert_existing(
        self,
        source_df: DataFrame,
        target_df: DataFrame,
        primary_keys: str | list[str],
        update_columns: str | list[str],
        insert_mapping_dict: dict[str, str],
    ) -> None:
        """Function for inserting new records and setting currency of matching records to False
        where the source and target records are different.

        Attributes:
            source_df: DataFrame Incoming data to be merged.
            target_df: DataFrame Target table to be merged into.
            primary_keys: List of primary keys to be used for matching records.
            update_columns: List of columns to be updated in the target table.
        """  # type: ignore # noqa: D205
        target_df.alias("t").merge(
            source_df.alias("s"),
            " AND ".join(f"t.{col} = s.{col}" for col in primary_keys) + " AND t.is_current = True",
        ).whenMatchedUpdate(
            condition=f.expr(" OR ".join(f"t.{col} != s.{col}" for col in update_columns)),
            set={"is_current": f.lit(False), "valid_to": f.current_timestamp()},
        ).whenNotMatchedInsert(
            values={
                **{k: f.col(v) for k, v in insert_mapping_dict.items()},
                "valid_from": f.current_timestamp(),
                "valid_to": f.lit(None),
                "is_current": f.lit(True),
            }
        ).execute()

    def insert_new(
        self,
        source_df: DataFrame,
        target_df: DataFrame,
        primary_keys: str | list[str],
        insert_mapping_dict: dict[str, str],
        context: TaskContext,
        conf: Configuration,
    ) -> None:
        """Function for inserting new current version of matching records where data is different.

        This function is used to insert new records into the target table and set the current_flag to True
        for the new records.
        It also sets the start_date to the current timestamp and end_date to None.

        Attributes:
            source_df: DataFrame Incoming data to be merged.
            target_df: DataFrame Target table to be merged into.
            primary_keys: List of primary keys to be used for matching records.
            update_columns: List of columns to be updated in the target table.
        """
        target_df = CatalogUtilities.get_target_deltatable(context, conf)
        # CPD-OFF - excluding from copy paste detection - query is different
        target_df.alias("t").merge(
            source_df.alias("s"),
            " AND ".join(f"t.{col} = s.{col}" for col in primary_keys) + " AND t.is_current = True",
        ).whenNotMatchedInsert(
            values={
                **{k: f.col(v) for k, v in insert_mapping_dict.items()},
                "valid_from": f.current_timestamp(),
                "valid_to": f.lit(None),
                "is_current": f.lit(True),
            },
        ).execute()
        # CPD-ON - resume copy paste detection

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchUpsertChangesTask.

        Extracts data from the task context as a dataframe and then upsert it to a delta table.
        It only add modified rows as well as new rows.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        target = CatalogUtilities.get_target_deltatable(context, _conf)

        ignore_lineage_cols = ["valid_from", "valid_to", "is_current"]
        _conf.ignore_columns = [*ignore_lineage_cols, *_conf.ignore_columns]

        # identify value columns to be updated
        update_columns = WriterUtilities.build_update_column_list(
            target,
            [
                *_conf.primary_keys,
                *_conf.created_columns,
                *_conf.updated_columns,
                *_conf.ignore_columns,
            ],
        )
        context.logger.info(f"List of columns to update: {update_columns}")

        # get the dataframe from the task context

        source_df = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)
        insert_df = source_df.columns
        mapping_dict = {f"t.{cl}": f"s.{cl}" for cl in insert_df if cl not in [*_conf.ignore_columns]}

        self.upsert_existing(source_df, target, _conf.primary_keys, update_columns, mapping_dict)
        context.logger.info("usperting existing records")
        self.insert_new(source_df, target, _conf.primary_keys, mapping_dict, context, _conf)
        context.logger.info("inserting new version records")
