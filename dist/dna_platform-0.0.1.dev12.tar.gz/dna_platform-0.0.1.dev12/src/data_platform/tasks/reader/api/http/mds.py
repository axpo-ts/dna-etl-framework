import asyncio
import gc
import json
from datetime import datetime
from typing import Any

import httpx
from tenacity import retry, stop_after_attempt, wait_exponential

from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BearerApiReaderConfig


class MdsBearerApiBulkReaderWriterTask(ETLTask):
    """Task for downloading API data from an endpoint and saving the JSON response into a DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass: Configuration dataclass for API reader.
    """

    task_name = "MdsBearerApiBulkReaderWriterTask"
    dataclass = BearerApiReaderConfig

    # CPD-OFF - Method Signature to Just make the API call which is called by the retry decorator

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def fetch_data(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        params: list[dict[str, Any]] | dict[str, Any],
        headers: dict[str, str],
        context: TaskContext,
        timeout: int,
        resource_id: int | None = None,
    ) -> httpx.Response:
        """Fetch data from the API asynchronously with automatic retry.

        Args:
            client (httpx.AsyncClient): The HTTP client used for making requests.
            method (str): The HTTP method to use (e.g., GET, POST).
            url (str): The API endpoint URL.
            params (list[dict[str, Any]] | dict[str, Any]): Parameters to send with the request.
            headers (dict[str, str]): Headers for the request, including authorization.
            context (TaskContext): The context containing logger and task properties.
            timeout (int): The timeout value for the request in seconds.
            resource_id (int | None): The ID of the resource being requested, used for logging.

        Returns:
            httpx.Response: The JSON response from the API.

        Raises:
            Exception: For any exceptions during the request after all retries.
        """
        # CPD-ON - End of Method Signature to Just make the API call which is called by the retry decorator
        try:
            context.logger.info(f"Making request to {url}")
            response = await client.request(method, url, json=params, headers=headers, timeout=timeout)
            # Always raise for status to trigger retry for any non-200 responses
            response.raise_for_status()
            return response
        except httpx.HTTPStatusError as e:
            # Log all HTTP errors with appropriate severity but always retry
            context.logger.warning(
                f"HTTP error occurred for resource_id {resource_id}: {e.response.status_code} - "
                f"{e.response.reason_phrase}. Response text: {e.response.text[:200]}. Will retry."
            )
            raise e
        except Exception as e:
            context.logger.warning(f"Request error for resource_id={resource_id}: {e}. Will retry.")
            raise e

    async def execute_async(self, context: TaskContext, conf: Configuration) -> None:
        """Asynchronously execute the API reader task.

        Args:
            context (TaskContext): The context containing logger and task properties.
            conf (Configuration): Configuration object for API reader settings.

        Raises:
            ValueError: If any errors occur during execution.
        """
        _conf = self.start_task(context, conf)
        concurrent_requests = int(_conf.api_time_window["concurrent_requests"])

        # Determine if task should fail on any request failure
        fail_on_error = bool(_conf.api_time_window.get("fail_on_error", False))
        context.logger.info(f"Task will {'fail' if fail_on_error else 'continue'} if individual requests fail")

        access_token = context.get_property(namespace=_conf.secret_namespace, key=_conf.access_token_key)
        headers = {"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"}
        time_blocks = self.get_time_blocks(context, _conf)

        # Configure client with limits and HTTP/2 support
        limits = httpx.Limits(max_connections=concurrent_requests, max_keepalive_connections=concurrent_requests)
        transport = httpx.AsyncHTTPTransport(http2=True)

        total_blocks = len(time_blocks)
        # Handle the case where there are no time blocks
        if total_blocks == 0:
            context.logger.warning("No time blocks available for API requests. Exiting.")
            return  # Exit early
        context.logger.info(f"Starting {total_blocks} API requests with concurrent limit of {concurrent_requests}")

        # Track statistics without storing all results in memory
        success_count = []
        error_count = []

        # Process API requests in smaller batches to control memory usage
        batch_size = min(concurrent_requests, total_blocks)  # Adjust batch size based on memory constraints
        for i in range(0, total_blocks, batch_size):
            batch = time_blocks[i : i + batch_size]
            context.logger.info(
                f"Processing batch {i // batch_size + 1}/{(total_blocks + batch_size - 1) // batch_size}, "
                f"size: {len(batch)}"
            )

            async with httpx.AsyncClient(limits=limits, transport=transport) as client:
                batch_success, batch_errors = await self._process_api_requests_batch(
                    client, batch, headers, _conf, context, fail_on_error
                )

                success_count.extend(batch_success)
                error_count.extend(batch_errors)

                # Force garbage collection after each batch
                gc.collect()

        # Check if we should fail the task due to errors
        if len(error_count) > 0:
            error_msg = f"Task soft failure due to ids {error_count} failed"
            context.logger.error(error_msg)

        # Log summary of results
        context.logger.info(f"Completed API requests: {len(success_count)} successful, {len(error_count)} failed")

    async def _process_api_requests_batch(
        self,
        client: httpx.AsyncClient,
        time_blocks: list[dict[str, Any]],
        headers: dict[str, str],
        config: BearerApiReaderConfig,
        context: TaskContext,
        fail_on_error: bool = False,
    ) -> tuple[list[int], list[int]]:
        """Process a batch of API requests and write responses as they arrive.

        Args:
            client (httpx.AsyncClient): The HTTP client for making requests.
            time_blocks (list[dict[str, Any]]): Batch of time blocks to process.
            headers (dict[str, str]): Headers for API requests.
            config (BearerApiReaderConfig): Configuration for API requests.
            context (TaskContext): Task execution context.
            fail_on_error (bool): Whether to raise exception on first error.

        Returns:
            tuple[list[int], list[int]]: A tuple containing lists of successful and failed resource IDs.
                The first list contains resource IDs of successful requests, and the second list contains
                resource IDs of failed requests.
                The lists are empty if no requests were made.

        Raises:
            Exception: If fail_on_error is True and any request fails.
        """
        tasks = []
        for block in time_blocks:
            params = self.prepare_params(block, config.api_name or "")
            task = asyncio.create_task(
                self._fetch_and_write(
                    client,
                    config.api_method or "",
                    config.api_url,
                    params,
                    headers,
                    context,
                    int(config.api_time_window["timeout"]),
                    block,
                    config,
                )
            )
            tasks.append(task)

        # Process tasks as they complete, without accumulating results in memory
        success_count = []
        error_count = []

        # Use as_completed to process responses as they arrive
        for future in asyncio.as_completed(tasks):
            task = asyncio.ensure_future(future)
            try:
                result = await task
                if result[0] is True:
                    success_count.append(result[1])
                else:
                    error_count.append(result[1])
            except Exception as e:
                context.logger.error(f"Batch request failed: {e}")
                error_count += [1]
                if fail_on_error:
                    # Cancel remaining tasks
                    for remaining_task in tasks:
                        if not remaining_task.done():
                            remaining_task.cancel()
                    raise ValueError(f"Task batch failed: {e}")

        return success_count, error_count

    async def _fetch_and_write(
        self,
        client: httpx.AsyncClient,
        method: str,
        url: str,
        params: list[dict[str, Any]] | dict[str, Any],
        headers: dict[str, str],
        context: TaskContext,
        timeout: int,
        block: dict[str, Any],
        config: BearerApiReaderConfig,
    ) -> tuple[bool, int]:
        """Fetch data and write it directly to volume without storing full result set in memory.

        Args:
            client (httpx.AsyncClient): The HTTP client for making requests.
            method (str): HTTP method to use.
            url (str): The API endpoint URL.
            params (list[dict[str, Any]] | dict[str, Any]): Request parameters.
            headers (dict[str, str]): Request headers.
            context (TaskContext): Task execution context.
            timeout (int): Request timeout in seconds.
            block (dict[str, Any]): Time block information.
            config (BearerApiReaderConfig): Configuration for API reader.

        Returns:
            bool: True if successful, False otherwise.
            int: Resource ID associated with the request.
        """
        if config.api_url and "streaming" in config.api_url.lower():
            resource_id = -1
        else:
            resource_id = block["resource_id"]

        try:
            context.logger.info(
                f"Making a {config.api_method} call for resource ID: {resource_id} or curve: {block['curve']} "
                f"with params: {params}"
            )
            response = await self.fetch_data(client, method, url, params, headers, context, timeout, resource_id)

            # Handle streaming for successful responses
            if response.status_code == 200:
                # Write to volume immediately to free memory
                self.write_to_volume(
                    context,
                    config,
                    response,
                    block["curve"],
                    block.get("start_time", None),
                    block.get("end_time", None),
                    resource_id,
                    block.get("block_num", 0),  # pass block_num
                )
                # Clear reference to potentially large response data
                del response
                return (True, resource_id)
            else:
                context.logger.error(f"Received non-200 response for resourceID: {resource_id}: {response.status_code}")
                return (False, resource_id)

        except Exception as e:
            context.logger.error(
                f"Failed request for resource ID: {resource_id} from "
                f"{block.get('start_time', 'N/A')} to {block.get('end_time', 'N/A')}: {e!s}"
            )
            return (False, resource_id)

    def prepare_params(self, block: dict[str, Any], api_name: str) -> list[dict[str, Any]] | dict[str, Any]:
        """Prepare parameters for the API request based on the time block and API name.

        Args:
            block (dict): A dictionary containing time block details.
            api_name (str): The name of the API being called.

        Returns:
            list[dict[str, Any]] | dict[str, Any]: The prepared parameters for the API request.
        """
        if api_name == "MDS":
            return [
                {
                    "Ids": [int(rid) for rid in block["resource_id"]]
                    if isinstance(block["resource_id"], list)
                    else [int(block["resource_id"])],
                    "Filters": {
                        "Expressions": [
                            f"ReferenceTime >= {block['start_time']}",
                            f"ReferenceTime < {block['end_time']}",
                        ]
                    },
                }
            ]
        return {"Filters": [f"MdoId = {int(block['resource_id'])}"], "Properties": []}

    def get_time_blocks(self, context: TaskContext, config: BearerApiReaderConfig) -> list[dict[str, Any]]:
        """Retrieve time blocks based on API name.

        Args:
            context (TaskContext): The context containing logger and task properties.
            config (BearerApiReaderConfig): Configuration object for API reader settings.

        Returns:
            list[dict[str, Any]]: A list of time blocks for the API request.
        """
        if config.api_name == "MDS":
            time_blocks = context.get_property(namespace=config.df_namespace, key=config.df_key)
            context.logger.info(f"Retrieved {len(time_blocks)} time blocks.")
        else:  # Assuming only "MDS metadata" is the alternative
            time_blocks = self.fetch_attributes(
                config.api_time_window["attributes_config"], config.api_time_window["volume_name"]
            )
        return time_blocks

    def fetch_attributes(self, config_path: str, volume_name: str) -> list[dict[str, Any]]:
        """Fetch attributes from a configuration JSON file.

        Args:
            config_path (str): Path to the configuration JSON file.
            volume_name (str): Name of the volume to associate with the attributes.

        Returns:
            list[dict[str, Any]]: A list of attributes with the associated volume name.
        """
        with open(config_path) as f:
            attributes_list = json.load(f)
        attributes = [
            {"resource_id": str(item["resource_id"])} for sublist in attributes_list.values() for item in sublist
        ]
        for item in attributes:
            item["curve"] = volume_name
        return attributes

    def write_to_volume(
        self,
        context: TaskContext,
        conf: BearerApiReaderConfig,
        response: httpx.Response,
        volume_curve: str,
        start_time: str,
        end_time: str,
        resource_id: int,
        block_num: int,
    ) -> None:
        """Write the API response data to a specified volume.

        Args:
            context (TaskContext): The context containing logger and task properties.
            conf (BearerApiReaderConfig): Configuration object for API reader settings.
            response (httpx.Response): The HTTP response object to write.
            volume_curve (str): The name of the volume curve to write to.
            start_time (str): The start time of the time block.
            end_time (str): The end time of the time block.
            resource_id (int): The resource ID associated with the response data.
            block_num (int): Unique block number to avoid filename collisions.

        Raises:
            ValueError: If there is an error writing to the volume.
        """
        volume_location = (
            f"/Volumes/{conf.api_time_window['catalog_name']}/{conf.api_time_window['schema_name']}/{volume_curve}"
        )

        timestamp = datetime.now().strftime("%Y%m%d%H%M%S") if conf.api_time_window["add_timestamp"] else ""
        startdate = datetime.strptime(start_time, "%Y-%m-%dT%H:%M:%S").strftime("%Y%m%d") if start_time else ""
        enddate = datetime.strptime(end_time, "%Y-%m-%dT%H:%M:%S").strftime("%Y%m%d") if end_time else ""

        file_name_parts = []

        # Construct the base file name
        if resource_id != -1:
            file_name_parts.append(str(resource_id))

        # Add timestamp if available
        if timestamp:
            file_name_parts.append(timestamp)

        # Add startdate and enddate if they are not None
        if startdate and enddate:
            file_name_parts.append(startdate)
            file_name_parts.append(enddate)

        # Add block number to ensure uniqueness
        file_name_parts.append(f"block{block_num}")

        # Join parts with underscore and append the .json extension
        file_name = "_".join(file_name_parts) + ".json"
        file_location = f"{volume_location}/{conf.api_time_window['file_name_prefix']}{file_name}"

        try:
            if conf.api_url and "streaming" in conf.api_url.lower():
                with open(file_location, "wb") as file:  # Open as binary for streaming
                    context.logger.info("writing response in chunks for streaming endpoint")
                    for chunk in response.iter_bytes(chunk_size=8192):
                        if chunk:
                            file.write(chunk)

            elif json.loads(str(conf.api_time_window["use_dbutils"]).lower()):
                dbutils = get_dbutils(context.spark)
                # Write directly without keeping the JSON string in memory
                dbutils.fs.put(file_location, json.dumps(response.json()), overwrite=True)  # type: ignore
            else:
                # write to file to reduce memory usage
                context.logger.info("writing response json for non-streaming endpoint")
                data = response.json()
                if isinstance(data, dict):
                    has_data = len(data.get("TransactionalData", [])) > 0
                elif isinstance(data, list):
                    has_data = len(data) > 0
                else:
                    has_data = False
                if has_data:
                    with open(file_location, "w") as file:
                        json.dump(data, file)
                    context.logger.info(f"Inserted file at {file_location}")
                else:
                    context.logger.warning(f"No data found in response for Id: {resource_id}. Skipping file write")

        except Exception as e:
            context.logger.error(f"Error writing to volume {file_location}: {e}")
            raise ValueError(f"Error writing to volume {file_location}: {e}")

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Synchronous execution method that runs the task.

        Args:
            context (TaskContext): Context object with logger and Spark session.
            conf (Configuration): Configuration object for API reader settings.

        Raises:
            ValueError: Raised for issues with authentication, HTTP method, or response handling.
        """
        try:
            asyncio.run(self.execute_async(context, conf))
        except Exception as e:
            context.logger.error(f"Error during execution: {e}")
            raise ValueError(f"Error during execution: {e}")
