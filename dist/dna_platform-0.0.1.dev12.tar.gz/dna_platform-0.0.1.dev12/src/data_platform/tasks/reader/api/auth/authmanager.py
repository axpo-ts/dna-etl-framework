from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.auth.azure import AzureOauthTask
from data_platform.tasks.reader.api.auth.config.dataclasses import OAuthConfig
from data_platform.tasks.transform.config.dataclasses import DatabricksApiConfig


class AzureOAuthTokenManager:
    """Class to manage OAuth token retrieval using AzureOAuthTask."""

    def __init__(self) -> None:
        """Initializes the token manager with context and configuration."""
        self.dataclass = OAuthConfig

    def obtain_access_token(self, context: TaskContext, config: DatabricksApiConfig) -> None:
        """Obtains the access token using AzureOAuthTask."""
        try:
            oauth_task = AzureOauthTask()  # Instantiate the AzureOAuthTask
            oauth_task.execute_token_request(context, config)
        except Exception as e:
            context.logger.error(f"Error while obtaining access token: {e}")
            raise  # Optionally re-raise the exception for further handling
