import json
from typing import Any

from requests import Response

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import ApiReaderConfig, BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy
from data_platform.tasks.reader.api.utils import execute_http_request


class RequestsApiReaderTask(ETLTask):
    """Task for reading from a given API.

    Attributes:
        task_name (str): The name of the task.
        api_url (str): Full API url.

    """

    task_name = "RequestsApiReaderTask"
    timeout = 0
    verify = False

    def __init__(self) -> None:
        """Setup http_headers to implement in init block."""
        self.http_headers: list[HttpHeaderStrategy] = []
        self.dataclass = ApiReaderConfig

    def execute(self, context: TaskContext, conf: Configuration, params: dict | None = None) -> None:
        """DRY block to orchestrate the creation of the HTTP request and response processing."""
        _conf = self.start_task(context, conf)

        _conf = self.override_config(context, _conf)

        payload = self.prepare_request(context, _conf)

        params = self.prepare_params(context, _conf, params)

        response = self.execute_request(context, _conf, payload, params=params)

        content = self.extract_content(context, _conf, response)

        self.handle_response(context, _conf, content)

    def override_config(self, context: TaskContext, conf: Any) -> Any:
        """Hook to be able to override parsed config."""
        return conf

    def prepare_request(self, context: TaskContext, conf: BaseApiReaderConfig) -> dict:
        """Override in implementations to prepare the request to send."""
        return {}

    def prepare_params(
        self, context: TaskContext, conf: BaseApiReaderConfig, params: dict | None = None
    ) -> dict | None:
        """DRY Reusable block to send prepare parameters."""
        return params

    def execute_request(
        self, context: TaskContext, conf: BaseApiReaderConfig, payload: dict, params: dict | None = None
    ) -> Response:
        """DRY Reusable block to send HTTP requests."""
        return execute_http_request(context, conf, payload, self.http_headers, self.timeout, self.verify, params=params)

    def extract_content(self, context: TaskContext, conf: BaseApiReaderConfig, response: Response) -> object:
        """Override in implementations to extract response to return."""
        if conf.return_content_type == "text":
            return response.text
        elif conf.return_content_type == "content":
            return response.content
        else:
            raise ValueError(f"Unsupported content type: {conf.return_content_type}")

    def handle_response(self, context: TaskContext, conf: BaseApiReaderConfig, content: Any) -> None:
        """Handle the API response content."""
        if conf.df_key and conf.df_namespace:
            context.put_property(namespace=conf.df_namespace, key=conf.df_key, value=content)
            context.logger.info(f"Data saved to namespace '{conf.df_namespace}' with key '{conf.df_key}'")
        elif conf.volume_storage_path:
            self.save_to_volume(content, context, conf)
        else:
            context.logger.warning("Neither df_key and df_namespace nor volume_storage_path is set.")

    def save_to_volume(self, content: Any, context: TaskContext, conf: BaseApiReaderConfig) -> None:
        """Override in implementations to save to volume or table as appropriate."""


class JsonResponseApiReaderTask(RequestsApiReaderTask):
    """Intermediate class to provide common JSON extract method from response."""

    def extract_content(self, context: TaskContext, conf: BaseApiReaderConfig, response: Response) -> object:
        """Extract JSON Response."""
        try:
            response_data = response.json()
            context.logger.info(f"API call successful (first 100 chars): {json.dumps(response_data)[:100]}")
            return response_data
        except ValueError as e:
            context.logger.error(f"Failed to parse JSON response: {e}")
            raise ValueError("Failed to parse JSON response") from e
