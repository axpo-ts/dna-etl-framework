from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy


class AcceptCsvHeader(HttpHeaderStrategy):
    """Class to add text/csv content type."""

    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """Adds Accept text/csv."""
        content_header = {"Accept": "text/csv"}
        headers.update(content_header)
        return headers
