# CPD-OFF - suppress copy paste detection on imports
from data_platform.tasks.reader.api.config.dataclasses import BasicAuthApiReaderConfig, BearerApiReaderConfig
from data_platform.tasks.reader.api.http.headers.access_token_bearer import AccessTokenBearerAuthHeader
from data_platform.tasks.reader.api.http.headers.basic_auth import BasicAuthHeader
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy
from data_platform.tasks.reader.api.http.headers.json_content_type import JsonContentTypeHeader
from data_platform.tasks.reader.api.http.request_reader import JsonResponseApiReaderTask

# CPD-ON - suppress copy paste detection on imports


class EBXBasicAuthApiReaderTask(JsonResponseApiReaderTask):
    """Task for downloading API data from EBX using Basic Authentication.

    Uses HTTP Basic Authentication for the new EBX endpoint.
    """

    task_name = "EBXBasicAuthApiReaderTask"

    def __init__(self) -> None:
        """Setup http_headers to implement in init block."""
        self.http_headers: list[HttpHeaderStrategy] = [BasicAuthHeader()]
        self.dataclass = BasicAuthApiReaderConfig


# Keep the old class for backward compatibility
class EBXBearerApiReaderTask(JsonResponseApiReaderTask):
    """Task for downloading API data from EBX using Bearer Authentication.

    Needs it's own implemenation due to bespoke "EBX" Authorisation HTTP header
    """

    task_name = "EBXBearerApiReaderTask"

    def __init__(self) -> None:
        """Setup http_headers to implement in init block."""
        self.http_headers: list[HttpHeaderStrategy] = [JsonContentTypeHeader(), AccessTokenBearerAuthHeader("EBX")]
        self.dataclass = BearerApiReaderConfig
