# CPD-OFF - suppress copy paste detection on imports
import ast
import asyncio
import json
from collections.abc import Iterator
from dataclasses import dataclass, field, replace
from datetime import datetime, timedelta
from functools import partial
from typing import Any, cast
from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

from requests import Response

from data_platform.tasks.core import Configuration, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BearerApiReaderConfig
from data_platform.tasks.reader.api.http.headers.access_token_bearer import AccessTokenBearerAuthHeader
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy
from data_platform.tasks.reader.api.http.headers.json_content_type import JsonContentTypeHeader
from data_platform.tasks.reader.api.http.request_reader import JsonResponseApiReaderTask

# CPD-ON - suppress copy paste detection on imports


@dataclass(kw_only=True)
class OrcaBearerApiReaderConfig(BearerApiReaderConfig):
    """Configuration class for Orca API reader tasks.

    Extends BearerApiReaderConfig with Orca-specific parameters for API URL construction
    and data retrieval.

    Attributes:
        api_url_params (dict[str, str]): Parameters for constructing the API URL including endpoint group,
            device ID, endpoint, and signal IDs
        table_name (str): Name of the table being processed
        buffer_days (int): Number of days to buffer the minimum date when querying historical data
        target_snapshot_column (str): Column name containing snapshot dates in the target table
        default_date (str): Default date to use if no historical data is found
        current_date (str): Current date for API calls
        bronze_catalog (str): Name of the bronze catalog containing historical data
        bronze_schema (str): Name of the bronze schema containing historical data
    """

    api_url_params: dict[str, str] = field(default_factory=dict)
    table_name: str
    buffer_days: int
    target_snapshot_column: str
    default_date: str
    current_date: str
    bronze_catalog: str
    bronze_schema: str
    staging_catalog: str
    staging_schema: str
    volume_name: str
    file_name: str
    api_concurrent_requests: int = 2

    def as_dict(self) -> dict:
        """Convert the dataclass instance to a dictionary.

        Returns:
            dict: Dictionary containing all fields of the dataclass
        """
        return {field.name: getattr(self, field.name) for field in self.__dataclass_fields__.values()}


class OrcaBearerApiReaderTask(JsonResponseApiReaderTask):
    """Task for downloading API data from Orca using Bearer Token Auth and JSON Response.

    This task handles authentication and data retrieval from the Orca API, with support for
    dynamic URL construction based on historical data and configuration parameters.

    Attributes:
        task_name (str): The name of the task, set to "OrcaBearerApiReaderTask"
        http_headers (list[HttpHeaderStrategy]): List of HTTP headers to include in requests
        dataclass (Type[OrcaBearerApiReaderConfig]): Configuration class for the task
    """

    task_name = "OrcaBearerApiReaderTask"

    def __init__(self) -> None:
        """Initialize the task with required headers for authentication and content type."""
        self.http_headers: list[HttpHeaderStrategy] = [JsonContentTypeHeader(), AccessTokenBearerAuthHeader()]
        self.dataclass = OrcaBearerApiReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the task with the given configuration and context.

        Args:
            context (TaskContext): The task context containing logger and other utilities
            conf (Configuration): The task configuration
        """
        _conf = self.start_task(context, conf)
        super().execute(context, _conf)

    def override_config(self, context: TaskContext, conf: Any) -> Any:
        """Override configuration to dynamically construct API URL based on historical data.

        This method computes the appropriate date range for the API call based on historical data
        and constructs the final API URL with all necessary parameters.

        Args:
            context (TaskContext): The task context containing logger and other utilities
            conf (Any): The task configuration

        Returns:
            Any: Updated configuration with the new API URL

        Raises:
            ValueError: If required parameters are missing
            Exception: If URL construction fails
        """
        _conf = cast(OrcaBearerApiReaderConfig, conf)
        if _conf.api_url:
            if all(
                [
                    _conf.bronze_catalog,
                    _conf.bronze_schema,
                    _conf.table_name,
                    _conf.buffer_days is not None,
                    _conf.target_snapshot_column,
                    _conf.default_date,
                    _conf.current_date,
                    _conf.api_url_params,
                ]
            ):
                try:
                    # Compute the new API URL with appropriate date range
                    min_date = self._get_min_date(
                        _conf.bronze_catalog,
                        _conf.bronze_schema,
                        _conf.table_name,
                        int(_conf.buffer_days),  # Ensure buffer_days is an int
                        _conf.target_snapshot_column,
                        _conf.default_date,
                        context,
                    )
                    new_api_url = self._create_api_url(
                        _conf.api_url,
                        _conf.api_url_params,
                        min_date,
                        _conf.current_date,
                        context,
                    )

                    # Update configuration with new URL
                    _conf = replace(_conf, api_url=new_api_url)
                    context.logger.info(f"Updated API URL: {_conf.api_url}")

                except Exception as e:
                    context.logger.error(f"Failed to construct API URL: {e}")
                    raise

        return _conf

    @staticmethod
    def _get_min_date(
        catalog_name: str,
        schema_name: str,
        table_name: str,
        buffer_days: int,
        target_snapshot_column: str,
        default_date: str,
        context: TaskContext,
    ) -> str:
        """Retrieve the minimum date from the table with buffer applied.

        Args:
            catalog_name (str): Name of the catalog containing the table
            schema_name (str): Name of the schema containing the table
            table_name (str): Name of the table to query
            buffer_days (int): Number of days to buffer the minimum date
            target_snapshot_column (str): Column containing snapshot dates
            default_date (str): Default date to return if no data found
            context (TaskContext): Task context containing logger and Spark session

        Returns:
            str: Minimum date in YYYY-MM-DD format, or default_date if no data found
        """
        sql_query = f"""
          SELECT date_format(to_date(dateadd(DAY, -{buffer_days}, min({target_snapshot_column}))), 'yyyy-MM-dd')
          AS from_date
          FROM {catalog_name}.{schema_name}.{table_name}
          LIMIT 1
        """
        context.logger.info(f"Executing query: {sql_query}")
        try:
            df = context.spark.sql(sql_query)
            df_list = [r.asDict() for r in df.collect()]
            return df_list[0]["from_date"] if df_list and df_list[0]["from_date"] else default_date
        except Exception as e:
            context.logger.warning(f"Failed to execute query: {e}. Using default date.")
            return default_date

    @staticmethod
    def _parse_mapping_dict(mapping_dict_str: str) -> dict[str, str]:
        """Parse a string representation of a dictionary into an actual dictionary.

        Args:
            mapping_dict_str (str): String representation of a dictionary

        Returns:
            dict[str, str]: Parsed dictionary

        Raises:
            ValueError: If the string cannot be parsed as a valid dictionary
        """
        try:
            mapping_dict = ast.literal_eval(mapping_dict_str)
            if not isinstance(mapping_dict, dict):
                raise ValueError("Parsed value is not a dictionary.")
            return mapping_dict
        except Exception as e:
            raise ValueError(f"Failed to parse mapping_dict string. Error: {e}")

    @staticmethod
    def _adjust_from_date(from_date: str, to_date: str, max_days: int = 29) -> str:
        """Adjust the from_date to ensure the date range doesn't exceed max_days.

        Args:
            from_date (str): Start date in YYYY-MM-DD format
            to_date (str): End date in YYYY-MM-DD format
            max_days (int): Maximum number of days allowed in the range

        Returns:
            str: Adjusted from_date in YYYY-MM-DD format
        """
        from_dt = datetime.strptime(from_date, "%Y-%m-%d")
        to_dt = datetime.strptime(to_date, "%Y-%m-%d")
        if (to_dt - from_dt).days > max_days:
            from_dt = to_dt - timedelta(days=max_days)
        return from_dt.strftime("%Y-%m-%d")

    @staticmethod
    def _create_api_url(
        api_url: str,
        api_url_params: dict,
        from_date: str,
        current_date: str,
        context: TaskContext,
    ) -> str:
        """Construct the API URL with necessary query parameters.

        Args:
            api_url (str): Base API URL
            api_url_params (dict): Dictionary containing API endpoint details including endpoint group,
                device ID, endpoint, and signal IDs
            from_date (str): Start date for the API call
            current_date (str): End date for the API call
            context (TaskContext): Task context containing logger and other utilities

        Returns:
            str: Complete API URL with all query parameters

        Raises:
            ValueError: If required URL parameters are missing
        """
        # Check required parameters based on endpoint group
        base_required_params = ["api_endpoint_group", "api_device_id", "api_endpoint"]
        missing_base_params = [param for param in base_required_params if param not in api_url_params]
        if missing_base_params:
            raise ValueError(f"Missing required URL parameters: {', '.join(missing_base_params)}")

        endpoint_group = api_url_params["api_endpoint_group"]

        # Check for api_signal_ids only for monitoring endpoint
        if endpoint_group == "monitoring":
            if "api_signal_ids" not in api_url_params:
                raise ValueError("Missing required URL parameter: api_signal_ids")

        # Adjust from_date if date range exceeds 29 days (API stores max 30 days)
        adjusted_from_date = OrcaBearerApiReaderTask._adjust_from_date(from_date, current_date, 29)

        if endpoint_group == "monitoring":
            base_url = (
                f"{api_url}{api_url_params['api_endpoint_group']}/"
                f"{api_url_params['api_device_id']}/{api_url_params['api_endpoint']}/download"
            )
            # Parse comma-separated signal IDs and append @Signals= before each value
            signal_ids_param: str | None = api_url_params.get("api_signal_ids")
            if signal_ids_param is None:
                raise ValueError("Missing required URL parameter: api_signal_ids")

            signal_ids_dict = OrcaBearerApiReaderTask._parse_mapping_dict(signal_ids_param)
            signal_ids = list(signal_ids_dict.keys())
            formatted_signals = "".join([f"&Signals={signal_id.strip()}" for signal_id in signal_ids])
            context.logger.info(f"Formatted signals: {formatted_signals}")
            url_params = f"?From={adjusted_from_date}&To={current_date}{formatted_signals}"

        elif endpoint_group == "planning":
            base_url = f"{api_url}{api_url_params['api_endpoint_group']}/{api_url_params['api_endpoint']}/download"
            url_params = f"?From={adjusted_from_date}&To={current_date}&Devices={api_url_params['api_device_id']}"

        else:
            raise ValueError(f"Invalid API endpoint group: {endpoint_group}")

        return base_url + url_params

    def _daterange(self, start_date: datetime, end_date: datetime) -> Iterator[datetime]:
        """Yield each date between start and end inclusive.

        Args:
            start_date: Starting date
            end_date: Ending date

        Yields:
            datetime: Each date in the range
        """
        current = start_date
        while current < end_date:
            yield current
            current += timedelta(days=1)

    async def _fetch_for_date(
        self,
        d_url: str,
        semaphore: asyncio.Semaphore,
        context: TaskContext,
        conf: Any,
        payload: dict,
        params: dict | None = None,
    ) -> Response:
        """Fetch data for a single day URL by delegating to the synchronous parent request.

        This coroutine replaces the configuration's api_url with the per-day URL (d_url),
        then runs the parent's synchronous execute_request inside a thread via asyncio.to_thread.
        A semaphore bounds concurrent requests to avoid overwhelming the remote API.

        Args:
            d_url: Fully formed URL for the specific day's request.
            semaphore: Semaphore used to limit concurrent fetches.
            context: Task execution context (logger, Spark session, etc.).
            conf: Configuration object (will be shallow-copied with updated api_url).
            payload: Request payload to pass to the parent request method.
            params: Optional query parameters.

        Returns:
            The requests.Response object returned by the parent's execute_request.

        Raises:
            Exception: Any exception raised by the underlying synchronous request is propagated.
        """
        # create a copy of the configuration with the daily URL substituted
        conf = replace(conf, api_url=d_url)

        # use semaphore to limit concurrency for external API calls
        async with semaphore:
            context.logger.info(f"Fetching data for URL: {d_url}")

            # The parent implementation (execute_request) is synchronous. Use functools.partial
            # to prepare the call and run it in a separate thread with asyncio.to_thread so
            # we don't attempt to await a non-awaitable.
            sync_call = partial(
                super().execute_request,
                context,
                conf,
                payload,
                params,
            )

            try:
                result: Response = await asyncio.to_thread(sync_call)
            except Exception as exc:
                # Log and propagate to allow upstream handling and visibility
                context.logger.error(f"Error fetching data for {d_url}: {exc}")
                raise
            finally:
                # Always emit a completion log so we know the task finished (success or failure).
                # If result is None we already logged the exception above; this is additional visibility.
                if result is None:
                    context.logger.info(f"Completed fetch task for URL: {d_url} with no response object.")
                else:
                    status_code = getattr(result, "status_code", "n/a")
                    context.logger.info(f"Completed fetch task for URL: {d_url} with response: {status_code}")
            return result

    async def _execute_request(
        self, context: TaskContext, conf: Any, payload: dict, params: dict | None = None
    ) -> list[tuple[str, Response]]:
        """Asynchronously execute API requests split by day and return per-day responses.

        This coroutine takes the configured API URL on the provided configuration and splits
        the query range into individual daily URLs (one URL per From date). It fetches each
        day's data concurrently but bounded by a semaphore to limit concurrency.

        The function returns a list of (date_string, Response) tuples where date_string is
        the 'From' value used for that request in 'YYYY-MM-DD' format and Response is the
        requests.Response returned for that daily request.

        Args:
            context: Task execution context providing logger and Spark session.
            conf: Configuration object (expected to include a fully-formed api_url with From/To query params).
            payload: Request payload to include in the HTTP call (if any).
            params: Optional additional query parameters.

        Returns:
            A list of (from_date_str, Response) tuples for each day in the requested range.

        Raises:
            ValueError: If the api_url does not contain a valid From/To range.
        """
        url_str = conf.api_url

        # Extract From/To from configured URL query parameters
        query_params = parse_qs(urlparse(url_str).query)
        from_date = query_params.get("From", [None])[0]
        to_date = query_params.get("To", [None])[0]

        # Ensure we have datetime objects for daterange generation
        if isinstance(from_date, str):
            from_date = datetime.fromisoformat(from_date)
        if isinstance(to_date, str):
            to_date = datetime.fromisoformat(to_date)

        # Limit concurrency to avoid overwhelming the API
        semaphore = asyncio.Semaphore(int(conf.api_concurrent_requests))

        # Build list of date strings for each day in the range
        date_ranges = [day_date.strftime("%Y-%m-%d") for day_date in self._daterange(from_date, to_date)]

        # Construct one URL per day by replacing the From param for each date
        base_query = parse_qs(urlparse(url_str).query)

        daily_urls = []
        for daily_date in date_ranges:
            next_date = (datetime.strptime(daily_date, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
            query_params = dict(base_query)  # shallow copy
            query_params["From"] = [daily_date]
            query_params["To"] = [next_date]
            new_query = urlencode(query_params, doseq=True)
            upd_url = urlunparse(urlparse(url_str)._replace(query=new_query))
            daily_urls.append(upd_url)

        # Create coroutines for each daily URL and execute concurrently
        tasks = [self._fetch_for_date(d_url, semaphore, context, conf, payload, params) for d_url in daily_urls]
        results = await asyncio.gather(*tasks)

        # Pair each date string with its corresponding Response result
        response_results = list(zip(date_ranges, results))

        return response_results

    def execute_request(
        self, context: TaskContext, conf: Any, payload: dict, params: dict | None = None
    ) -> list[tuple[str, Response]]:
        """Execute the API request synchronously by running the internal asynchronous executor.

        This method is a synchronous wrapper around the internal async _execute_request method;
        it runs the async coroutine using asyncio.run and returns the underlying response(s).

        Args:
            context: Task execution context providing logger and Spark session.
            conf: Configuration object for the API reader (typically an OrcaBearerApiReaderConfig).
            payload: Request payload to send in the API call.
            params: Optional query parameters to include with the request.

        Returns:
            Response: The response object or a collection of responses produced by the async executor.
            list[tuple[str, Response]]: A list of (from_date_str, Response) tuples.

        Raises:
            RuntimeError: If the asynchronous execution fails or is cancelled.
        """
        return asyncio.run(self._execute_request(context=context, conf=conf, payload=payload, params=params))

    def extract_content(self, context: TaskContext, conf: Any, response: Response) -> object:
        """Extract content from a single Response or from multiple (date, Response) pairs.

        This method supports both a single requests.Response (the synchronous case)
        and the list of (from_date, Response) tuples produced by the internal
        asynchronous executor. For a single Response it delegates to the parent
        implementation to parse and return the content; for multiple responses it
        parses each Response via the parent implementation and returns a list of
        (from_date, parsed_content) tuples.

        Args:
            context: Task execution context containing logger and Spark session.
            conf: Configuration object for the API reader (typically OrcaBearerApiReaderConfig).
            response: A requests.Response instance or a list of (from_date, Response)
                tuples produced by the async executor.

        Returns:
            The parsed response content for a single Response, or a list of
            (from_date, parsed_content) tuples when multiple responses are provided.

        Raises:
            ValueError: If the response format is not supported.
        """
        if not isinstance(response, list):
            # Fallback: single response, just delegate to parent
            return super().extract_content(context, conf, response)

        # Multiple responses: process each with parent method
        all_data = []
        for from_date, resp in response:
            try:
                context.logger.info(f"Extracting content for date: {from_date}")
                day_data = super().extract_content(context, conf, response=resp)
            except Exception as e:
                context.logger.error(f"Failed to extract content for date {from_date}: {e}")
                raise
            context.logger.info(f"Extracted content for date {from_date}")
            all_data.append((from_date, day_data))
        return all_data

    def handle_response(self, context: TaskContext, conf: Any, content: Any) -> None:
        """Handle the API response content."""
        for from_date, item in content:
            context.logger.info(f"Saving content for date: {from_date}")
            self.save_to_volume(context, conf, item, from_date)

    def save_to_volume(
        self, context: TaskContext, conf: OrcaBearerApiReaderConfig, content: Any, from_date: str
    ) -> None:
        """Write JSON content to a staging volume file using configuration and a date suffix.

        This method constructs a file path inside the configured staging volume using fields
        from the provided configuration and the provided from_date, then writes the provided
        JSON-serializable content to that file. Logging is emitted for both the target volume
        and the final file path. Any exception raised during writing is logged and re-raised.

        Args:
            context: Task execution context providing logger and Spark session.
            conf: OrcaBearerApiReaderConfig containing staging volume details and file naming.
            content: JSON-serializable object to be written to the volume.
            from_date: Date string (YYYY-MM-DD) used as part of the output filename.

        Returns:
            None

        Raises:
            Exception: Propagates any exception raised while attempting to write the file.
        """
        # volume to write the json object
        volume_location = f"/Volumes/{conf.staging_catalog}/{conf.staging_schema}/{conf.volume_name}"
        context.logger.info(volume_location)

        # location to write the json object
        time_now = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        file_location = f"{volume_location}/{conf.file_name}_{from_date}_{time_now}.json"

        context.logger.info(file_location)

        try:
            with open(file_location, "w") as file:
                json.dump(content, file)
            context.logger.info(f"Successfully wrote JSON to volume at {file_location} for date {from_date}")
        except Exception as e:
            context.logger.error(f"Failed to write JSON to volume: {e} for date {from_date}")
            raise
        return None
