from dataclasses import dataclass


@dataclass(kw_only=True)
class BaseOauthConfig:
    """Base Configuration class for all OauthTask configurations.

    Attributes:
        task_name (str): The name of the task.
        namespace (str): The namespace in task context where secrets are stored.
        access_token_key (str): The access token key required for the access token from Task Context.
    """

    task_name: str
    namespace: str
    access_token_key: str


@dataclass(kw_only=True)
class BasicOauthConfig(BaseOauthConfig):
    """Configuration class for AzureOauthTask.

    Attributes:
        username_key (str): The username key required to get the username from key vault.
        password_key (str): The password key required to get the username from key vault.
        content_type (str): Content type of the API.
        auth_url (str): The auth URL of the API.
        auth_token_name (str): Name of the access token retrieval get.
    """

    username_key: str
    password_key: str
    content_type: str
    auth_url: str
    auth_token_name: str = "accessToken"


@dataclass(kw_only=True)
class OrcaOauthConfig(BasicOauthConfig):
    """Configuration class for OrcaOauthConfig.

    Attributes:
        grant_type(str): Grant Type for the API: client_Credentials
    """

    granttype_key: str
    auth_token_name: str = "access_token"


@dataclass(kw_only=True)
class OAuthConfig(BaseOauthConfig):
    """Base configuration class for OAuth settings."""

    tenant_id_key: str
    client_id_key: str
    client_secret_key: str
    api_scope_key: str
