import base64
from typing import cast

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig, BasicAuthApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy


class BasicAuthHeader(HttpHeaderStrategy):
    """Class to add HTTP Basic Authentication header."""

    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """Add Basic Authentication header to the request.

        Args:
            context: Task context containing secrets
            conf: API reader configuration
            headers: Existing headers dictionary

        Returns:
            Updated headers dictionary with Basic Auth header
        """
        # Cast to BasicAuthApiReaderConfig to access username_key and password_key
        _conf = cast(BasicAuthApiReaderConfig, conf)

        # Get credentials from task context using configuration values
        username = context.get_property(namespace=conf.secret_namespace, key=_conf.username_key)
        password = context.get_property(namespace=conf.secret_namespace, key=_conf.password_key)

        if not username or not password:
            raise ValueError(
                f"Missing credentials: username_key='{_conf.username_key}', password_key='{_conf.password_key}'"
            )

        # Create Basic Auth header
        credentials = f"{username}:{password}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()
        auth_header = {"Authorization": f"Basic {encoded_credentials}"}

        headers.update(auth_header)
        return headers
