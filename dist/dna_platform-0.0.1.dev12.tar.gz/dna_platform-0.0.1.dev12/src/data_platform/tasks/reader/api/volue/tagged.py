# CPD-OFF - ignore imports
import asyncio
from typing import Any, cast

import nest_asyncio  # type: ignore
import pandas as pd
from pyspark.sql import DataFrame
from pyspark.sql import functions as f

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.volue.volue import VolueAbstractCurveApiBulkReaderTask

# CPD-ON - ignore imports
nest_asyncio.apply()  # type: ignore


class VolueTaggedApiBulkReaderTask(VolueAbstractCurveApiBulkReaderTask):
    """Task for reading from a given API.

    Attributes:
        task_name (str): The name of the task.
        api_url (str): Full API url.

    """

    task_name = "VolueTaggedApiBulkReaderTask"

    # CPD-OFF - ignore multiline method signature across implementations
    async def process_curve(
        self, date_from: str, date_to: str, curve_name: str, context: TaskContext, curve: Any, tags: str | None = None
    ) -> tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]:
        # CPD-ON - ignore multiline method signature across implementations
        """Implementation for TS Curves."""
        date_from, date_to = self.enforce_correct_curve_dates(
            date_from=date_from,
            date_to=date_to,
            curve=curve,
            context=context,
        )
        if tags:
            wanted_tags = {cleaned for raw in tags if raw and (cleaned := raw.strip())}
        else:
            raise Exception("Trying to retrieve a tagged timeseries curve with no tags passed in")

        return_list = []

        for tag in wanted_tags:
            api_data_filter_params = {}
            api_data_filter_params["data_from"] = date_from
            api_data_filter_params["data_to"] = date_to
            api_data_filter_params["tag"] = tag
            context.logger.info(f" curve_name: {curve_name} | date params: {api_data_filter_params}")
            ts = await asyncio.to_thread(curve.get_data, **api_data_filter_params)
            cast(pd.Series, ts)
            return_list.append((curve_name, tag, ts))

        return return_list

    # CPD-OFF - ignore multiline method signature across implementations
    def process_results(
        self,
        results: list[tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]],
        context: TaskContext | None = None,
    ) -> list:
        # CPD-ON - ignore multiline method signature across implementations
        """Implementation for Tagged TS Curves."""
        dfs = []
        for curve in results:
            for curve_name, tag, df in curve:
                df = df.to_pandas().to_frame().reset_index().assign(curve_name=curve_name).assign(tag=tag)
                df.columns = ["value_at", "value", "curve_name", "tag"]
                dfs.append(df)
        return dfs

    def process_df(
        self, df: DataFrame, context: TaskContext | None, api_get_params: dict[str, str] | None
    ) -> DataFrame:
        """Overridable method to select columns from a DataFrame."""
        df = df.select(
            f.col("tag"),
            f.col("curve_name"),
            f.col("value_at"),
            f.col("value"),
        )
        return df
