from __future__ import annotations

import itertools
import json
import logging
import re
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any

__all__ = [
    "load_curve_file_and_expand",
]

_LOG = logging.getLogger(__name__)
_PLACEHOLDER_RE = re.compile(r"{(\w+)}")


# ────────────────────────── helpers ──────────────────────────


def _extract_matrix(
    item: Mapping[str, Any],
    placeholders: Iterable[str],
) -> dict[str, list[str]]:
    """Collect value lists for every placeholder inside *item*.

    Args:
        item: Arbitrary mapping that may contain lists keyed by placeholder names
            (e.g. ``"area": ["dk1", "dk2"]``).
        placeholders: The set of placeholder names that appear in the
            ``curve_name`` template (e.g. ``["area", "fuel"]``).

    Returns:
        A dictionary ``{placeholder: list_of_values}``.  If a required list is
        missing or empty, the function logs a warning and omits that
        placeholder; the caller can decide whether to skip expansion.

    Side Effects:
        Emits ``logging.WARNING`` for every placeholder that has no
        corresponding list.
    """
    matrix: dict[str, list[str]] = {}
    missing: list[str] = []

    for ph in placeholders:
        values = item.get(ph)
        if isinstance(values, list) and values:
            matrix[ph] = values
        else:
            missing.append(ph)

    if missing:
        _LOG.warning(
            "Skipping '%s' → missing value list for %s",
            item.get("curve_name"),
            ", ".join(missing),
        )
    return matrix


def _expand_curve_item(template_item: dict[str, Any]) -> list[dict[str, Any]]:
    """Expand one mapping that contains a *curve_name* with placeholders.

    For example, the template::

        {"curve_name": "pro {area} {category} mwh/h cet min15 a", "area": ["dk1", "dk2"], "category": ["spv", "wnd"]}

    becomes *four* fully-specified items, one for every product of the value
    lists.

    Args:
        template_item: A mapping that must contain the key ``"curve_name"`` and
            optional lists for each ``{placeholder}`` used in that string.

    Returns:
        A list with **one or more** expanded copies of *template_item*.  If no
        placeholders are found, the list contains the original item.  If some
        placeholder lists are missing, an empty list is returned (the caller
        already received a warning from :func:`_extract_matrix`).
    """
    tmpl: str = template_item.get("curve_name", "")
    placeholders = _PLACEHOLDER_RE.findall(tmpl)

    # No placeholders → pass through unchanged
    if not placeholders:
        return [template_item]

    matrix = _extract_matrix(template_item, placeholders)
    if set(matrix) != set(placeholders):
        return []

    expanded: list[dict[str, Any]] = []
    for combo in itertools.product(*(matrix[p] for p in placeholders)):
        name = tmpl
        for ph, value in zip(placeholders, combo):
            name = name.replace(f"{{{ph}}}", value)

        # Copy without the placeholder lists
        base = {k: v for k, v in template_item.items() if k not in placeholders}
        base["curve_name"] = name
        expanded.append(base)

    return expanded


def _convert_to_curves_dict(expanded_data: Any) -> Any:
    """Convert expanded template data to a format with curve dictionaries.

    Converts from:
    [{"time_series_a": [{"curve_name": "...", ...}, ...]}, ...]

    To:
    [{"time_series_a": {"curve_name_1": {...}, "curve_name_2": {...}}}, ...]

    Args:
        expanded_data: The expanded template data structure.

    Returns:
        The same structure but with lists of curve items converted to dictionaries
        keyed by curve_name.
    """
    if isinstance(expanded_data, list):
        return [_convert_to_curves_dict(item) for item in expanded_data]

    if isinstance(expanded_data, dict):
        converted = {}
        for key, value in expanded_data.items():
            if isinstance(value, list):
                # Check if this is a list of curve items
                if value and isinstance(value[0], dict) and "curve_name" in value[0]:
                    # Convert list to dictionary keyed by curve_name
                    curves_dict = {}
                    for curve_item in value:
                        if isinstance(curve_item, dict) and "curve_name" in curve_item:
                            curve_name = curve_item["curve_name"]
                            curves_dict[curve_name] = curve_item
                    converted[key] = curves_dict
                else:
                    # Not a curves list, recurse normally
                    converted[key] = _convert_to_curves_dict(value)
            else:
                converted[key] = _convert_to_curves_dict(value)
        return converted

    # Scalars remain unchanged
    return expanded_data


# ─────────────────────── recursive walker ───────────────────────


def _walk(node: Any) -> Any:
    """Recursively traverse *node* and expand every curve template it finds.

    The function is generic: it accepts any JSON-compatible structure and
    returns another structure of the **exact same shape**, except every dict
    that originally contained a ``curve_name`` with placeholders is replaced by
    one or more fully-expanded dicts.

    Args:
        node: Any JSON value (dict, list or scalar).

    Returns:
        The expanded JSON value.
    """
    if isinstance(node, list):
        out: list[Any] = []
        for element in node:
            expanded = _walk(element)
            # a leaf expansion may return a list itself
            out.extend(expanded if isinstance(expanded, list) else [expanded])
        return out

    if isinstance(node, dict):
        # leaf candidate
        if "curve_name" in node:
            return _expand_curve_item(node)

        # otherwise recurse into every value
        return {k: _walk(v) for k, v in node.items()}

    # scalars (str, int, None …) are unchanged
    return node


# ────────────────────────── public API ──────────────────────────


def load_curve_file_and_expand(path: str | Path) -> Any:
    """Load a JSON template file, expand all ``curve_name`` templates, and convert to dict format.

    ``load_curve_file_and_expand`` understands **any** combination of lists and dicts that
    ultimately leads to items having a ``curve_name`` key. After expansion, it converts
    lists of curve items to dictionaries keyed by curve_name for easier processing.

    Example:
        >>> result = load_curve_file_and_expand("curve_templates.json")
        >>> isinstance(result, list)
        True

    Args:
        path: Path to a JSON file with the template configuration.

    Returns:
        The fully-expanded JSON structure with curve lists converted to dictionaries.
        Each section like "time_series_a" will contain a dictionary where keys are
        curve names and values are the curve data.

    Raises:
        json.JSONDecodeError: If the file is not valid JSON.
        OSError: If the file cannot be read.
    """
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)

    expanded = _walk(data)
    return _convert_to_curves_dict(expanded)
