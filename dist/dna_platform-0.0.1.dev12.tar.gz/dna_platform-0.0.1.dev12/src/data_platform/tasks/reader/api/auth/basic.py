import json
from typing import cast

import requests

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.auth.config.dataclasses import BaseOauthConfig, BasicOauthConfig


class BasicOauthTask(ETLTask):
    """Task for retrieving OAuth2 tokens using secrets from task context for Basic authentication.

    Attributes:
        task_name (str): Name of the task.
        dataclass (Type[AzureOauthConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the AzureOauthTask by using secrets stored in the task context to get an OAuth2 token.
    """

    task_name = "BasicOauthTask"
    verify = False

    def __init__(self) -> None:
        """Set dataclass."""
        self.dataclass = BasicOauthConfig

    def parse_config(self, context: TaskContext, conf: Configuration) -> BaseOauthConfig:
        """Return configuration as dataclass."""
        # Map config to the dataclass definition
        _conf = self.dataclass(**conf.as_dict())
        return _conf

    def prepare_oauth_body(self, context: TaskContext, conf: BaseOauthConfig) -> dict | str:
        """Return JSON body of Oauth token request."""
        conf = cast(BasicOauthConfig, conf)
        # Retrieve secrets from the task context
        username = context.get_property(conf.namespace, conf.username_key)
        password = context.get_property(conf.namespace, conf.password_key)
        # Prepare data for token request
        body = {"login": username, "password": password}
        context.logger.info("done body")
        return json.dumps(body)

    def prepare_http_headers(self, context: TaskContext, conf: BaseOauthConfig) -> dict | None:
        """Return array of HTTP headers needed for request."""
        conf = cast(BasicOauthConfig, conf)
        headers = {"Content-Type": conf.content_type}
        context.logger.info("done header")
        return headers

    def get_url(self, context: TaskContext, conf: BaseOauthConfig) -> str:
        """URL to send request to."""
        conf = cast(BasicOauthConfig, conf)
        return conf.auth_url

    def get_auth_token_name(self, context: TaskContext, conf: BaseOauthConfig) -> str:
        """Return name of JSON attribute to find access token."""
        conf = cast(BasicOauthConfig, conf)
        return conf.auth_token_name

    def execute_token_request(self, context: TaskContext, conf: BaseOauthConfig) -> None:
        """DRY execution of HTTP Request for Oauth token request."""
        url = self.get_url(context, conf)
        headers = self.prepare_http_headers(context, conf)
        body = self.prepare_oauth_body(context, conf)
        auth_token_name = self.get_auth_token_name(context, conf)

        context.logger.info(f"auth url: {url}")

        # Request the access token
        try:
            response = requests.post(url, data=body, headers=headers, verify=self.verify)
            access_token = response.json().get(auth_token_name)
            if access_token:
                context.logger.info(f"Access token obtained and stored successfully.{access_token[0:20]}>>REDACTED<<")
                context.put_property(namespace=conf.namespace, key=conf.access_token_key, value=access_token)
            else:
                context.logger.error("Failed to retrieve access token from response.")
                raise ValueError("Access token not found in response.")

        except requests.RequestException as e:
            context.logger.error("Error occurred during token request: %s", e)
            raise ValueError("Error occurred during token request.") from e

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the BasicOauthTask by using secrets stored in the task context to get an OAuth2 token.

        Args:
            context (TaskContext): The task context that holds the task state and configuration.
            conf (Configuration): The configuration for the BasicOauthTask.
        """
        _conf = self.start_task(context, conf)
        self.execute_token_request(context, _conf)
