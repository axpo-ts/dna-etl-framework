from typing import cast

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig, BearerApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy


class AccessTokenBearerAuthHeader(HttpHeaderStrategy):
    """Class to add Authentication Bearer Header."""

    def __init__(self, header: str = "Bearer") -> None:
        """Initialise with ability to override header for EBX."""
        self.bearer_prefix = header

    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """Append header based on access token retrieved from configuration."""
        _conf = cast(BearerApiReaderConfig, conf)
        try:
            conf_namespace = getattr(_conf, "secret_namespace")
            conf_access_token_key = getattr(_conf, "access_token_key")
            access_token = context.get_property(namespace=conf_namespace, key=conf_access_token_key)
        except Exception as e:
            context.logger.error(f"Failed to obtain access token: {e}")
            raise ValueError("Failed to obtain access token:") from e
        auth_header = {"Authorization": f"{self.bearer_prefix} {access_token}"}
        headers.update(auth_header)
        return headers
