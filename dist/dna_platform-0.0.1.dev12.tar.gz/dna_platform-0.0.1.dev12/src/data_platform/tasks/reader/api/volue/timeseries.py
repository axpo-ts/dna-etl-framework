# CPD-OFF - ignore imports
import asyncio
from typing import Any

import nest_asyncio  # type: ignore
import pandas as pd
from pyspark.sql import DataFrame
from pyspark.sql import functions as f

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.volue.volue import VolueAbstractCurveApiBulkReaderTask

# CPD-ON - ignore imports
nest_asyncio.apply()  # type: ignore


class VolueTimeseriesApiBulkReaderTask(VolueAbstractCurveApiBulkReaderTask):
    """Task for reading from a given API.

    Attributes:
        task_name (str): The name of the task.
        api_url (str): Full API url.

    """

    task_name = "VolueTimeseriesApiBulkReaderTask"

    # CPD-OFF - ignore multiline method signature across implementations
    async def process_curve(
        self, date_from: str, date_to: str, curve_name: str, context: TaskContext, curve: Any, tags: str | None = None
    ) -> tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]:
        # CPD-ON - ignore multiline method signature across implementations
        """Implementation for TS Curves."""
        date_from, date_to = self.enforce_correct_curve_dates(
            date_from=date_from,
            date_to=date_to,
            curve=curve,
            context=context,
        )
        api_data_filter_params = {}
        api_data_filter_params["data_from"] = date_from
        api_data_filter_params["data_to"] = date_to
        context.logger.info(f" curve_name: {curve_name} | date params: {api_data_filter_params}")
        ts = await asyncio.to_thread(curve.get_data, **api_data_filter_params)
        return curve_name, ts

    # CPD-OFF - ignore multiline method signature across implementations
    def process_results(
        self,
        results: list[tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]],
        context: TaskContext | None = None,
    ) -> list:
        # CPD-ON - ignore multiline method signature across implementations
        """Implementation for TS Curves."""
        dfs = [df.to_pandas().to_frame().reset_index().assign(curve_name=curve_name) for curve_name, df in results]
        for df in dfs:
            df.columns = ["value_at", "value", "curve_name"]
        return dfs

    def process_df(
        self, df: DataFrame, context: TaskContext | None = None, api_get_params: dict[str, str] | None = None
    ) -> DataFrame:
        """Overridable method to select columns from a DataFrame."""
        df = df.select(
            f.col("curve_name"),
            f.col("value_at"),
            f.col("value"),
        )
        return df
