# CPD-OFF - suppress copy paste detection on imports


import json
import time
from typing import ClassVar, cast

import requests
from pyspark.sql import DataFrame, Row
from pyspark.sql.functions import col, collect_list, upper
from requests import Response

from data_platform.etl.transform.transform import add_audit_cols_snake_case
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.auth.authmanager import AzureOAuthTokenManager
from data_platform.tasks.reader.api.auth.config.dataclasses import OAuthConfig  # noqa: F401
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.access_token_bearer import AccessTokenBearerAuthHeader
from data_platform.tasks.reader.api.http.headers.json_content_type import JsonContentTypeHeader
from data_platform.tasks.transform.config.dataclasses import DatabricksApiConfig

# CPD-OFF - suppress copy paste detection on code


class DatabricksAPI(ETLTask):
    """Base class for interacting with the Azure Databricks SCIM API."""

    task_name = "DatabricksAPI"
    HTTP_SUCCESS_CODES: ClassVar[set] = {200, 201}
    RATE_LIMIT_EXCEEDED: ClassVar[int] = 429
    CONFLICT: ClassVar[int] = 409

    def __init__(self) -> None:
        """Initializes the DatabricksAPI class with default configurations."""
        super().__init__()
        self.dataclass = DatabricksApiConfig
        self.http_headers = [JsonContentTypeHeader(), AccessTokenBearerAuthHeader()]
        self.timeout: int = 1800
        self.token_manager: AzureOAuthTokenManager

    def initialize_headers(self, context: TaskContext, conf: DatabricksApiConfig) -> None:
        """Initializes the HTTP headers for the API request.

        This method initializes the Token from Azure and constructs the HTTP headers required
        for the API request by iterating over the `http_headers` attribute and appending headers
        based on the provided task context and configuration.

        Args:
            context (TaskContext): The context of the task, providing runtime
                information and utilities.
            conf (DatabricksApiConfig): The configuration object containing
                settings specific to the Databricks API.

        Returns: None
        """
        self.token_manager = AzureOAuthTokenManager()
        self.token_manager.obtain_access_token(context, conf)

        _conf = cast(BaseApiReaderConfig, conf)
        headers: dict[str, str] = {}
        for header in self.http_headers:
            headers = header.append_header(context, _conf, headers)
        self.headers = headers

    def api_call_with_retries(
        self, context: TaskContext, conf: DatabricksApiConfig, payload: dict | str | None = {}, max_retries: int = 2
    ) -> Response:
        """Handles API calls with retry logic.

        Args:
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing
                settings specific to the Databricks API.
            payload (dict, optional): The data to send with the API request. Defaults to {}.
            max_retries (int, optional): The maximum number of retry attempts. Defaults to 5.

        Returns:
            Response: The HTTP response from the API call.
        """
        first_response = None

        for attempt in range(max_retries):
            try:
                response = requests.request(self.api_method, self.api_url, headers=self.headers, data=payload)
                if response.status_code in self.HTTP_SUCCESS_CODES:
                    return response

                # Handle token expiration error
                if any(
                    err in response.text
                    for err in [
                        "JWT has expired",
                        "WT expired",
                        "ExpiredJwtException",
                        "invalid_token",
                        "token has expired",
                        "Allowed clock skew",
                        "Token is expiring within",
                    ]
                ):
                    context.logger.warning("Access token has expired. Refreshing token...")
                    self.token_manager.obtain_access_token(context, conf)
                    self.initialize_headers(context, conf)
                    continue  # Reset the Token and Retry the API call

                if response.status_code == self.CONFLICT:
                    context.logger.warning(f"Conflict detected: {response.text}")
                    first_response = first_response or response
                    return first_response

                if response.status_code == self.RATE_LIMIT_EXCEEDED:
                    wait_time = 2**attempt
                    context.logger.info(f"Rate limit exceeded. Retrying in {wait_time} seconds...")
                    time.sleep(wait_time)
                else:
                    context.logger.error(f"Error in API call (attempt {attempt + 1}): {response.text}")

            except Exception as e:
                context.logger.error(f"API request failed during attempt {attempt + 1}: {response.text},{str(e)[:100]}")

            if attempt == max_retries - 1:
                context.logger.error("Max retries exceeded.")
                return self.create_dummy_response("max retries exceeded")

        return (
            first_response
            if first_response and first_response.json().get("id")
            else self.create_dummy_response("Failed to create group")
        )

    def create_dummy_response(self, reason: str) -> Response:
        """Creates a dummy response for error handling.

        Args:
            reason (str): The reason for creating a dummy response.

        Returns:
            Response: A dummy HTTP response with an error message.
        """
        dummy_response = Response()
        dummy_response.status_code = 500
        dummy_response._content = json.dumps({"error": f"Dummy response due to {reason}"}).encode("utf-8")
        return dummy_response

    def create_group(self, group_name: str, context: TaskContext, conf: DatabricksApiConfig) -> str | None:
        """Creates a group in Azure Databricks using the SCIM API.

        Args:
            group_name (str): The name of the group to be created.
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing API settings.

        Returns:
            str | None: The ID of the created group or None if creation failed.
        """
        self.build_url(conf, "POST", conf.api_scim_urls["scim_account_url"])
        payload = json.dumps({"displayName": group_name})

        context.logger.info(f"Making API Call with {self.api_url} and payload: {payload}")

        try:
            response = self.api_call_with_retries(context, conf, payload)

            if response.json().get("id"):
                group_id = response.json()["id"]
                context.logger.info(f"Group '{group_name}' created successfully with ID: {group_id}.")
                return group_id
            else:
                context.logger.error(f"Failed to create group: {response.text}")
                return None
        except Exception as e:
            context.logger.error(f"Error while creating group '{group_name}': {e!r}")
            return None

    def get_user_id(self, user_email: str, context: TaskContext, conf: DatabricksApiConfig) -> str:
        """Returns the user ID for the given user email.

        Args:
            user_email (str): The email address of the user.
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing API settings.

        Returns:
            str: The user ID or "0" if the user does not exist.
        """
        self.build_url(
            conf, "GET", conf.api_scim_urls["scim_users_url"], f"?filter=userName eq '{user_email}'&attributes=id"
        )
        response = self.api_call_with_retries(context, conf)

        if "Resources" in response.json():
            return response.json()["Resources"][0]["id"]
        elif response.json().get("totalResults", 0) == 0:
            context.logger.warning("User does not exist in the workspace yet")
            return "0"
        else:
            context.logger.error(f"Failed to get user ID: {response.text}")
            return "0"

    def fetch_all_group_ids(self, context: TaskContext, conf: DatabricksApiConfig) -> dict[str, str]:
        """Fetch all groups and return a dictionary of group names to IDs.

        Args:
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing API settings.

        Returns:
            dict[str, str]: A dictionary mapping group names to their IDs.
        """
        self.build_url(conf, "GET", conf.api_scim_urls["scim_groups_url"])
        response = self.api_call_with_retries(context, conf)

        if response.status_code == 200:
            return {group["displayName"]: group["id"] for group in response.json().get("Resources", [])}
        else:
            context.logger.error(f"Failed to fetch groups: {response.text}")
            return {}

    def get_group_id(self, group_name: str, context: TaskContext, conf: DatabricksApiConfig) -> str:
        """Returns the group ID for the specified group name.

        Args:
            group_name (str): The name of the group.
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing API settings.

        Returns:
            str: The group ID or "0" if the group does not exist.
        """
        self.build_url(conf, "GET", conf.api_scim_urls["scim_account_url"], f"?filter=displayName eq '{group_name}'")
        response = self.api_call_with_retries(context, conf)

        if response.status_code == 200:
            response_json = response.json()
            if "Resources" in response_json and response_json["totalResults"] > 0:
                return response_json["Resources"][0]["id"]
            else:
                context.logger.error(f"No group found with name '{group_name}'.")
                return "0"
        else:
            context.logger.error(f"Failed to get group ID: {response.text}")
            return "0"

    def assign_group_to_workspace(self, group_id: str, context: TaskContext, conf: DatabricksApiConfig) -> str | None:
        """Assigns a group to the Azure Databricks workspace.

        Args:
            group_id (str): The unique identifier of the group to be assigned to the workspace.
            context (TaskContext): The task context containing logging and other runtime information.
            conf (DatabricksApiConfig): The configuration object containing Databricks API details.

        Returns:
            str | None: The principal ID of the assigned group if the operation is successful,
            otherwise None.

        Logs:
            - Logs the API call details including the URL and payload.
            - Logs an error message if the group assignment fails.

        Raises:
            None: This method does not raise exceptions directly but logs errors for failed operations.
        """
        self.build_url(conf, "PUT", conf.api_scim_urls["scim_permissions_url"], f"/{group_id}")
        payload = json.dumps({"permissions": ["USER"]})
        context.logger.info(f"Making API Call with {self.api_url} and payload: {payload}")
        response = self.api_call_with_retries(context, conf, payload)

        if response.status_code == 200:
            return response.json()["principal"]["principal_id"]
        else:
            context.logger.error(f"Failed to assign group to workspace: {response.text}")
            return None

    def get_etag_for_rule_set(self, group_id: str, context: TaskContext, conf: DatabricksApiConfig) -> str | None:
        """Retrieves the ETag for a rule set associated with a specific group from the Databricks Account SCIM API.

        Args:
            group_id (str): The ID of the group for which the rule set ETag is to be fetched.
            context (TaskContext): The task context containing logging and other runtime information.
            conf (DatabricksApiConfig): Configuration object containing Databricks API details.

        Returns:
            str | None: The ETag of the rule set if the request is successful, otherwise None.

        Raises:
            None: This method handles errors internally by logging them and returning None.
        """
        self.build_url(
            conf,
            "GET",
            conf.api_scim_urls["scim_ruleset_url"],
            f"?name=accounts/{conf.account_id}/groups/{group_id}/ruleSets/default&etag=",
        )

        response = self.api_call_with_retries(context, conf)
        if response.status_code == 200:
            return response.json()["etag"]
        else:
            context.logger.error(f"Unable to fetch ETag for Rule Set: {response.text}")
            return None

    def assign_management_group(
        self, group_id: str, etag: str, context: TaskContext, conf: DatabricksApiConfig
    ) -> None:
        """Assigns a management group to a Databricks account using the SCIM API.

        This method constructs a payload to assign a management group to a specific
        group within a Databricks account and sends the request to the SCIM API.
        It logs the result of the operation.

        Args:
            group_id (str): The ID of the group to which the management group will be assigned.
            etag (str): The ETag value used for concurrency control.
            context (TaskContext): The task context containing logging and other utilities.
            conf (DatabricksApiConfig): The configuration object containing Databricks API details.

        Raises:
            Exception: If the API call fails, an error message is logged, and an exception may be raised.

        Logs:
            - Logs an info message if the management group is successfully assigned.
            - Logs an error message if the assignment fails.
        """
        self.build_url(conf, "PUT", conf.api_scim_urls["scim_ruleset_url"])

        payload = json.dumps(
            {
                "name": f"accounts/{conf.account_id}/groups/{group_id}/ruleSets/default",
                "rule_set": {
                    "name": f"accounts/{conf.account_id}/groups/{group_id}/ruleSets/default",
                    "description": "",
                    "grant_rules": [{"role": "roles/group.manager", "principals": [f"groups/{conf.admin_group}"]}],
                    "etag": f"{etag}",
                },
            }
        )

        response = self.api_call_with_retries(context, conf, payload)
        if response.status_code == 200:
            context.logger.info(f"Assigned management group {conf.admin_group} to group {group_id}")
        else:
            context.logger.error(f"Failed to assign management group to group: {response.text}")

    def assign_user_id_to_group(
        self, user_id: str, group_id: str, context: TaskContext, conf: DatabricksApiConfig
    ) -> None:
        """Assigns a user to a specified group in Databricks using the SCIM API.

        This method sends a PATCH request to the Databricks SCIM API to add the given
        user ID to the specified group ID. It constructs the appropriate payload and
        handles the API call with retries.

        Args:
            user_id (str): The unique identifier of the user to be added to the group.
            group_id (str): The unique identifier of the group to which the user will be added.
            context (TaskContext): The task context containing logging and other utilities.
            conf (DatabricksApiConfig): The configuration object containing Databricks API details.

        Returns:
            None

        Logs:
            - Logs the URL and payload used for the API call.
            - Logs the response text from the API call.

        Raises:
            Any exceptions raised during the API call will propagate to the caller.
        """
        self.build_url(conf, "PATCH", conf.api_scim_urls["scim_account_url"], f"/{group_id}")
        payload = json.dumps(
            {
                "schemas": ["urn:ietf:params:scim:api:messages:2.0:PatchOp"],
                "Operations": [{"op": "add", "path": "members", "value": [{"value": f"{user_id}"}]}],
            }
        )

        context.logger.info(f"Assigning User {user_id} with url: {self.api_url} and payload {payload}")

        response = self.api_call_with_retries(context, conf, payload)

        context.logger.info(f"assign user to group response: {response.text[:100]}")

    def build_url(self, conf: DatabricksApiConfig, api_method: str, endpoint: str, query: str = "") -> None:
        """Constructs and sets the full API URL and HTTP method for a Databricks API request.

        Args:
            conf (DatabricksApiConfig): Configuration object containing the Databricks host URL.
            api_method (str): The HTTP method to be used for the API request (e.g., 'GET', 'POST').
            endpoint (str): The specific API endpoint to be appended to the host URL.
            query (str, optional): Optional query string to be appended to the URL. Defaults to an empty string.

        Returns:
            None
        """
        self.api_url = f"{conf.host_url}/{endpoint}" + (f"{query}" if query else "")
        self.api_method = api_method


class DatabricksGroupManager(DatabricksAPI):
    """Manages groups and user assignments in Azure Databricks."""

    task_name = "DatabricksGroupManager"

    def __init__(self) -> None:
        """Initializes the DatabricksGroupManager class."""
        super().__init__()

    def read_input_tables(self, context: TaskContext, conf: DatabricksApiConfig) -> list[dict[str, list[str]]]:
        """Reads the input tables and returns a list of groups and their associated users.

        This method performs the following steps:
        1. Reads the LPI and LoginName columns from the LPI table.
        2. Reads the Login_Name and Mail columns from the user attributes table, converting Login_Name to uppercase.
        3. Reads the LPI and Mail columns from the LPI user mapping table.
        4. Joins the LPI table with the user attributes table on the LoginName column.
        5. Performs a left anti join with the LPI user mapping table to exclude rows that already exist in the mapping.
        6. Groups the resulting DataFrame by LPI and collects the associated emails into a list.

        Args:
            context (TaskContext): The task context containing the Spark session.
            conf (DatabricksApiConfig): Configuration object containing table names.

        Returns:
            list[dict[str, list[str]]]: A list of dictionaries, where each dictionary contains:
                - 'name' (str): The LPI group name.
                - 'users' (list[str]): A list of email addresses associated with the group.
        """
        lpi_login_df = context.spark.read.table(conf.lpi_table).select(
            col("lpi").alias("LPI"),
            col("login_name").alias("LoginName"),
        )
        login_mail_df = context.spark.read.table(conf.user_attributes_table).select(
            upper("Login_Name").alias("LoginName"), "Mail"
        )
        lpi_mail_df = context.spark.read.table(conf.lpi_user_mapping_table).select("LPI", "Mail")

        joined_df = lpi_login_df.join(login_mail_df, on="LoginName", how="inner")
        joined_df = joined_df.join(lpi_mail_df, ["LPI", "Mail"], how="left_anti")

        result_df = joined_df.groupBy("LPI").agg(collect_list("Mail").alias("users"))

        return [{"name": row["LPI"], "users": row["users"]} for row in result_df.collect()]

    def process_groups(
        self, groups: list[dict[str, list[str]]], context: TaskContext, conf: DatabricksApiConfig
    ) -> None:
        """Processes the list of groups and users to create groups, assign users, and manage group assignments.

        This method handles the creation of groups, assigns users to the created groups, and performs
        additional management tasks such as assigning groups to workspaces and linking management groups.

        Args:
            groups (list[dict[str, list[str]]]): A list of dictionaries where each dictionary represents
                a group with its associated users. Each dictionary should have a "name" key for the group
                name and a "users" key containing a list of user identifiers.
            context (TaskContext): The task context object used for logging, error handling, and Spark
                session access.
            conf (DatabricksApiConfig): The configuration object containing API settings, target schema,
                and table names.

        Returns: None: The method does not return any value. It writes the results of successful user
            assignments to a specified table.

        Raises:
            ValueError: If any required configuration or context is missing or invalid.
            RuntimeError: If critical operations such as group creation or user assignment fail.

        Notes:
            - This method logs detailed information about the processing of each group, including
              successes and failures.
            - It ensures that the "LPI_admins" group is assigned to each created group if applicable.
            - Audit columns are added to the resulting DataFrame before writing to the target table.
        """
        groups_dict = self.fetch_all_group_ids(context, conf)
        lpi_admins_id = self.handle_group_creation(conf.admin_group, groups_dict, context, conf)
        successful_additions = []

        for group in groups:
            group_name: str = str(group["name"])
            context.logger.info(f"Processing group: {group_name}")

            group_id = self.handle_group_creation(group_name, groups_dict, context, conf)
            context.logger.info(f"Group Id is : {group_id}")

            if group_id is None:
                context.logger.error(f"Failed to create group '{group_name}'. Skipping user assignments.")
                continue

            principal_id = self.assign_group_to_workspace(group_id, context, conf)

            if principal_id is None:
                context.logger.error(f"Failed to assign group {group_name} to workspace. Skipping user assignments.")
                continue

            if lpi_admins_id:
                self.assign_user_id_to_group(lpi_admins_id, group_id, context, conf)
                etag = self.get_etag_for_rule_set(group_id, context, conf)
                if etag:
                    self.assign_management_group(group_id, etag, context, conf)
                    successful_additions.append({"user": "LPI_admins", "group": group_name})
                context.logger.info(f"Assigned LPI_admins to group: {group_name}")

            user_assignments = self.assign_users_to_group(group["users"], group_id, context, conf)

            # Extend successful_additions with user and group name
            successful_additions.extend([{"user": entry["user"], "group": group_name} for entry in user_assignments])

            rows = [Row(user=entry["user"], group=entry["group"]) for entry in successful_additions]

            df = context.spark.createDataFrame(rows, conf.target_schema)

            df_audit = add_audit_cols_snake_case(df=df, logger=context.logger)

            self.write_to_table(df_audit, conf.lpi_user_mapping_table, context)

    def write_to_table(self, df: DataFrame, target_table: str, context: TaskContext) -> None:
        """Writes the provided DataFrame to the specified target table in append mode.

        Args:
            df (DataFrame): The DataFrame to be written to the target table.
            target_table (str): The name of the target table where the DataFrame will be written.
            context (TaskContext): The task context containing logger and other runtime information.

        Raises:
            Exception: Logs an error message if writing to the table fails.
        """
        try:
            df.write.mode("append").saveAsTable(target_table)
        except Exception as e:
            context.logger.error(f"Failed to write DataFrame to table: {e}")

    def assign_users_to_group(
        self, users: list[str], group_id: str, context: TaskContext, conf: DatabricksApiConfig
    ) -> list[dict[str, str]]:
        """Assigns a list of users to a specified group in the Databricks workspace.

        This method validates if each user exists in the workspace, retrieves their user ID,
        and assigns them to the specified group if they are valid.

        Args:
            users (list[str]): A list of usernames to be assigned to the group.
            group_id (str): The ID of the group to which the users will be assigned.
            context (TaskContext): The task context containing logging and other utilities.
            conf (DatabricksApiConfig): The configuration object for interacting with the Databricks API.

        Returns:
            list[dict[str, str]]: A list of dictionaries containing the user and group information
                                  for each successful assignment. Each dictionary has the keys:
                                  - "user": The username of the assigned user.
                                  - "group": The ID of the group to which the user was assigned.
        """
        additions = []
        for user in users:
            context.logger.info(f"Validating if user: {user} exists in workspace")
            user_id = self.get_user_id(user, context, conf)
            if user_id != "0":
                self.assign_user_id_to_group(user_id, group_id, context, conf)
                additions.append({"user": user, "group": group_id})
        return additions

    def handle_group_creation(
        self, group_name: str, groups_dict: dict[str, str], context: TaskContext, conf: DatabricksApiConfig
    ) -> str | None:
        """Handles group creation if it doesn't already exist.

        Args:
            group_name (str): The name of the group to create or retrieve.
            groups_dict (dict[str, str]): A dictionary mapping group names to their IDs.
            context (TaskContext): The context for logging and error handling.
            conf (DatabricksApiConfig): The configuration object containing API settings.

        Returns:
            str | None: The ID of the group if created or fetched, or None if creation failed.
        """
        if group_name not in groups_dict:
            context.logger.info(f"Creating group: {group_name}")
            group_id = self.create_group(group_name, context, conf)
            if group_id is not None:
                groups_dict[group_name] = group_id
        else:
            group_id = groups_dict[group_name]
        return group_id

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Orchestrates the reading of tables, group creation, and user assignments.

        Args:
            context (TaskContext): The context for logging and error handling.
            conf (Configuration): The configuration object containing task settings.
        """
        context.logger.info("Starting group processing...")
        conf = self.start_task(context, conf)

        _conf = cast(DatabricksApiConfig, conf)

        self.initialize_headers(context, _conf)

        groups = self.read_input_tables(context, _conf)

        self.process_groups(groups, context, _conf)

        context.logger.info("Completed group processing.")
