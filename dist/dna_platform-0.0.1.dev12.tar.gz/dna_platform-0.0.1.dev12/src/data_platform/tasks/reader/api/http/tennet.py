import datetime
from time import sleep
from typing import Any, cast

from requests import Response

import data_platform.common
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import ApiReaderConfig, BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.accept_csv import AcceptCsvHeader
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy
from data_platform.tasks.reader.api.http.headers.tennet_auth import TennetAuthHeader
from data_platform.tasks.reader.api.http.request_reader import RequestsApiReaderTask


class TennetMeritOrderIterateApiTask(ETLTask):
    """Class to iterate over the TennetMeritOrderIterateApiTask and return."""

    task_name = "TennetMeritOrderIterateApiTask"
    dataclass = ApiReaderConfig

    @staticmethod
    def _validate_api_params(_conf: ApiReaderConfig) -> dict:
        api_parameters = _conf.api_get_params or {}
        if api_parameters == {}:
            raise ValueError("Missing any API Parameters for Task")
        if "start_date" not in api_parameters:
            raise ValueError("Missing required start_date for API call")
        return api_parameters

    @staticmethod
    def _calculate_start_date(context: TaskContext, volume_path: str, api_parameters: dict) -> datetime:
        """Determine date to load from and if full/delta load."""
        file_list = data_platform.common.get_dbutils(context.spark).fs.ls(f"{volume_path}")

        if len(file_list) == 0:
            return datetime.datetime.strptime(api_parameters["start_date"], "%d-%m-%Y")
        else:
            file_name_list = [file.name for file in file_list]
            file_name_list.sort(reverse=True)
            latest_file = file_name_list[1] if ("checkpoint" in file_name_list[0]) else file_name_list[0]
            latest_day = latest_file.split("_")[2]
            latest_day_dt = datetime.datetime.strptime(latest_day, "%d-%m-%Y")
            delta_days = int(api_parameters.get("delta_load_window_days", 0))
            start_date_dt = latest_day_dt - datetime.timedelta(days=(delta_days - 1))
            return start_date_dt

    @staticmethod
    def _iterate_api(context: TaskContext, conf: Configuration, date_to_load: datetime.datetime) -> None:
        """Execute API request and return response."""
        context.logger.info(f"API Reader Config: {conf}")
        api_reader_task = TennetMeritOrderApiReaderTask()
        today = datetime.datetime.now()
        while date_to_load < today:
            newconf = conf.as_dict()
            newconf["api_get_params"]["target_day"] = date_to_load.strftime("%d-%m-%Y")
            api_reader_task.execute(context, Configuration(newconf))
            date_to_load = date_to_load + datetime.timedelta(days=1)
            # sleep to avoid racing the API rate limit
            sleep(2)

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Main method of TennetMeritOrderIterateApiTask."""
        _conf = self.start_task(context, conf)
        _conf = cast(ApiReaderConfig, _conf)

        api_parameters = self._validate_api_params(_conf)

        # Determine start date
        start_date = self._calculate_start_date(context, _conf.volume_storage_path, api_parameters)
        str_start_date = start_date.strftime("%d-%m-%Y")
        context.logger.info(f"Start Date is: {str_start_date}")

        # Iterate invoking APIReaderTask
        self._iterate_api(context, conf, start_date)


class TennetMeritOrderApiReaderTask(RequestsApiReaderTask):
    """Class to invoke Tennet Merit Order API to retrieve aFRR energy prices for a day."""

    task_name = "TennetMeritOrderApiReaderTask"
    verify = True

    def __init__(self) -> None:
        """Initialize the TennetMeritOrderApiReaderTask with the configuration dataclass."""
        self.http_headers: list[HttpHeaderStrategy] = [TennetAuthHeader(), AcceptCsvHeader()]
        self.dataclass = ApiReaderConfig

    def prepare_request(self, context: TaskContext, conf: BaseApiReaderConfig) -> dict:
        """Prepare the payload for the API request.

        Args:
            context (TaskContext): The context for task execution.
            conf (Configuration): The configuration containing API parameters.

        Returns:
            dict: A dictionary representing the payload for the API request.
        """
        _conf = cast(ApiReaderConfig, conf)
        api_parameters = _conf.api_get_params or {}
        if "target_day" not in api_parameters:
            raise ValueError("Missing required target day for API call")

        return {}

    def prepare_params(self, context: TaskContext, conf: BaseApiReaderConfig, params: dict | None = None) -> dict:
        """Prepare additional parameters for the API request.

        Args:
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing API parameters.
            params (dict | None): Optional initial parameters to be extended.

        Returns:
            dict: A dictionary of additional parameters for the API request.
        """
        _conf = cast(ApiReaderConfig, conf)
        api_parameters = _conf.api_get_params
        params = params or {}

        target_day = api_parameters["target_day"]
        start_timestamp = datetime.datetime.strptime(target_day, "%d-%m-%Y")
        end_timestamp = start_timestamp + datetime.timedelta(days=1)
        params["date_from"] = start_timestamp.strftime("%d-%m-%Y %H:%M:%S")
        params["date_to"] = end_timestamp.strftime("%d-%m-%Y %H:%M:%S")

        return params

    def extract_content(self, context: TaskContext, conf: BaseApiReaderConfig, response: Response) -> object:
        """Extract the content from the API response.

        Args:
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing API parameters.
            response (Response): The HTTP response object from the API request.

        Returns:
            object: The extracted content from the response if successful.

        Raises:
            ValueError: If the API request fails with a non-200 status code.
        """
        if response.status_code == 200:
            return response.content
        else:
            context.logger.error(f"Tennet API Call Failed: {response.status_code} - {response.text}")
            raise ValueError(f"Tennet API request failed with status code {response.status_code}")

    def save_to_volume(self, content: Any, context: TaskContext, conf: BaseApiReaderConfig) -> None:
        """Save the API response content to a CSV file in the specified volume.

        Args:
            content (Any): The raw content from the API response.
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing storage path.

        Returns:
            None
        """
        _conf = cast(ApiReaderConfig, conf)
        api_parameters = _conf.api_get_params or {}
        target_day = api_parameters["target_day"]
        target_day_dt = datetime.datetime.strptime(target_day, "%d-%m-%Y")
        epoch = int(target_day_dt.timestamp())
        timestamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")

        file_path = f"{conf.volume_storage_path}/{epoch}_meritorderrecords_{target_day}_{timestamp}.{conf.file_format}"
        with open(file_path, "wb") as file:
            file.write(content)
        context.logger.info(f"CSV file saved to {file_path}")
