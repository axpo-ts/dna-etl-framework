# CPD-OFF - suppress copy paste detection on imports


from typing import cast

from pyspark.sql import DataFrame
from pyspark.sql.functions import lower, upper
from pyspark.sql.types import StringType, StructField, StructType

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BearerApiReaderConfig
from data_platform.tasks.reader.api.http.headers.access_token_bearer import AccessTokenBearerAuthHeader
from data_platform.tasks.reader.api.http.headers.json_content_type import JsonContentTypeHeader
from data_platform.tasks.reader.api.utils import execute_http_request

# CPD-ON - suppress copy paste detection on imports


class MdlmApiReaderTask(ETLTask):
    """Task for reading user data from an API based on input DataFrame."""

    task_name = "MdlmApiReaderTask"

    def __init__(self) -> None:
        """Initialize the UserApiReaderTask with default HTTP headers, configuration dataclass, and timeout."""
        super().__init__()
        self.http_headers = [
            JsonContentTypeHeader(),
            AccessTokenBearerAuthHeader(),
        ]
        self.dataclass = BearerApiReaderConfig  # Set the data class for configuration
        self.timeout = 1800  # Set timeout to 1800 seconds

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the API call and process the input DataFrame.

        This method performs the following steps:
        - Initializes the task configuration using `start_task`.
        - Retrieves the input DataFrame from the context based on the provided namespace and key.
        - Processes the input DataFrame to prepare it for API requests.
        - Prepares filter conditions based on the processed DataFrame.
        - Makes API requests using the prepared filter conditions and configuration.
        - Transforms the API response into a DataFrame.
        - Stores the resulting DataFrame in the context for further use.

        Args:
            context (TaskContext): The task execution context, which provides access to shared properties.
            conf (Configuration): The task configuration object containing necessary parameters.

        Returns:
            None
        """
        # Get the input DataFrame from the context
        conf = self.start_task(context, conf)

        _conf = cast(BearerApiReaderConfig, conf)

        df: DataFrame = context.get_property(
            namespace=_conf.api_time_window["df_input_namespace"], key=_conf.api_time_window["df_input_key"]
        )

        processed_df = self.process_dataframe(context, df, _conf.api_time_window["target_table"])

        filter_conditions = self.prepare_filter_conditions(processed_df)

        extracted_info = self.make_api_requests(filter_conditions, context, _conf)

        output_df = self.transform_response_to_dataframe(context, processed_df, extracted_info)

        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=output_df)

    def make_api_requests(self, chunks: list, context: TaskContext, conf: BearerApiReaderConfig) -> list:
        """Make API calls for each chunk of filter conditions and extract specific information.

        Args:
            chunks (list): A list of chunks, where each chunk is a list of filter conditions
            to be applied in the API request.
            context (TaskContext): The task context object containing logger and other runtime information.
            conf (BearerApiReaderConfig): Configuration object containing API details such as base URL
            and authentication information.

        Returns:
            list: A list of tuples containing extracted information from the API response.
            Each tuple contains the email, surname, and given name of a person.

        """
        base_url = conf.api_url
        select_url = conf.api_time_window["select_url"]
        extracted_info = []
        original_api_url = conf.api_url

        for chunk in chunks:
            filter_string = " or ".join(chunk)
            final_url = f"{base_url}({filter_string}){select_url}"

            conf.api_url = final_url

            context.logger.info(f"\n\n\t url: {conf.api_url}")

            # Reuse the execute_request method
            response = execute_http_request(
                context=context,
                conf=conf,
                payload={},
                http_headers=self.http_headers,
                timeout=self.timeout,
                verify=True,
            )

            if response.status_code == 200:
                res = response.json()
                extracted_info.extend(
                    [
                        (person.get("mailNickname"), person.get("mail"), person.get("surname"), person.get("givenName"))
                        for person in res.get("value", [])
                    ]
                )
                context.logger.info(f"\n\n\t extracted info: {extracted_info}")
            else:
                context.logger.error(f"API request failed with status {response.status_code}: {response.text}")
                raise ValueError(f"Failed to fetch data from API: {response.text}")

            # Reset URL to base for next iteration to avoid appending filters
            conf.api_url = original_api_url

        return extracted_info

    def process_dataframe(self, context: TaskContext, df: DataFrame, target_table: str) -> DataFrame:
        """Processes the input DataFrame to clean and prepare data for further use.

        This method performs the following operations:
        1. Reads the target table from the Spark context and selects distinct login names.
        2. Compares the input DataFrame with the target DataFrame to exclude overlapping records.

        Args:
            context (TaskContext): The task context containing the Spark session and other configurations.
            df (DataFrame): The input DataFrame containing login names to be processed.
            target_table (str): The name of the target table to compare against.

        Returns:
            DataFrame: A processed DataFrame containing the cleaned login names and additional extracted columns.
        """
        target_df = context.spark.read.table(target_table).select(upper("login_name").alias("LoginName")).distinct()
        df = df.select(upper("login_name").alias("LoginName")).distinct()
        df = df.exceptAll(target_df)
        return df.select("LoginName")

    def prepare_filter_conditions(self, df: DataFrame) -> list:
        """Prepare filter conditions for the API request.

        This method takes a DataFrame containing names and generates a list of filter
        conditions to be used in API requests. Each condition is a string that checks
        if the given name and surname start with specified values. The conditions are
        grouped into chunks, with each chunk containing a maximum of `max_conditions`
        conditions.

        Args:
            df (DataFrame): A Spark DataFrame containing the columns 'FirstName' and
                            'SurName' to generate filter conditions.

        Returns:
            list: A list of lists, where each inner list contains up to `max_conditions`
                  filter condition strings.
        """
        names_df = df.collect()
        max_conditions = 7
        filter_conditions = [f"(mailNickname eq '{row['LoginName']}')" for row in names_df]

        # Split into chunks
        return [filter_conditions[i : i + max_conditions] for i in range(0, len(filter_conditions), max_conditions)]

    def transform_response_to_dataframe(
        self, context: TaskContext, input_df: DataFrame, extracted_info: list
    ) -> DataFrame:
        """Transform the extracted API response into a DataFrame.

        This method processes a list of extracted information from an API response
        and transforms it into a Spark DataFrame. It performs the following steps:
        - Creates a DataFrame from the extracted information with specified columns.
        - Generates a "CleanedLoginName" column by concatenating substrings of "GivenName" and "SurName".
        - Identifies rows with special characters in "CleanedLoginName" and adjusts the value
          using parts of the "Mail" column if special characters are found.
        - Filters out rows where the "Mail" column is null.
        - Joins the transformed DataFrame with an input DataFrame on the "CleanedLoginName" column
          (case-insensitive match).
        - Selects and renames specific columns for the final output.

        Args:
            context (TaskContext): The task context containing the Spark session.
            input_df (DataFrame): The input DataFrame containing existing data.
            extracted_info (list): A list of dictionaries or records extracted from the API response.

        Returns:
            DataFrame: A transformed Spark DataFrame with the following columns:
                - login_name: The login name from the input DataFrame.
                - mail: The email address from the extracted information.
                - sur_name: The surname from the extracted information.
                - given_name: The given name from the extracted information.
        """
        output_schema = StructType(
            [
                StructField("login_name", StringType(), True),
                StructField("mail", StringType(), True),
                StructField("sur_name", StringType(), True),
                StructField("given_name", StringType(), True),
            ]
        )

        user_schema = StructType(
            [
                StructField("MailNickname", StringType(), True),
                StructField("Mail", StringType(), True),
                StructField("SurName", StringType(), True),
                StructField("GivenName", StringType(), True),
            ]
        )
        if not extracted_info:
            context.logger.warning("No data extracted from API. Returning empty DataFrame.")
            return context.spark.createDataFrame([], output_schema)

        df = context.spark.createDataFrame(extracted_info, user_schema).filter("Mail is not null")

        df = (
            df.alias("source")
            .join(input_df.alias("target"), lower(df.MailNickname) == lower(input_df.LoginName), "left")
            .select(
                df.MailNickname.alias("login_name"),
                df.Mail.alias("mail"),
                df.SurName.alias("sur_name"),
                df.GivenName.alias("given_name"),
            )
        )

        return df
