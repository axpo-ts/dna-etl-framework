from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy


class JsonContentTypeHeader(HttpHeaderStrategy):
    """Class to add application/json content type."""

    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """Adds Content-Type application/json."""
        content_header = {"Content-Type": "application/json"}
        headers.update(content_header)
        return headers
