from abc import ABC, abstractmethod

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig


class HttpHeaderStrategy(ABC):
    """Abstract class for HTTP Header Implementations.

    Extend to implement different HTTP Headers
    """

    @abstractmethod
    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """No implementation to be overridden."""
        pass
