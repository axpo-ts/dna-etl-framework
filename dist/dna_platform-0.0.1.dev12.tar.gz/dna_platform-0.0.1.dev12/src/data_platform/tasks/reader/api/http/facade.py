from collections.abc import Iterator

import requests
from pyspark.sql import SparkSession
from pyspark.sql.functions import udtf


def get_is_member_flag(group: str) -> bool:
    """Checks if the current user is a member of the specified group.

    Args:
        group (str): The name of the group to check membership for.

    Returns:
        bool: True if the user is a member of the group, False otherwise.
    """
    spark = SparkSession.getActiveSession()
    if spark is None:
        raise RuntimeError("No active Spark session found.")
    res = spark.sql(f"SELECT is_member('{group}')").collect()[0][0]
    return bool(res)


# Embed flag into class (serialized safely as bool)
IS_FACADE_USER = get_is_member_flag("DNA_FACADE")


@udtf(
    returnType="""
    product STRING,
    start_date STRING,
    end_date STRING,
    timeStampInZone STRING,
    inTradingTime BOOLEAN,
    askBestPrice DOUBLE,
    askSumVolume DOUBLE,
    askBest10MWPrice DOUBLE,
    askBest30MWPrice DOUBLE,
    bidBestPrice DOUBLE,
    bidSumVolume DOUBLE,
    bidBest10MWPrice DOUBLE,
    bidBest30MWPrice DOUBLE,
    timeStamp STRING,
    count BIGINT,
    standardProductName STRING
"""
)
class OrderStatisticsUDTF:
    """A UDTF (User Defined Table Function) for fetching and processing order statistics.

    From an external API based on the provided products and date ranges.
    """

    # CPD-OFF - suppress copy paste detection on doc string
    def eval(self, products: list[str], start_dates: list[str], end_dates: list[str]) -> Iterator:
        """Processes the provider array of products and date ranges, fetching data from an external API.

        Args:
            products (list[str]): List of product identifiers.
            start_dates (list[str]): List of start dates for the data range.
            end_dates (list[str]): List of end dates for the data range.

        Yields:
            tuple: Processed data rows containing product, date range, and provides the Order statistics.
        """
        if not IS_FACADE_USER:
            return

        for product, start_date, end_date in zip(products, start_dates, end_dates):
            source = "OrderStatistics"
            url = f"https://set_dev.prod.axponet.ch:9138/api/{source}/{product}?start={start_date}&end={end_date}&timeZone=CET&step=Minute&stepSize=1&keepEmptyBuckets=false"
            resp = requests.get(url, headers={"Content-Type": "application/json"}, timeout=60, verify=False)
            data = resp.json().get("data", [])
            for row in data:
                yield (
                    product,
                    start_date,
                    end_date,
                    row.get("timeStampInZone"),
                    row.get("inTradingTime"),
                    row.get("askBestPrice"),
                    row.get("askSumVolume"),
                    row.get("askBest10MWPrice"),
                    row.get("askBest30MWPrice"),
                    row.get("bidBestPrice"),
                    row.get("bidSumVolume"),
                    row.get("bidBest10MWPrice"),
                    row.get("bidBest30MWPrice"),
                    row.get("timeStamp"),
                    row.get("count"),
                    row.get("standardProductName"),
                )

    # CPD-ON - suppress copy paste detection on doc string


@udtf(
    returnType="""
    product STRING,
    start_date STRING,
    end_date STRING,
    startInZone STRING,
    endInZone STRING,
    inTradingTime BOOLEAN,
    open DOUBLE,
    high DOUBLE,
    low DOUBLE,
    close DOUBLE,
    volume DOUBLE,
    weightedAverage DOUBLE,
    paidVolume DOUBLE,
    paidWeightedAverage DOUBLE,
    givenVolume DOUBLE,
    givenWeightedAverage DOUBLE,
    startUtc STRING,
    endUtc STRING,
    count BIGINT,
    standardProductName STRING
"""
)
class TradeStatisticsUDTF:
    """A UDTF (User Defined Table Function) for fetching and processing Trade statistics.

    From an external API based on the provided products and date ranges.
    """

    # CPD-OFF - suppress copy paste detection on doc string
    def eval(self, products: list[str], start_dates: list[str], end_dates: list[str]) -> Iterator:
        """Processes the provided array list of products and date ranges, fetching data from an external API.

        Args:
            products (list[str]): List of product identifiers.
            start_dates (list[str]): List of start dates for the data range.
            end_dates (list[str]): List of end dates for the data range.

        Yields:
            tuple: Processed data rows containing product, date range, and provides the Trade statistics.
        """
        if not IS_FACADE_USER:
            return
        for product, start_date, end_date in zip(products, start_dates, end_dates):
            source = "TradeStatistics"
            url = f"https://set_dev.prod.axponet.ch:9138/api/{source}/{product}?start={start_date}&end={end_date}&timeZone=CET&step=Minute&stepSize=1&keepEmptyBuckets=false"
            resp = requests.get(url, headers={"Content-Type": "application/json"}, timeout=60, verify=False)
            data = resp.json().get("data", [])
            for row in data:
                yield (
                    product,
                    start_date,
                    end_date,
                    row.get("startInZone"),
                    row.get("endInZone"),
                    row.get("inTradingTime"),
                    row.get("open"),
                    row.get("high"),
                    row.get("low"),
                    row.get("close"),
                    row.get("volume"),
                    row.get("weightedAverage"),
                    row.get("paidVolume"),
                    row.get("paidWeightedAverage"),
                    row.get("givenVolume"),
                    row.get("givenWeightedAverage"),
                    row.get("startUtc"),
                    row.get("endUtc"),
                    row.get("count"),
                    row.get("standardProductName"),
                )

    # CPD-ON - suppress copy paste detection on doc string


@udtf(
    returnType="""
    product STRING,
    start_date STRING,
    end_date STRING,
    standardProductName STRING,
    price DOUBLE,
    timeStampInZone STRING,
    timeStamp STRING
"""
)
class RiskSettlementUDTF:
    """A UDTF (User Defined Table Function) for fetching and processing Risk Settlement data.

    From an external API based on the provided products and date ranges.
    """

    # CPD-OFF - suppress copy paste detection on doc string
    def eval(self, products: list[str], start_dates: list[str], end_dates: list[str]) -> Iterator:
        """Processes the provided products and date ranges, fetching data from the external API.

        Args:
            products (list[str]): List of product identifiers to query.
            start_dates (list[str]): List of start dates for the data range to query.
            end_dates (list[str]): List of end dates for the data range to query.

        Yields:
            tuple: Processed data rows containing product, date range, and provides the settlement data statistics.
        """
        if not IS_FACADE_USER:
            # No access → return nothing
            return
        for product, start_date, end_date in zip(products, start_dates, end_dates):
            source = "SettlementData"
            url = f"https://set_dev.prod.axponet.ch:9138/api/{source}/{product}?start={start_date}&end={end_date}&timeZone=CET&step=Minute&stepSize=1&keepEmptyBuckets=false"
            resp = requests.get(url, headers={"Content-Type": "application/json"}, timeout=60, verify=False)
            data = resp.json().get("data", [])
            for row in data:
                yield (
                    product,
                    start_date,
                    end_date,
                    row.get("standardProductName"),
                    row.get("price"),
                    row.get("timeStampInZone"),
                    row.get("timeStamp"),
                )

    # CPD-ON - suppress copy paste detection on doc string


@udtf(
    returnType="""
    product STRING,
    start_date STRING,
    end_date STRING,
    standardProductName STRING,
    rate DOUBLE,
    quoteDate STRING,
    timeStampInZone STRING,
    `timeStamp` STRING
"""
)
class FXUDTF:
    """A UDTF (User Defined Table Function) for fetching and processing FX (Forex) data.

    From an external API based on the provided products and date ranges.
    """

    # CPD-OFF - suppress copy paste detection on doc string
    def eval(self, products: list[str], start_dates: list[str], end_dates: list[str]) -> Iterator:
        """Processes the provided array of products and date ranges, fetching data from the external API.

        Args:
            products (list[str]): List of product identifiers.
            start_dates (list[str]): List of start dates for the data range.
            end_dates (list[str]): List of end dates for the data range.

        Yields:
            tuple: Processed data rows containing product, date range, and provide FX Trade statistics.
        """
        if not IS_FACADE_USER:
            # No access → return nothing
            return
        for product, start_date, end_date in zip(products, start_dates, end_dates):
            source = "FX/Rate"
            url = f"https://set_dev.prod.axponet.ch:9138/api/{source}/{product}?start={start_date}&end={end_date}&timeZone=CET&step=Minute&stepSize=1&keepEmptyBuckets=false"
            resp = requests.get(url, headers={"Content-Type": "application/json"}, timeout=60, verify=False)
            data = resp.json().get("data", [])
            for row in data:
                yield (
                    product,
                    start_date,
                    end_date,
                    row.get("standardProductName"),
                    row.get("rate"),
                    row.get("quoteDate"),
                    row.get("timeStampInZone"),
                    row.get("timeStamp"),
                )

    # CPD-ON - suppress copy paste detection on doc string


def register_all(spark: SparkSession) -> None:
    """Registers all UDTFs with the provided Spark session.

    Args:
        spark: The Spark session to register the UDTFs with.
    """
    print("Registering UDTFs:")
    udtfs = {
        "risk_settlement_udtf": RiskSettlementUDTF,
        "trade_statistics_udtf": TradeStatisticsUDTF,
        "fx_udtf": FXUDTF,
        "order_statistics_udtf": OrderStatisticsUDTF,
    }

    for name, cls in udtfs.items():
        spark.udtf.register(name, cls)  # type: ignore
        print(f" - {name}")
    print("✅ UDTFs have been registered successfully!")

    # Example usage with explanations
    print("Example usage in SQL:\n")
    print("""
    SELECT *
    FROM trade_statistics_udtf(
        array('Germany Y-2026 Baseload', 'TTF Y-2026', 'Germany Y-2025 Baseload','TTF M12-2025'),
        array('2025-05-24', '2025-05-24', '2024-05-24','2025-08-01'),
        array('2025-08-10', '2025-08-10', '2024-08-10','2025-08-02')
    );
    """)
    print("Parameter explanations:")
    print(" - First array: list of product names (e.g., 'Germany Y-2026 Baseload').")
    print(" - Second array: corresponding start dates for each product (YYYY-MM-DD).")
    print(" - Third array: corresponding end dates for each product (YYYY-MM-DD).")
    print("\n⚠️ Make sure all arrays have the same length, each index corresponds to a single query.")
