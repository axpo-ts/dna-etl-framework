from typing import Any

import requests
from requests import Response

from data_platform.tasks.core import TaskContext


def execute_http_request(
    context: TaskContext,
    conf: Any,
    payload: dict,
    http_headers: list,
    timeout: int,
    verify: bool,
    params: dict | None = None,
) -> Response:
    """DRY Reusable block to send HTTP requests."""
    # Set payload to send to None if not passed in
    tosend = payload if payload else None
    # Default API Method to GET if not sent in via the configuration
    api_method = conf.api_method if hasattr(conf, "api_method") else "GET"
    # Loop and build HTTP headers to use with the request
    headers: dict[str, str] = {}
    for header in http_headers:
        headers = header.append_header(context, conf, headers)
    # Use class timeout if set otherwise set to None
    timeoutmillis = None if timeout == 0 else timeout
    try:
        if api_method == "POST":
            context.logger.info(
                f"POST request to url: {conf.api_url}\n"
                f"payload/body: {tosend}\n"
                f"params: {params}\n"
                f"and headers: {headers}\n"
                f"verify: {verify}"
            )
            response = requests.post(
                url=conf.api_url, json=tosend, headers=headers, timeout=timeoutmillis, verify=verify, params=params
            )

        elif api_method == "GET":
            redacted_headers = {k: v if k.lower() != "authorization" else "REDACTED" for k, v in headers.items()}
            context.logger.info(
                f"GET request to url: {conf.api_url}\n"
                f"params: {params}\n"
                f"and headers: {redacted_headers}\n"
                f"verify: {verify}"
            )
            try:
                response = requests.get(
                    url=conf.api_url, params=params, headers=headers, timeout=timeoutmillis, verify=verify
                )
            except Exception as e:
                context.logger.error(f"API {api_method} for url: {conf.api_url} failed: {e}")
                raise ValueError(f"Failed to download data from the endpoint: {e}") from e
        else:
            message = f"Unknown API method: '{api_method}'"
            context.logger.error(message)
            raise ValueError(message)
        # Raises HTTPError for bad responses
        response.raise_for_status()
        return response
    except requests.RequestException as e:
        context.logger.error(f"API request failed: {e}")
        raise ValueError(f"Failed to download data from the endpoint: {e}") from e
