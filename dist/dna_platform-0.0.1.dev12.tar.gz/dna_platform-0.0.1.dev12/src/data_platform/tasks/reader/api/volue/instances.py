# CPD-OFF - ignore imports
import asyncio
from typing import cast

import nest_asyncio  # type: ignore
import pandas as pd
from pyspark.sql import DataFrame
from pyspark.sql import functions as f

# vit
from volue_insight_timeseries.curves import InstanceCurve

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.volue.volue import VolueAbstractCurveApiBulkReaderTask

# CPD-ON - ignore imports
nest_asyncio.apply()  # type: ignore


class VolueInstancesApiBulkReaderTask(VolueAbstractCurveApiBulkReaderTask):
    """Task for reading from a given API.

    Attributes:
        task_name (str): The name of the task.
        api_url (str): Full API url.

    """

    task_name = "VolueInstancesApiBulkReaderTask"

    # CPD-OFF - ignore multiline method signature across implementations
    async def process_curve(
        self,
        date_from: str,
        date_to: str,
        curve_name: str,
        context: TaskContext,
        curve: InstanceCurve,
        tags: str | None = None,
    ) -> tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]:
        # CPD-ON - ignore multiline method signature across implementations
        """Implementation for Instance Curves."""
        date_from, date_to = self.enforce_correct_curve_dates(
            date_from=date_from,
            date_to=date_to,
            curve=curve,
            context=context,
        )
        search_data_filter_params = {}
        search_data_filter_params["issue_date_from"] = date_from
        search_data_filter_params["issue_date_to"] = date_to
        search_data_filter_params["with_data"] = "false"
        context.logger.info(f"curve_name: {curve_name} | search date params: {search_data_filter_params}")

        ts_list = await asyncio.to_thread(curve.search_instances, **search_data_filter_params)

        return_list = []

        for ts in ts_list:
            api_data_filter_params = {}
            api_data_filter_params["issue_date"] = ts.issue_date
            # Getting data of a specific instance timeseries curve asynchronously
            ts = await asyncio.to_thread(curve.get_instance, **api_data_filter_params)
            cast(pd.Series, ts)
            context.logger.info(f"Got response for {curve_name}-{ts.issue_date}")
            return_list.append((curve_name, str(ts.issue_date), ts))

        return return_list  # type: ignore

    # CPD-OFF - ignore multiline method signature across implementations
    def process_results(
        self,
        results: list[tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]],
        context: TaskContext | None = None,
    ) -> list[pd.DataFrame]:
        # CPD-ON - ignore multiline method signature across implementations
        """Convert raw results into Spark DataFrames directly.

        Args:
        results: Curve results with forecast data.
        context: Task execution context.

        Returns:
            list[DataFrame]: List of Spark DataFrames.
        """
        if not context:
            raise ValueError("Context cannot be None when processing DataFrame.")
        pdf_list: list[pd.DataFrame] = []

        for curve in results:
            for forecast in curve:
                pdf = (
                    forecast[2]  # type: ignore
                    .to_pandas()
                    .to_frame()
                    .reset_index()
                    .assign(curve_name=forecast[0])
                    .assign(issued_at=forecast[1])
                )
                pdf.columns = ["value_at", "value", "curve_name", "issued_at"]

                if not pdf.empty:
                    pdf_list.append(pdf)
        return pdf_list

    def process_df(
        self, df: DataFrame, context: TaskContext | None = None, api_get_params: dict[str, str] | None = None
    ) -> DataFrame:
        """Overridable method to select columns from a DataFrame."""
        if not context:
            raise ValueError("Context cannot be None when processing DataFrame.")
        df = df.select(
            f.col("issued_at"),
            f.col("curve_name"),
            f.col("value_at"),
            f.col("value"),
        )

        target_table = (
            f"{api_get_params['catalog_name']}.{api_get_params['schema_name']}.{api_get_params['table']}"
            if api_get_params and all(api_get_params.get(key) for key in ["catalog_name", "schema_name", "table"])
            else None
        )

        if target_table:
            df.write.mode("append").saveAsTable(target_table)
            context.logger.warning(f"Data written into table: {target_table}")
            del df  # To free up memory
            return context.spark.createDataFrame([], "string")

        context.logger.warning("Target table is not specified. Skipping saveAsTable operation.")
        return df
