import os

try:
    import smbclient  # type: ignore
except ImportError:
    smbclient = None

from datetime import datetime

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.config.dataclasses import SimpleFileTransferConfig


class SimpleFileTransferTask(ETLTask):
    """Task for transferring files between an SMB share and specified volumes.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleFileTransferConfig]): The configuration dataclass.
    """

    task_name = "SimpleFileTransferTask"
    dataclass = SimpleFileTransferConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleFileTransferTask.

        Transfers files from an SMB share to specified volume locations based on filename criteria.

        Args:
            context (TaskContext): The task context.
            conf (SimpleFileTransferConfig): The task configuration containing information such as
                                             SMB host, path, and volume destinations.
        """
        _conf = self.start_task(context, conf)

        # Retrieve SMB credentials
        credentials = self.get_credentials(context, _conf)

        # Configure smbclient with the retrieved credentials
        self.configure_smb_client(credentials)

        # Perform file transfer
        self.transfer_files(context, _conf)

    def get_credentials(self, context: TaskContext, conf: SimpleFileTransferConfig) -> dict[str, str]:
        """Retrieve SMB credentials from the context.

        Args:
            context (TaskContext): The task context.
            conf (SimpleFileTransferConfig): The configuration containing secret keys.

        Returns:
            Dict[str, str]: A dictionary of credentials retrieved from the context.
        """
        credentials = {}
        for key in conf.secret_keys:
            credentials[key] = context.get_property(namespace=conf.secret_namespace, key=key)
        return credentials

    def configure_smb_client(self, credentials: dict[str, str]) -> None:
        """Configure the smbclient with provided credentials.

        Args:
            credentials (Dict[str, str]): A dictionary of credentials for the smbclient.
        """
        cred_values = list(credentials.values())
        smbclient.ClientConfig(username=cred_values[0], password=cred_values[1])

    def transfer_files(self, context: TaskContext, conf: SimpleFileTransferConfig) -> None:
        """Transfer files based on filename criteria to specified volumes.

        Args:
            context (TaskContext): The task context.
            conf (SimpleFileTransferConfig): The configuration containing SMB paths.
        """
        unc_path = r"\\" + conf.host + conf.path
        context.logger.info(f"Transferring files from SMB path: {unc_path}")

        try:
            for filename in smbclient.listdir(unc_path):
                self.process_file(context, filename, unc_path, conf)
        except Exception as e:
            context.logger.error(f"An error occurred: {e}")

    def process_file(self, context: TaskContext, filename: str, unc_path: str, conf: SimpleFileTransferConfig) -> None:
        """Process each file and determine its destination based on filename.

        Args:
            context (TaskContext): The task context.
            filename (str): The name of the file to process.
            unc_path (str): The UNC path of the SMB share.
            conf (SimpleFileTransferConfig): The configuration containing volume paths.
        """
        smb_file_path = os.path.join(unc_path, filename)
        context.logger.info(f"TDFS Filepath {smb_file_path}.")
        if self.is_file(smb_file_path):
            volume_file_path = self.get_destination_volume(filename, conf)
            if volume_file_path:
                self.copy_file_to_volume(smb_file_path, volume_file_path, context)
            else:
                context.logger.info(f"Skipped {filename}: does not match any criteria.")
        else:
            context.logger.error(f"{smb_file_path} is not a file, skipping.")

    def get_destination_volume(self, filename: str, conf: SimpleFileTransferConfig) -> str | None:
        """Determine the destination volume based on the filename.

        Args:
            filename (str): The name of the file to check.
            conf (SimpleFileTransferConfig): The configuration containing volume paths.

        Returns:
            str | None: The path to the destination volume, or None if no match is found.
        """
        if "lpidefinition" in filename.lower():
            return os.path.join(conf.lpidefinition_volume, filename)
        elif "enduserentitlement" in filename.lower():
            return os.path.join(conf.enduserentitlement_volume, filename)
        return None

    def is_file(self, file_path: str) -> bool:
        """Checks if the specified path is a file.

        Args:
            file_path (str): The path to check.

        Returns:
            bool: True if the path is a file, False otherwise.
        """
        return smbclient.stat(file_path).st_mode != 0

    def copy_file_to_volume(self, smb_file_path: str, volume_file_path: str, context: TaskContext) -> None:
        """Copies a file from SMB to the specified volume location with a date and time suffix.

        Args:
            smb_file_path (str): The path of the file on the SMB share.
            volume_file_path (str): The destination path on the local volume.
            context (TaskContext): The task context.
        """
        # Get the current date and time in yyyyMMddHHmmss format
        date_suffix = datetime.now().strftime("%Y%m%d%H%M%S")

        # Extract file name and extension
        file_name, file_extension = os.path.splitext(os.path.basename(volume_file_path))

        # Create new file path with date and time suffix
        new_volume_file_path = os.path.join(
            os.path.dirname(volume_file_path), f"{file_name}_{date_suffix}{file_extension}"
        )

        with smbclient.open_file(smb_file_path, mode="rb") as smb_file:
            with open(new_volume_file_path, "wb") as volume_file:
                volume_file.write(smb_file.read())

        context.logger.info(f"Moved {os.path.basename(smb_file_path)} to {new_volume_file_path}")
