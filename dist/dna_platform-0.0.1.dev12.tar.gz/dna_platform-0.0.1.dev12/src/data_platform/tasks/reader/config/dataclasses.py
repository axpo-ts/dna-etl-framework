from dataclasses import dataclass, field

from data_platform.tasks.config.dataclasses import BaseCatalogConfig


@dataclass(kw_only=True)
class SimpleReaderConfig(BaseCatalogConfig):
    """Configuration class for SimpleBatchReaderTask, SimpleBatchFileReaderTask, SimpleStreamingTableReaderTask.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        format (str): The format of the data source.
        path (str, optional): The path to the data source (for file-based tasks).
        reader_options (Dict[str, str]): Additional reader options as a dictionary.
        secret_key (str, optional): The key of the secret in databricks secrets.
        secret_namespace (str, optional): The namespace in which the secret is stored in the task context.
        secret_options_name (str, optional): The reader option name for the secret
        schema (str, optional): Optional option to provide string schema to use on read
        include_metadata (bool, optional): Optional flag to include metadata in the read operation. Default is False
            (for file based tasks).
        filter_clause (Dict[str, str]): An optional dictionary config to filter the table.
        watermark_days (int, optional): The number of days to use for the watermark filter.
        watermark_filter_col (str, optional): The column to use for the watermark filter.
    """

    _format: str
    path: str | None = None
    reader_options: dict[str, str] = field(default_factory=dict)
    secret_key: str = ""
    secret_namespace: str = ""
    secret_options_name: str = ""
    schema: str | None = None
    include_metadata: bool = False
    filter_options: dict[str, str] = field(default_factory=dict)
    watermark_days: int | None = None
    watermark_filter_col: str | None = None


@dataclass(kw_only=True)
class SimpleFileTransferConfig:
    """Configuration for the SimpleFileTransferTask.

    Attributes:
        secret_namespace (str): Namespace for storing secrets.
        secret_keys (List[str]): List of keys for retrieving credentials.
        smb_host (str): The hostname or IP address of the SMB server.
        smb_path (str): The path to the SMB share.
        lpidefinition_volume (str): Path to the volume for LPiDefinition files.
        enduserentitlement_volume (str): Path to the volume for EndUserEntitlement files.
    """

    task_name: str
    secret_namespace: str
    secret_keys: list[str]
    host: str
    path: str
    lpidefinition_volume: str
    enduserentitlement_volume: str
