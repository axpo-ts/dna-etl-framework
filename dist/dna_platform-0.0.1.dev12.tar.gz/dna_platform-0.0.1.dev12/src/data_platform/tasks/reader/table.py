from pyspark.sql import DataFrame

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.config.dataclasses import SimpleReaderConfig
from data_platform.tasks.utils import CatalogUtilities


class SimpleBatchReaderTask(ETLTask):
    """Task for reading batch data from a table.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleBatchReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchReaderTask.

        Retrieves data from a table, creates a dataframe then puts that dataframe on the task_context
        so its available downstream to any other tasks.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration, a YAML file containing information
                                such as the table name, schema, data format etc.
        """
        _conf = self.start_task(context, conf)

        # get final table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        context.logger.info(f"reading table: {table_name}")

        # read in dataframe
        df = context.spark.read.options(**_conf.reader_options).format(_conf._format).table(table_name)  # type: ignore

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)


class SimpleStreamingTableReaderTask(ETLTask):
    """Task for reading streaming data from a table.

    This class defines a task for reading streaming data from a table data source. It takes a configuration object
    with information about the data source, such as the table name and reader options.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleStreamingTableReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleStreamingReaderTableTask.

        Reads data from a stream and makes it available for other tasks as a task context.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task a YAML file containing information such as the table name, schema,
                data format etc.

        """
        _conf = self.start_task(context, conf)

        df: DataFrame

        # define table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        if _conf.schema:
            df = (
                context.spark.readStream.schema(_conf.schema)
                .options(**_conf.reader_options)
                .format(_conf._format)
                .table(table_name)  # type: ignore
            )
        else:
            df = context.spark.readStream.options(**_conf.reader_options).format(_conf._format).table(table_name)

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)


class SimpleTableReaderTask(ETLTask):
    """Task for reading streaming data from a table.

    This class defines a task for reading streaming data from a table data source. It takes a configuration object
    with information about the data source, such as the table name and reader options.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleTableReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleTableReaderTask.

        Reads data from a stream and makes it available for other tasks as a task context.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task a YAML file containing information such as the table name, schema,
                data format etc.

        """
        _conf = self.start_task(context, conf)

        df: DataFrame

        # define table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        if _conf.schema:
            df = (
                context.spark.read.schema(_conf.schema)
                .options(**_conf.reader_options)
                .format(_conf._format)
                .table(table_name)  # type: ignore
            )
        else:
            df = context.spark.read.options(**_conf.reader_options).format(_conf._format).table(table_name)

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)
