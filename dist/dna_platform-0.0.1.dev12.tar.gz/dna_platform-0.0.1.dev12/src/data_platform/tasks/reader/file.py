from pyspark.sql import DataFrame
from pyspark.sql import functions as f

from data_platform.etl.transform.transform import sanitize_column_name
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.config.dataclasses import SimpleReaderConfig


class SimpleBatchFileReaderTask(ETLTask):
    """Task for reading batch data from a file.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleBatchFileReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchFileReaderTask.

        Retrieves data from a file, creates a dataframe then puts that dataframe on the task_context so its available
        downstream to any other tasks.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task a YAML file containing information such as
                                the table name, schema, data format etc.

        """
        _conf = self.start_task(context, conf)

        secret = context.get_property(
            namespace=_conf.secret_namespace,
            key=_conf.secret_key,
            optional=True,  # type:ignore
        )
        reader_options = {**_conf.reader_options}
        if secret:
            reader_options[_conf.secret_options_name] = secret  # type:ignore

        context.logger.info(f"path: {_conf.path}")

        if _conf.schema:
            # read in dataframe with string schema provided
            df = (
                context.spark.read.schema(_conf.schema).options(**reader_options).format(_conf._format).load(_conf.path)
            )  # type: ignore
        else:
            # read in dataframe infering schema
            df = context.spark.read.options(**reader_options).format(_conf._format).load(_conf.path)  # type: ignore
        # add dataframe onto task context
        df = df.select([f.col(col).alias(sanitize_column_name(col)) for col in df.columns])
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)


class SimpleStreamingFileReaderTask(ETLTask):
    """Task for reading streaming data.

    This class defines a task for reading streaming data from a data source. It takes a configuration object
    with information about the data source, such as reader options.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleStreamingFileReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleStreamingFileReaderTask.

        Reads data from a stream and makes it available for other tasks as a task context.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task a YAML file containing information such as the table name, schema,
            data format etc.

        """
        _conf = self.start_task(context, conf)

        df: DataFrame

        if _conf.schema:
            df = (
                context.spark.readStream.schema(_conf.schema)
                .options(**_conf.reader_options)
                .format(_conf._format)
                .load(path=_conf.path)
            )
        else:
            df = context.spark.readStream.options(**_conf.reader_options).format(_conf._format).load(path=_conf.path)

        if _conf.include_metadata:
            df = df.withColumn("_source_filepath", f.input_file_name())

        context.logger.info(f"Streaming dataframe with schema: {df.schema}")

        # add dataframe to task context
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)
