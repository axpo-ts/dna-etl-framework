from data_platform.tasks.core import TaskContext


def get_watermark_filter(
    context: TaskContext, target_table: str, watermark_filter_col: str, watermark_days: int
) -> str | None:
    """Get watermark-based filter condition if configured.

    Args:
        context: Task context containing Spark session
        target_table: Name of target table to check for watermark
        watermark_filter_col: Column name to filter on
        watermark_days: Number of days to look back from max timestamp

    Returns:
        SQL filter condition or None
    """
    # Return None if any required parameter is missing
    if not all([watermark_days, target_table, watermark_filter_col]):
        return None

    # Check if target table exists and get watermark date
    if context.spark.catalog.tableExists(target_table):
        watermark_query = f"""
            SELECT COALESCE(
                DATE_ADD(MAX({watermark_filter_col}), -{watermark_days}),
                to_timestamp('1999-01-01 00:00:00')
            ) as cutoff_date
            FROM {target_table}
        """
    else:
        watermark_query = "SELECT to_timestamp('1999-01-01 00:00:00') as cutoff_date"

    cutoff_date = context.spark.sql(watermark_query).collect()[0]["cutoff_date"]
    return f"{watermark_filter_col} >= '{cutoff_date}'"


def get_filter_conditions(context: TaskContext, filter_options: dict[str, str] | None = None) -> list[str]:
    """Get filter conditions based on filter options.

    Args:
        context: Task context containing Spark session
        filter_options: Dictionary containing filter configuration (optional)

    Returns:
        List of filter conditions to apply
    """
    filter_conditions = []

    # Add custom filters if configured
    if filter_options:
        target_table = filter_options.get("target_table")
        source_filter_col = filter_options.get("filter_clause", "").strip()

        if target_table and source_filter_col:
            if context.spark.catalog.tableExists(target_table):
                filter_value = context.spark.sql(filter_options["table_exists"]).collect()[0][0]
                filter_conditions.append(f"{source_filter_col}'{filter_value}'")
            else:
                filter_value = context.spark.sql(filter_options["table_not_exists"]).collect()[0][0]
                filter_conditions.append(f"{source_filter_col}'{filter_value}'")

    return filter_conditions
