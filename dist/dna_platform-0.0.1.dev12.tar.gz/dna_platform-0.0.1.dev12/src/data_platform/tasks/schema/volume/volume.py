from pyspark.sql import DataFrame

from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.schema.volume.config.dataclasses import VolumeConfig


class CreateVolumeTask(ETLTask):
    """Task for creating a volume in the data lake.

    Args:
        ETLTask (class): Abstract base class for ETL (Extract, Transform, Load) tasks.
    """

    task_name: str = "CreateVolumeTask"
    dataclass = VolumeConfig

    def execute(self, context: TaskContext, conf: Configuration) -> DataFrame:
        """Create a volume in the data lake and initialize directory structure."""
        _conf = self.start_task(context, conf)

        full_volume_name = f"`{_conf.catalog_name}`.`{_conf.schema_name}`.`{_conf.volume_name}`"

        context.logger.info(f"Creating volume {full_volume_name}")

        # Create the volume
        if _conf.comment:
            # Keep single quotes and double quotes intact by using triple quotes in the SQL later
            escaped_comment = _conf.comment.replace("'", "\\'").replace('"', '\\"')
            query = f"""CREATE VOLUME IF NOT EXISTS {full_volume_name} COMMENT '{escaped_comment}'"""
        else:
            query = f"""CREATE VOLUME IF NOT EXISTS {full_volume_name}"""
        context.spark.sql(query)

        # Create directories if paths are specified
        if hasattr(_conf, "paths") and _conf.paths:
            context.logger.info(f"Found paths configuration: {_conf.paths}")
            volume_path = f"/Volumes/{_conf.catalog_name}/{_conf.schema_name}/{_conf.volume_name}"
            context.logger.info(f"Base volume path: {volume_path}")

            dbutils = get_dbutils(context.spark)
            # Split CSV string into individual paths
            paths = [p.strip() for p in _conf.paths.split(",")]
            context.logger.info(f"Parsed {len(paths)} paths to create")

            for path in paths:
                full_path = f"{volume_path}/{path}"
                context.logger.info(f"Creating directory: {full_path}")
                try:
                    dbutils.fs.mkdirs(full_path)  # type: ignore
                    context.logger.info(f"Successfully created directory: {full_path}")
                except Exception as e:
                    context.logger.error(f"Failed to create directory {full_path}: {e!s}")
                    raise
        else:
            context.logger.info("No paths configuration found - skipping directory creation")

        # Return the result of volume creation
        return context.spark.sql(f"DESCRIBE VOLUME {full_volume_name}")
