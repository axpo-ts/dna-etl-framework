from dataclasses import dataclass


@dataclass
class CreateViewConfig:
    """Configuration class for the Tables Tasks.

    Attributes:
        task_name (str): The name of the task.
    """

    task_name: str
    source_catalog_prefix: str
    source_catalog_name: str
    source_schema_name: str
    source_table_name: str
    target_catalog_name: str
    target_schema_name: str
    target_view_name: str
    license: str | None = None
    comment: str | None = None
