from dataclasses import dataclass


@dataclass
class SchemaConfig:
    """Configuration class for the Schema Tasks.

    Attributes:
        task_name (str): The name of the task.
        schema_name (str): The name of the schema.
        catalog_name (Optional[str]): The name of the catalog (optional).
    """

    task_name: str
    schema_name: str
    catalog_name: str | None = None


@dataclass
class CreateSchemaConfig(SchemaConfig):
    """Configuration class for the CreateSchemaTask.

    Attributes:
        task_name (str): The name of the task.
        schema_name (str): The name of the schema.
        catalog_name (Optional[str]): The name of the catalog (optional).
    """

    create_validation_table: str | bool | None = "False"

    def __post_init__(self) -> None:
        """Function that transforms the params further if needed."""
        self.create_validation_table = self.create_validation_table in [True, "True", "TRUE", "true", "T", "t", "1"]


@dataclass
class CreateSchemaCommentsConfig(SchemaConfig):
    """Configuration class for the CreateSchemaCommentTask.

    Attributes:
        task_name (str): The name of the task.
        schema_name (str): The name of the schema.
        catalog_name (Optional[str]): The name of the catalog (optional).
        comment (str): The comment to be added to the schema.
    """

    comment: str | None = "default comment"
    view_name: str | None = None
