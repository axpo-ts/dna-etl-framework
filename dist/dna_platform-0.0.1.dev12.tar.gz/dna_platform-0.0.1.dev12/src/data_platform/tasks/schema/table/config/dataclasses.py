from dataclasses import dataclass, field


@dataclass
class TableMetadataConfig:
    """Base configuration class for table metadata tasks.

    This class provides common configuration attributes for tasks that handle
    table metadata such as tags and comments.

    Attributes:
        task_name (str): The name of the task.
        table_name (str | None): The name of the table.
        schema_name (str | None): The name of the schema.
        catalog_name (str | None): The name of the catalog.
        view_name (str | None): The name of the view to use for metadata configuration.
    """

    task_name: str
    table_name: str | None = None
    schema_name: str | None = None
    catalog_name: str | None = None
    view_name: str | None = None
    pause_yaml_metadata: bool | None = True


@dataclass
class CreateTableConfig:
    """Configuration class for the Tables Tasks.

    Attributes:
        task_name (str): The name of the task.
        schema_name (str): The name of the schema.
        table_name (str): The name of the table.
        table_schema (str): The schema of the table.
        catalog_name (Optional[str]): The name of the catalog (optional).
        partition_cols (Optional[str]): Columns to Partition the table (optional).
        primary_keys (Optional[str]): Primary Keys to the table (optional).
        clustering_cols (Optional[str]): Clustering Columns to the table (optional).
        table_comment (Optional[str]): Comment for the table (optional).
        writer_options (Dict[str, str], optional): Additional writer options as a dictionary
                                                (default is an empty dictionary).
    """

    task_name: str
    schema_name: str
    table_name: str
    table_schema: str
    catalog_name: str | None = None
    partition_cols: str | None = None
    primary_keys: str | None = None
    table_comment: str | None = None
    clustering_cols: str | None = None
    writer_options: dict[str, str] = field(default_factory=dict)


@dataclass
class CreateTableFromDataFrameConfig:
    """Configuration class for the Create Table From DataFrame Task.

    Attributes:
        task_name (str): The name of the task.
        df_namespace (str): The namespace where the dataframe is saved.
        df_key (str): The key under which the dataframe is saved.
        catalog_name (str): The name of the catalog.
        table_name (str): The name of the table.
        writer_options (Dict[str, str], optional): Additional writer options as a dictionary
                                                (default is an empty dictionary).
    """

    task_name: str
    schema_name: str
    table_name: str
    df_namespace: str
    df_key: str
    catalog_name: str | None = None
    table_format: str = "delta"
    writer_options: dict[str, str] = field(default_factory=dict)


@dataclass
class CreateTableTagsConfig(TableMetadataConfig):
    """Configuration class for adding tags to columns in a specified table.

    Attributes:
        task_name (str): The name of the task.
        tags (dict[str, str]): Dictionary of tags to apply to the table.
        pause_yaml_tags (bool | None): Whether to pause applying tags from YAML configuration.
    """

    tags: dict[str, str] = field(default_factory=dict)


@dataclass
class CreateTableCommentConfig(TableMetadataConfig):
    """Configuration class for setting table comments.

    Attributes:
        task_name (str): The name of the task.
        comment (str | None): The comment to set on the table.
        pause_yaml_comments (bool | None): Whether to pause applying comments from YAML configuration.
    """

    comment: str | None = None
