from pyspark.sql import DataFrame
from pyspark.sql.functions import col

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.schema.table.column.config.dataclasses import (
    CreateColumnCommentsConfig,
    CreateColumnTagsConfig,
)
from data_platform.tasks.schema.utils import SchemaUtils


class CreateColumnCommentsTask(ETLTask):
    """Task for setting column comments based on a data dictionary DataFrame."""

    task_name: str = "CreateColumnCommentsTask"
    dataclass = CreateColumnCommentsConfig

    @staticmethod
    def _get_view_based_comments(context: TaskContext, view_name: str) -> DataFrame:
        """Get column comments from a view.

        Args:
            context (TaskContext): The task context.
            view_name (str): The name of the view containing comment data.

        Returns:
            DataFrame: DataFrame containing column comments.
        """
        sql_query = f"""SELECT
            dd.catalog_name,
            dd.schema_name,
            dd.table_name,
            dd.column_name,
            dd.column_comment,
            dd.`__END_AT`
        FROM
            {view_name} dd
        """
        context.logger.info(f"Using SQL query: {sql_query}")
        comments_df = context.spark.sql(sql_query)
        context.logger.info(f"Using view '{view_name}' for column comments. Rows: {comments_df.count()}")
        return comments_df

    @staticmethod
    def _get_dataframe_comments(context: TaskContext, df_namespace: str, df_key: str) -> DataFrame:
        """Get column comments from a DataFrame.

        Args:
            context (TaskContext): The task context.
            df_namespace (str): The namespace of the DataFrame.
            df_key (str): The key of the DataFrame.

        Returns:
            DataFrame: DataFrame containing column comments.
        """
        data_dictionary_df = context.get_property(namespace=df_namespace, key=df_key)
        context.logger.info(f"Using DataFrame '{df_key}' for column comments. Rows: {data_dictionary_df.count()}")
        return data_dictionary_df

    @staticmethod
    def _apply_column_comment(
        context: TaskContext,
        catalog_name: str,
        schema_name: str,
        table_name: str,
        column_name: str,
        comment: str,
    ) -> None:
        """Apply a comment to a specific column.

        Args:
            context (TaskContext): The task context.
            catalog_name (str): The catalog name.
            schema_name (str): The schema name.
            table_name (str): The table name.
            column_name (str): The column name.
            comment (str): The comment to apply.
        """
        if not comment:
            return

        if not SchemaUtils.column_exists(context, catalog_name, schema_name, table_name, column_name):
            context.logger.warning(f"Skipping as either table {table_name} or column {column_name} doesn't exist")
            return

        try:
            # Keep single quotes and double quotes intact by using triple quotes in the SQL later
            escaped_comment = comment.replace("'", "\\'").replace('"', '\\"')
            sql_query = f"""
                ALTER TABLE {catalog_name}.{schema_name}.{table_name}
                ALTER COLUMN {column_name} COMMENT '{escaped_comment}'
            """
            context.logger.info(sql_query)
            context.spark.sql(sql_query)
            context.logger.info(
                f"""Added comment: {escaped_comment}, to column {column_name}
                in table {catalog_name}.{schema_name}.{table_name}"""
            )
        except Exception as e:
            context.logger.error(
                f"""Failed to set comment for column '{column_name}' in table
                '{catalog_name}.{schema_name}.{table_name}': {e}"""
            )
            raise

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Set column comments based on input.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        try:
            # Get comments from either view or DataFrame
            if _conf.view_name:
                comments_df = self._get_view_based_comments(context, _conf.view_name)
            else:
                comments_df = self._get_dataframe_comments(context, _conf.df_namespace, _conf.df_key)

            # Filter active rows with non-null comments
            filtered_dict_df = (
                comments_df.filter((col("__END_AT").isNull()) & (col("column_comment").isNotNull()))
                .select("catalog_name", "schema_name", "table_name", "column_name", "column_comment")
                .drop_duplicates()
            )

            # Process each row to update column comments
            for row in filtered_dict_df.collect():
                self._apply_column_comment(
                    context,
                    row["catalog_name"],
                    row["schema_name"],
                    row["table_name"],
                    row["column_name"],
                    row["column_comment"],
                )

            context.logger.info("Column comments successfully set. Check logs for any failures.")
        except Exception as e:
            context.logger.error(f"Column comments did not set, error: {e}")
            raise


class CreateColumnTagsTask(ETLTask):
    """Task for setting column tags based on a data dictionary DataFrame.

    This task will set tags on specified columns in a table using information
    from a data dictionary DataFrame that includes column names and associated tags.
    """

    task_name: str = "CreateColumnTagsTask"
    dataclass = CreateColumnTagsConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Set column tags based on the data dictionary DataFrame."""
        # Retrieve configuration details
        _conf = self.start_task(context, conf)

        # Retrieve the data dictionary DataFrame with column tags
        data_dictionary_df: DataFrame = context.get_property(namespace=_conf.df_namespace, key=_conf.df_key)

        # Filter the data dictionary for the specified table in the configuration
        filtered_dict_df = data_dictionary_df.filter(col("proposed_tag_key").isNotNull()).drop_duplicates()

        # Set tags for each column based on the data dictionary
        for row in filtered_dict_df.collect():
            catalog_name = row["catalog_name"]
            schema_name = row["schema_name"]
            table_name = row["table_name"]
            column_name = row["column_name"]
            tag_key = row["proposed_tag_key"]
            tag_value = row["proposed_tag_value"]

            if not SchemaUtils.column_exists(context, catalog_name, schema_name, table_name, column_name):
                context.logger.warning(f"Skipping as either table {table_name} or column {column_name} doesn't exists")
                continue

            # Generate SQL to add the tag for each column
            set_tag_sql = f"""
                ALTER TABLE {catalog_name}.{schema_name}.{table_name}
                ALTER COLUMN {column_name} SET TAGS ('{tag_key}' = '{tag_value}')
            """
            context.logger.info(
                f"Setting tag '{tag_key}' for column '{column_name}': {tag_value} using script: \n \
                                {set_tag_sql}"
            )
            context.spark.sql(set_tag_sql)

        context.logger.info("Column tags successfully set.")
