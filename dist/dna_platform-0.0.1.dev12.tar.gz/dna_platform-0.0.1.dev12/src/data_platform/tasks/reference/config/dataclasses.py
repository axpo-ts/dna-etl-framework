from dataclasses import dataclass


@dataclass
class ApplyReferenceMappingConfig:  # noqa: D101
    task_name: str
    df_input_namespace: str
    df_input_key: str
    df_output_namespace: str
    df_output_key: str
    mapping_ref_groups: list[str]
    catalog_prefix: str
    schema_prefix: str
    rename_to_group: bool = False
