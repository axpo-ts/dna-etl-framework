import json
from dataclasses import dataclass, field
from typing import Optional

from data_platform.tasks.core import Configuration
from data_platform.tasks.reader.api.auth.config.dataclasses import OAuthConfig


@dataclass
class CoreTransformConfig(Configuration):
    """Configuration class for core transformation tasks, specifying the source and destination context details.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame.
        df_input_key (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    df_output_namespace: str
    df_output_key: str


@dataclass
class ApplySQLTaskConfig(CoreTransformConfig):
    """Configuration class for the ApplySQLTask.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame.
        df_input_key (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
        sql_file (str): The path to the SQL file containing the query.
        df_alias (str): The alias to use for the input DataFrame in the SQL query. Defaults to "df".
        sql_file_vars (dict[str,str]): Additional variables to be passed to the SQL file. Defaults to {}.
        dynamic_columns (str): Columns to be dynamically handled, passed as a comma-separated string.
    """

    sql_file: str
    df_alias: str = "df"
    sql_file_vars: dict[str, str] = field(default_factory=dict)
    dynamic_columns: str = ""

    def __post_init__(self) -> None:
        """Post initialization method to convert a JSON object to a dict."""
        if isinstance(self.sql_file_vars, str):
            self.sql_file_vars = json.loads(self.sql_file_vars)


@dataclass
class ApplyPysparkConfig(CoreTransformConfig):
    """Configuration class for the TransformerTask.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame.
        df_input_key (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
        transformations (str): The functions and parameters.
    """

    transformations: list[dict]


@dataclass
class JoinDataFrameConfig:
    """Configuration class for the TransformerTask.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace_left (str): The namespace of the input DataFrame.
        df_input_key_left (str): The key of the input DataFrame.
        df_input_namespace_right (str): The namespace of the input DataFrame.
        df_input_key_right (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
    """

    task_name: str
    df_input_namespace_left: str
    df_input_key_left: str
    df_input_namespace_right: str
    df_input_key_right: str
    df_output_namespace: str
    df_output_key: str
    join_on: list[str]
    join_how: str = "inner"


@dataclass
class UnionDataFrameConfig:
    """Configuration class for class implementing dataframe union operation.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace_first (str): The namespace of the first input DataFrame.
        df_input_key_first (str): The key of the first input DataFrame.
        df_input_namespace_second (str): The namespace of the second input DataFrame.
        df_input_key_secon (str): The key of the second input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
    """

    task_name: str
    df_input_namespace_first: str
    df_input_key_first: str
    df_input_namespace_second: str
    df_input_key_second: str
    df_output_namespace: str
    df_output_key: str
    allow_missing_columns: str | bool = False

    def __post_init__(self) -> None:
        """Apply post init logic."""
        self.allow_missing_columns = self.allow_missing_columns in [
            True,
            "True",
            "true",
            "TRUE",
            "T",
            "t",
            "Yes",
            "YES",
            "yes",
            "y",
            "Y",
        ]
        return None


@dataclass
class NetCdfToCsvTaskConfig(CoreTransformConfig):
    """Configuration class for the NetCdfToCsvTask.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame.
        df_input_key (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
        api_output_format (str): The format of the output DataFrame.
        columns_to_drop (str | list): Column to drop from data set.
    """

    api_output_format: str
    columns_to_drop: None | str | list = None


@dataclass
class MeteomaticsIterateApiConfig:
    """Configuration class for MeteomaticsIterateApiTask.

    Attributes:
        task_name (str): The name of the task.
        df_namespace (str): The namespace to use for storing the DataFrame in the task context.
        df_key (str): The key to use for storing the DataFrame in the task context.
        secret_namespace (str): Namespace used to store API secrets.
        access_token_key (str): Key used to store the API access token.
        api_name (str | None): Name used to call the API data endpoint.
        api_method (str | None): Method used to call the API data endpoint ('GET' or 'POST').
        api_url_params (dict | None): Parameters used to call the API data endpoint.
    """

    task_name: str
    df_namespace: str
    df_key: str
    secret_namespace: str
    access_token_key: str
    api_name: Optional[str] = None  # noqa: UP007
    api_method: Optional[str] = None  # noqa: UP007
    api_url_params: Optional[dict] = None  # noqa: UP007
    member_selection: str = ""


@dataclass
class DatabricksApiConfig(OAuthConfig, Configuration):
    """Dataclass representing the configuration for interacting with the Databricks API.

    Attributes:
        api_url (str): The base URL of the Databricks API.
        df_namespace (str): The namespace to use for storing the DataFrame in the task context.
        df_key (str): The key to use for storing the DataFrame in the task context.
        secret_namespace (str): Namespace used to store API secrets.
        access_token_key (str): Key used to store the API access token.
        api_time_window (dict): The time window for the API request.
    """

    task_name: str
    secret_namespace: str
    access_token_key: str
    host_url: str
    lpi_table: str
    user_attributes_table: str
    lpi_user_mapping_table: str
    target_schema: str
    admin_group: str
    account_id: str
    api_scim_urls: dict


@dataclass
class IncrementalTablesReaderTaskConfig:
    """Configuration class for the IncrementalTablesReaderTask.

    Attributes:
        task_name (str): The name of the task.
        source_tables (dict[str, str]): Mapping of source aliases to table names.
        target_table (str): The table used to compute the maximum watermark value.
        df_output_namespace (str): Namespace under which to store the output DataFrame in context.
        df_output_key (str): Key to identify the output DataFrame in context.
        watermark_column (str): Column name used for incremental filtering (e.g., 'updated_at').
        watermark_filter (str, optional): Optional SQL WHERE clause filter applied before computing max watermark
                                          (e.g., "region = 'EU' AND active = true").
        drop_duplicates (bool): Whether to remove duplicate rows after union. Defaults to True.
    """

    task_name: str
    source_tables: dict[str, str]
    target_table: str
    df_output_namespace: str = "default"
    df_output_key: str = "unioned_incremental_df"
    watermark_column: str = "updated_at"
    watermark_filter: Optional[str] = None  # noqa: UP007
    drop_duplicates: bool = False
