from collections.abc import ByteString
from io import BytesIO, StringIO

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.transform.config.dataclasses import NetCdfToCsvTaskConfig


class NetCdfToCsvTask(ETLTask):
    """A task that applies SQL queries on a DataFrame.

    This task takes a DataFrame as input, applies an SQL query to it, and stores the result in another DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplySQLTaskConfig]): The configuration dataclass.

    """

    task_name = "NetCdfToCsvTask"
    dataclass = NetCdfToCsvTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the NetCdfToCsvTask.

        Args:
            context (TaskContext): The context object for the task.
            conf (Configuration): The configuration object for the task.
        """
        _conf = self.start_task(context, conf)

        if _conf.api_output_format == "csv":
            context.logger.info("get csv object")
            csv_content: str = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
            output = csv_content
        elif _conf.api_output_format == "netcdf":
            import xarray as xr  # type: ignore

            context.logger.info("get NetCdf object")
            netcdf_content: ByteString = context.get_property(
                namespace=_conf.df_input_namespace, key=_conf.df_input_key
            )

            # Assuming response_netcdf.content contains the NetCDF data
            netcdf_data = BytesIO(netcdf_content)

            try:
                # Try NetCDF4/HDF5
                xr_ds = xr.open_dataset(netcdf_data, engine="h5netcdf")
            except ValueError as e:
                if "is not the signature of a valid netCDF4 file" in str(e):
                    # Fall back to NetCDF3
                    netcdf_data.seek(0)  # reset buffer
                    xr_ds = xr.open_dataset(netcdf_data, engine="scipy")
                else:
                    raise e

            # Convert the xarray Dataset to a Pandas DataFrame
            pd_df = xr_ds.to_dataframe().reset_index()
            # List of columns to drop if they exist
            columns_to_drop = (
                _conf.columns_to_drop if isinstance(_conf.columns_to_drop, list) else [_conf.columns_to_drop]
            )

            # Drop the columns if they exist in the DataFrame
            pd_df = pd_df.drop(columns=[col for col in columns_to_drop if col in pd_df.columns])

            # Convert DataFrame to CSV object
            csv_buffer = StringIO()
            pd_df.to_csv(csv_buffer, index=False)

            # Get CSV string
            output = csv_buffer.getvalue()

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=output)
