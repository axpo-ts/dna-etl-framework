from collections.abc import Callable
from importlib.abc import Traversable
from typing import Any, TextIO

from delta import DeltaTable

from data_platform.tasks.config.dataclasses import BaseCatalogConfig
from data_platform.tasks.core import TaskContext


class CatalogUtilities:
    """A class of helper methods used in all tasks."""

    @staticmethod
    def build_table_name_from_conf(conf: BaseCatalogConfig) -> str:
        """Return table name based on task configuration."""
        return CatalogUtilities.build_table_name(conf.catalog_name, conf.schema_name, conf.table_name)

    @staticmethod
    def build_table_name(catalog_name: str | None, schema_name: str | None, table_name: str | None) -> str:
        """Return table name based on task configuration."""
        if catalog_name:
            table_name = f"`{catalog_name}`.`{schema_name}`.`{table_name}`"
        else:
            table_name = f"`{schema_name}`.`{table_name}`"
        return table_name

    @staticmethod
    def get_target_deltatable(context: TaskContext, conf: BaseCatalogConfig) -> DeltaTable:
        """Return a DeltaTable instance for a givne context/conf."""
        table_name = CatalogUtilities.build_table_name_from_conf(conf)
        # write data to table
        context.logger.info(f"Upserting the dataframe to table: {table_name}")
        return DeltaTable.forName(context.spark, table_name)


def file_provider(path: str | Traversable, call: Callable[[TextIO], Any], mode: str = "r") -> Any:
    """Executes a function on a TextIO object with the given path.

    Args:
        path (Union[str, Traversable]): The path to the file.
        call (Callable[[TextIO], Any]): The function to be executed on the TextIO object.
        mode (str, optional): The mode to open the file with. Defaults to "r".

    Returns:
        Any: The result of the callable.

    Raises:
        FileNotFoundError: If the file specified by the path does not exist.
        PermissionError: If the file specified by the path cannot be opened due to insufficient permissions.
        ValueError: If an invalid mode is provided.

    Example:
        >>> def count_lines(file: TextIO) -> int:
        ...     return len(file.readlines())
        >>> file_provider("path/to/file.txt", count_lines)
        10

    Note:
        This function uses the `open` function to open the file with the specified mode.
        The file is automatically closed after the callable is executed.
    """
    with open(path, mode) as f:  # type: ignore
        return call(f)  # type: ignore
