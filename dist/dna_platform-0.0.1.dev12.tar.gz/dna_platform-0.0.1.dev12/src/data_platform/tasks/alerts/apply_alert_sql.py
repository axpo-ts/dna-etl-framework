import yaml
from pyspark.sql import DataFrame

from data_platform.tasks.alerts.config.dataclasses import ApplyAlertSQLTaskConfig
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.transform.apply_sql import ApplySQLTask


class ApplyAlertSQLTask(ETLTask):
    """A task that applies SQL queries and prepares data for Alerts.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplyAlertSQLTaskConfig]): The configuration dataclass.
    """

    task_name = "ApplyAlertSQLTask"
    dataclass = ApplyAlertSQLTaskConfig

    def get_alerts(self, input_conf: Configuration) -> list:
        """Retrieve alerts from the configuration.

        Parameters:
            input_conf: The input configuration object.

        Returns:
            list: A list of alert configurations.
        """
        alerts_config = yaml.safe_load(open(input_conf.alerts_config))
        return alerts_config.get("alerts", [])

    def get_sql_results(self, context: TaskContext, input_conf: Configuration, alert_config: dict) -> DataFrame:
        """Create checks from the rules configuration.

        Parameters:
            context (TaskContext): The context object for the task.
            input_conf: The input configuration object.
            alert_config (dict): The alert configuration dictionary.

        Returns:
            DataFrame: The resulting DataFrame after applying the SQL query.
        """
        df = context.spark.range(10)
        context.put_property("input_namespace", alert_config["table"], df)
        apply_sql_task = ApplySQLTask()
        apply_sql_task_config = {
            "task_name": "ApplySQLTask",
            "df_input_namespace": "input_namespace",
            "df_input_key": alert_config["table"],
            "df_output_namespace": f"""alert_{alert_config["table"]})""",
            "df_output_key": alert_config["table"],
            "df_alias": "source_table",
            "sql_file": f"""{input_conf.workspace_path_prefix}{alert_config["constraint"]}""",
            "sql_file_vars": {
                "env_catalog_name": input_conf.env_catalog_identifier,
                "env_schema_prefix": input_conf.schema_prefix,
            },
        }
        apply_sql_task.execute(context, Configuration(apply_sql_task_config))
        return context.get_property(namespace=f"""alert_{alert_config["table"]})""", key=alert_config["table"])

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the ApplyAlertSQLTask.

        Parameters:
            context (TaskContext): The context object for the task.
            conf (Configuration): The configuration object for the task.
        """
        input_conf = self.start_task(context, conf)

        # Get alerts
        alerts_config_list = self.get_alerts(input_conf)
        context.logger.info("Retrieved alerts configuration: %s", alerts_config_list)

        # Prepare data for the alerts
        alert_idx = 1
        alerts_data_list = []

        for alert_config in alerts_config_list:
            context.logger.info(f"Processing alert: {alert_config}")
            sql_query_output = self.get_sql_results(context, input_conf, alert_config)
            sample_data = self.dataframe_to_list_of_dicts(sql_query_output, alert_config.get("sample_records", 5))
            card_message = self.prepare_card_message(alert_config, sql_query_output, sample_data, alert_idx)
            alerts_data_list.append(card_message)
            alert_idx += 1

        context.logger.info(
            f"Card data for alert: {alerts_data_list}",
        )
        # Add alerts_data_list onto task context
        context.put_property(
            namespace=input_conf.df_output_namespace, key=input_conf.df_output_key, value=alerts_data_list
        )

    @staticmethod
    def dataframe_to_list_of_dicts(df: DataFrame, sample_rows: int) -> list:
        """Convert a DataFrame to a list of dictionaries.

        Parameters:
            df (DataFrame): The DataFrame to convert.
            sample_rows (int): The number of sample rows to convert.

        Returns:
            list: A list of dictionaries representing the DataFrame rows.
        """
        sample_df = df.limit(sample_rows)
        return [row.asDict() for row in sample_df.collect()]

    @staticmethod
    def prepare_card_message(
        alert_config: dict, sql_query_output: DataFrame, sample_data: list, alert_idx: int
    ) -> dict:
        """Prepare a message for the card.

        Parameters:
            alert_config (dict): The alert configuration dictionary.
            sql_query_output (DataFrame): The output DataFrame from the SQL query.
            sample_data (list): A list of sample data dictionaries.
            alert_idx (int): The index of the alert.

        Returns:
            dict: A dictionary representing the card message.
        """
        card_message_success = {
            "activityTitle": f"""Alert {alert_idx}: {alert_config["name"]}_{alert_config["table"]}""",
            "facts": [
                {"name": "Description", "value": alert_config["description"]},
                {"name": "Message", "value": "No alerts found in the data"},
            ],
            "markdown": True,
        }

        card_message_failure = {
            "activityTitle": f"""Alert {alert_idx}: {alert_config["name"]}_{alert_config["table"]}""",
            "facts": [
                {"name": "Description", "value": alert_config["description"]},
                {"name": "Alert Records Count:", "value": sql_query_output.count()},
                {"name": "Sample Alert Records", "value": str(sample_data)},
            ],
            "markdown": True,
        }

        return card_message_success if sql_query_output.count() == 0 else card_message_failure
