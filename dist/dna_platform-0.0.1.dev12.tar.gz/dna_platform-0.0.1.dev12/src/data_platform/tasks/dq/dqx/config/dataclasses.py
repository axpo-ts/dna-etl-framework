from dataclasses import dataclass

from data_platform.tasks.core import Configuration


@dataclass
class ApplyDqxRulesConfig(Configuration):
    """Configuration class for core transformation tasks, specifying the source and destination context details.

    Attributes:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame.
        df_input_key (str): The key of the input DataFrame.
        df_output_namespace (str): The namespace of the output DataFrame.
        df_output_key (str): The key of the output DataFrame.
        dq_rules_file_path (str): Location of DQ rules file.
        target_schema_name (str): name of the schema the rule is being applied to.
        target_table_name (str): name of the table the rule is being applied to.
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    df_output_namespace: str
    df_output_key: str
    target_schema_name: str
    target_table_name: str
    dq_rules_table: str
    dq_metrics_table: str
    dq_quarantine_table: str
    dq_rules_file_path: str | None = None


@dataclass
class DataQualityRulesConfig:
    """Dataclass representing the configuration for interacting with the Databricks API.

    Attributes:
        api_url (str): The base URL of the Databricks API.
        df_namespace (str): The namespace to use for storing the DataFrame in the task context.
        df_key (str): The key to use for storing the DataFrame in the task context.
        secret_namespace (str): Namespace used to store API secrets.
        access_token_key (str): Key used to store the API access token.
        api_time_window (dict): The time window for the API request.
    """

    task_name: str
    search_directory: str
    df_output_namespace: str
    df_output_key: str
    dq_rules_table: str
