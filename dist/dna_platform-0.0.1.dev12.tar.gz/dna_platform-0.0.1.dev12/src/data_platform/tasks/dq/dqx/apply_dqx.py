from pyspark.sql import DataFrame

from data_platform.etl.data_quality.apply_dqx_rules import ApplyDqxRulesTask as NewApplyDqxRulesTask
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.dq.dqx.config.dataclasses import ApplyDqxRulesConfig


class ApplyDqxRulesTask(ETLTask):
    """A task that applies transform funcs on a DataFrame.

    This task takes a DataFrame as input, applies an SQL query to it, and stores the result in another DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplyDqxRulesConfig]): The configuration dataclass.

    """

    task_name = "ApplyDqxRulesTask"
    dataclass = ApplyDqxRulesConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ApplyDqxRulesTask by dissecting the key pair values of the configuration.

        Then executing the SQL query.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        context.logger.info("get the input dataframe")
        input_df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)

        valid_df = NewApplyDqxRulesTask(
            context=context,
            source_df=input_df,
            target_schema_name=_conf.target_schema_name,
            target_table_name=_conf.target_table_name,
            dq_metrics_table=_conf.dq_metrics_table,
            dq_quarantine_table=_conf.dq_quarantine_table,
            dq_rules_file_path=_conf.dq_rules_file_path,
            dq_rules_table=_conf.dq_rules_table,
        ).execute()

        context.logger.info("DQ rules applied to dataframe")
        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=valid_df)

        context.logger.info("return dataframe")
