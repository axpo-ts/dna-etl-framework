# Constants
TIME_FORMAT = "%Y-%m-%dT%H:%M:%S"
TRUE_VALUES = ["true", "t", "yes"]
MAX_RESOURCE_IDS_PER_BLOCK = 10
