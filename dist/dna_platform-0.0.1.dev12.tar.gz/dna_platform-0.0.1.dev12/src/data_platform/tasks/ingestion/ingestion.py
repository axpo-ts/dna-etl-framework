import json
from collections import defaultdict
from datetime import date, datetime, timedelta
from math import ceil
from typing import Any

import pandas as pd

from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.ingestion.config.dataclasses import (
    GetTimeBlocksConfig,
    RewriteJsonFileFromIndexToRecordsConfig,
    SetDatabricksParameterConfig,
    SetDeltaLoadParametersConfig,
)
from data_platform.tasks.ingestion.constants import MAX_RESOURCE_IDS_PER_BLOCK, TRUE_VALUES


class GetTimeBlocksTask(ETLTask):
    """Task used to split a [start_timestamp, end_timestamp] into blocks of 'block_width_days' days each.

    Task used to create time filters to read data from an API. For each resulting element, it also outputs whether
    to overwrite or append the API data to the output table.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[GetTimeBlocksConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the GetTimeBlocksTask by creating a list of dictionaries, where
            each element contains the parameters of the requested time blocks.
    """

    task_name: str = "GetTimeBlocksTask"
    dataclass = GetTimeBlocksConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the GetTimeBlocksTask.

        Saves the time blocks parameters (e.g. block number, start and end time, ...)
        to a list saved to the task context.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        # get the parameters used to create the list of time blocks
        try:
            if len(_conf.inputs) >= 3:  # if parameters supplied via input dictionary
                _start_timestamp = context.get_property(
                    namespace=_conf.inputs["namespace"], key=_conf.inputs["start_timestamp"]
                )
                _end_timestamp = context.get_property(
                    namespace=_conf.inputs["namespace"], key=_conf.inputs["end_timestamp"]
                )
                _block_width_days = context.get_property(
                    namespace=_conf.inputs["namespace"], key=_conf.inputs["block_width_days"]
                )
                _write_mode = (
                    context.get_property(namespace=_conf.inputs["namespace"], key=_conf.inputs["write_mode"])
                    if "write_mode" in _conf.inputs.keys()
                    else _conf.write_mode
                )
            else:
                _start_timestamp = datetime.strptime(_conf.start_timestamp, _conf.time_format)
                _end_timestamp = datetime.strptime(_conf.end_timestamp, _conf.time_format)
                _block_width_days = int(_conf.block_width_days)
                _write_mode = _conf.write_mode
        except Exception as e:
            context.logger.error(
                f"Failed to read the parameters providing the start and end timestamp, block width and write mode: {e}"
            )
            raise ValueError("Failed to read the input parameters") from e

        # calculate the time blocks
        _num_blocks = ceil((_end_timestamp - _start_timestamp).total_seconds() / (_block_width_days * 60 * 60 * 24))
        context.logger.info(f"Generating {_num_blocks} time blocks.")

        _time_blocks = []
        for i in range(_num_blocks):
            _start_time = _start_timestamp + timedelta(days=i * _block_width_days)
            _end_time = _start_timestamp + timedelta(days=(i + 1) * _block_width_days)
            _end_time = min(_end_timestamp, _end_time)
            __write_mode = "overwrite" if (i == 0 and _write_mode == "overwrite") else "append"
            _time_blocks.append(
                {
                    "block_num": i,
                    "start_time": _start_time.strftime(_conf.time_format),
                    "end_time": _end_time.strftime(_conf.time_format),
                    "delta_days": (_end_time - _start_time).total_seconds() / (60 * 60 * 24),
                    "write_mode": __write_mode,
                }
            )
        context.logger.info(f"Generated the following time blocks:\n\t {_time_blocks}")

        # add the output to the context
        try:
            # Create the Spark DataFrame and place in task context
            context.put_property(namespace=_conf.outputs["namespace"], key=_conf.outputs["key"], value=_time_blocks)
            context.logger.info(
                f"Data saved to namespace '{_conf.outputs['namespace']}' with key '{_conf.outputs['key']}'"
            )
        except Exception as e:
            context.logger.error(
                "Failed to save the output. Please provide a 'namespace' and 'key' "
                "as part of the 'output' argument: {e}"
            )
            raise ValueError("Failed to save the results to the contex.") from e


class SetDatabricksParameterTask(ETLTask):
    """Task used to write a variable to a Databricks task parameter.

    Provide the input variable in task context (namespace and key) and the name of the
    Databricks task parameter where to save the variable to.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SetDatabricksParameterConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the SetDatabricksParameterTask by writing the input variable
            to the specified Databricks task parameter.
    """

    task_name: str = "SetDatabricksParameterTask"
    dataclass = SetDatabricksParameterConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SetDatabricksParameterTask.

        Writes the input variable (read from the task context) to the specified
        Databricks task parameter.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        # context.logger.info("running SimpleBatchWriterTask")
        context.logger.info(f"\n\n\t running task:   {self.task_name}")

        # map the config to the dataclass definition
        _conf = self.dataclass(**conf.as_dict())
        context.logger.info(_conf)

        # get the parameters used to create the list of time blocks
        context.logger.info(
            f"Reading the input variable from \
                            namespace = '{_conf.inputs['namespace']}' \
                            and key = '{_conf.inputs['key']}'"
        )
        try:
            _data = context.get_property(namespace=_conf.inputs["namespace"], key=_conf.inputs["key"])
        except Exception as e:
            context.logger.error(f"Failed to read the input variable from the task context: {e}")
            raise ValueError("Failed to read the input variable from the task context") from e

        # save the variable to a task parameter
        context.logger.info(f"Saving the data to the 'tasks.GetDAG.values.{_conf.parameter_name}' task parameter.")
        dbutils = get_dbutils(context.spark)
        dbutils.jobs.taskValues.set(key=_conf.parameter_name, value=_data)  # type: ignore


class SetDeltaLoadParametersBulkTask(ETLTask):
    """Task used to determine the load parameters for an API call.

    This task calculates the necessary parameters for loading data from an API,
    determining whether to perform a full load or a delta load, and generating
    corresponding time blocks for data processing.

    Attributes:
        task_name (str): The name of the task.
        dataclass: Configuration dataclass for load parameters.
    """

    task_name: str = "SetDeltaLoadParametersBulkTask"
    dataclass = SetDeltaLoadParametersConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SetDeltaLoadParametersBulkTask.

        This method orchestrates the entire process of reading input parameters,
        determining timestamps, calculating output parameters, and saving the results.

        Args:
            context (TaskContext): The context for logging and retrieving properties.
            conf (Configuration): The configuration object containing parameters for the task.

        Raises:
            ValueError: If there is an error reading input variables from the context or processing the task.
        """
        context.logger.info(f"\n\n\t running task: {self.task_name}")

        config = self.dataclass(**conf.as_dict())
        context.logger.info(config)

        try:
            self.process_load_parameters(context, config)
        except Exception as e:
            context.logger.error(f"Failed to read the input variable from the task context: {e}")
            raise ValueError("Failed to read the input variable from the task context") from e

    def process_load_parameters(self, context: TaskContext, config: SetDeltaLoadParametersConfig) -> None:
        """Process load parameters for the task.

        This method reads input parameters, determines timestamps for resource IDs,
        calculates time blocks, and saves the results.

        Args:
            context (TaskContext): The context for logging and retrieving properties.
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.
        """
        context.logger.info("Reading the input parameters")
        full_load = self.is_full_load(config)
        full_load_interval = float(config.inputs["full_load_window_days"])
        delta_load_interval = float(config.inputs["delta_load_window_days"])

        timestamps = self.determine_timestamps(context, config, delta_load_interval, full_load)
        time_blocks = self.calculate_time_blocks(
            timestamps, full_load_interval, delta_load_interval, config, context, full_load
        )

        context.logger.info(f"Generated the following time blocks:\n\t {time_blocks}")
        self.save_outputs(context, config, time_blocks)

    def is_full_load(self, config: SetDeltaLoadParametersConfig) -> bool:
        """Check if the load is a full load.

        Args:
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.

        Returns:
            bool: True if the load type is full load, False otherwise.
        """
        return config.inputs["full_load"].lower() in TRUE_VALUES

    def get_end_timestamp(self, config: SetDeltaLoadParametersConfig) -> datetime:
        """Return end timestamp using to_date if provided, else today's date.

        Args:
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.

        Returns:
            datetime: The end timestamp.
        """
        today = date.today()
        to_date_str = config.inputs.get("to_date", "")
        if to_date_str:
            # Try parsing with timestamp, else fallback to date-only
            if "T" in to_date_str:
                return datetime.strptime(to_date_str, "%Y-%m-%dT%H:%M:%S")
            else:
                return datetime.strptime(to_date_str, "%Y-%m-%d")
        return datetime(today.year, today.month, today.day)

    def extract_resource_id(self, file_name: str) -> str | None:
        """Extract the resource ID from the filename."""
        parts = file_name.split("_")
        return parts[0] if parts else None

    def extract_end_date(self, file_name: str) -> datetime | None:
        """Extract the end date from the filename if it follows the expected format."""
        parts = file_name.replace(".json", "").split("_")
        if len(parts) >= 4:
            return datetime.strptime(parts[3], "%Y%m%d")
        return None

    def determine_timestamps(
        self,
        context: TaskContext,
        config: SetDeltaLoadParametersConfig,
        delta_load_interval: float,
        full_load: bool,
    ) -> list[dict[str, Any]]:
        """Determine timestamps for ingestion.

        Unified logic for:
        - Manual override (from_date, to_date, resource_ids)
        - Full load
        - Incremental load
        """
        manual_resource_ids = config.inputs.get("resource_ids")
        manual_from_date = config.inputs.get("from_date")
        manual_to_date = config.inputs.get("to_date")
        full_load = self.is_full_load(config)
        delta_load_window_days = int(delta_load_interval)

        context.logger.info("Reading input parameters...")

        # --- CASE 1: Manual or Full Load ---
        if full_load or (manual_resource_ids and manual_from_date and manual_to_date):
            context.logger.info("Detected manual override or full load mode — resolving curves and date ranges.")

            # Load JSON config for curve-resource mapping
            try:
                volumes = self.load_volumes(config)
            except Exception as e:
                context.logger.error(f"Error loading config JSON: {e}")
                raise

            ids = [r.strip() for r in manual_resource_ids.split(",")] if manual_resource_ids else None
            start_time = datetime.strptime(manual_from_date, "%Y-%m-%d") if manual_from_date else None
            end_time = (
                datetime.strptime(manual_to_date, "%Y-%m-%d") if manual_to_date else self.get_end_timestamp(config)
            )

            time_blocks = []
            for curve, resource_list in volumes.items():
                for resource in resource_list:
                    rid = str(resource["resource_id"])

                    # If manual IDs are provided, filter by them
                    if ids and rid not in ids:
                        continue

                    # Get from_date (manual → config fallback)
                    if start_time:
                        from_date = start_time
                    else:
                        from_date_str = resource.get("from_date")
                        if from_date_str:
                            try:
                                from_date = datetime.strptime(from_date_str, config.inputs["time_format"])
                            except Exception:
                                from_date = datetime.fromisoformat(from_date_str)
                        else:
                            from_date = end_time - timedelta(days=delta_load_window_days)

                    time_blocks.append(
                        {
                            "resource_id": rid,
                            "curve": curve,
                            "start_time": from_date,
                            "end_time": end_time,
                            "full_load": True,
                        }
                    )

            context.logger.info(
                f"Generated {len(time_blocks)} {'manual' if manual_resource_ids else 'full'} load time blocks."
            )
            return time_blocks

        # --- CASE 2: Incremental Load ---
        context.logger.info("Incremental load selected — deriving from bronze table.")
        return self.get_incremental_from_dates(context, config, delta_load_window_days)

    def get_min_reference_times(self, context: TaskContext, schema: str, input_data: dict) -> tuple[dict, dict]:
        """Query the database to get identifiers and their minimum ReferenceTime.

        Returns:
            dict: dictionary containing identifier and min(ReferenceTime).
        """
        # Step : Build identifer_reference_maps from JSON
        identifier_reference_maps = {
            key: {
                item["resource_id"]: item["from_date"]
                for item in items
                if isinstance(items, list) and "resource_id" in item and "from_date" in item
            }
            for key, items in input_data.items()
            if isinstance(items, list)
        }

        # Step : Build all_identifier_min_reference_maps from existing table
        all_identifier_min_reference_maps = {}

        for table_key in input_data:
            full_table_name = f"{schema}.{table_key}"
            if context.spark.catalog.tableExists(full_table_name):
                try:
                    query = f"""
                        SELECT Identifier, MIN(ReferenceTime) as ReferenceTime
                        FROM {full_table_name}
                        GROUP BY Identifier
                    """
                    df = context.spark.sql(query)

                    min_ref_dict = {row["Identifier"]: row["ReferenceTime"].isoformat() for row in df.collect()}

                    all_identifier_min_reference_maps[table_key] = min_ref_dict

                except Exception as e:
                    print(f" Error processing table '{full_table_name}': {e}")
            else:
                print(f" Table does not exist: {full_table_name} — Skipping.")
        return all_identifier_min_reference_maps, identifier_reference_maps

    def get_incremental_from_dates(
        self,
        context: TaskContext,
        config: SetDeltaLoadParametersConfig,
        window_days: int,
    ) -> list[dict[str, Any]]:
        """Generic incremental loader (for both streaming & non-streaming endpoints).

        Determines from_date dynamically from the bronze table:
        - Uses MAX(ReferenceTime) per Identifier if available.
        - Falls back to config JSON from_date only for PROD.
        - In non-prod, falls back to (today - window_days).
        - to_date = get_end_timestamp(config)
        """
        schema = config.inputs["schema"]
        catalog = schema.split(".")[0].lower() if schema else ""
        is_prod = "prod" in catalog

        end_time = self.get_end_timestamp(config)
        date_today = date.today()
        today = datetime(date_today.year, date_today.month, date_today.day)
        time_blocks = []
        volumes = self.load_volumes(config)

        for curve, resource_list in volumes.items():
            table_name = f"{schema}.{curve}"
            ref_map = {}

            # Step 1: Fetch latest ReferenceTime per Identifier
            try:
                if context.spark.catalog.tableExists(table_name):
                    query = f"""
                        SELECT Identifier, MAX(ReferenceTime) AS ReferenceTime
                        FROM {table_name}
                        GROUP BY Identifier
                    """
                    df = context.spark.sql(query)
                    ref_map = {str(row["Identifier"]): row["ReferenceTime"] for row in df.collect()}
                    context.logger.info(f"Fetched max ReferenceTime for {len(ref_map)} identifiers from {table_name}")
                else:
                    context.logger.info(f"Bronze table {table_name} not found — using fallback.")
            except Exception as e:
                context.logger.error(f"Error querying {table_name}: {e}")

            # Step 2: Determine from_date per resource
            for resource in resource_list:
                rid = str(resource["resource_id"])
                from_date_cfg = None

                # Parse from_date from JSON if available
                from_date_str = resource.get("from_date")
                if from_date_str:
                    try:
                        from_date_cfg = datetime.strptime(from_date_str, config.inputs["time_format"])
                    except Exception:
                        from_date_cfg = datetime.fromisoformat(from_date_str)

                if rid in ref_map and ref_map[rid] is not None:
                    # Reference exists in bronze table -> Delta load style
                    ref_time = ref_map[rid]
                    if isinstance(ref_time, str):
                        try:
                            ref_time = datetime.fromisoformat(ref_time)
                        except ValueError:
                            ref_time = datetime.strptime(ref_time, config.inputs["time_format"])
                    ref_time = ref_time.replace(tzinfo=None)
                    from_date = ref_time - timedelta(days=window_days)
                    first_load = False
                else:
                    # New identifier logic:
                    # - PROD → use config JSON's from_date
                    # - NON-PROD → use (today - window_days)
                    if is_prod and from_date_cfg:
                        from_date = from_date_cfg
                        context.logger.info(f"[PROD] Using config JSON from_date for new resource_id={rid}")
                    else:
                        from_date = today - timedelta(days=window_days)
                        context.logger.info(
                            f"[NON-PROD] Using (today - {window_days} delta days) for new resource_id={rid}"
                        )
                    first_load = True

                time_blocks.append(
                    {
                        "resource_id": rid,
                        "curve": curve,
                        "start_time": from_date,
                        "end_time": end_time,
                        "full_load": False,
                        "first_load": first_load,
                    }
                )

        return time_blocks

    def load_volumes(self, config: SetDeltaLoadParametersConfig) -> dict[str, Any]:
        """Load volume configurations from a JSON file.

        Args:
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.

        Returns:
            dict[str, Any]: A dicitonary of curves and mdos configurations loaded from the JSON file.
        """
        with open(config.inputs["config_path"]) as f:
            return json.loads(f.read())

    def calculate_time_blocks(
        self,
        timestamps: list[dict[str, Any]],
        full_load_interval: float,
        delta_load_interval: float,
        config: SetDeltaLoadParametersConfig,
        context: TaskContext,
        full_load: bool,
    ) -> list[dict[str, Any]]:
        """Calculate time blocks for API requests.

        For streaming endpoints:
        - Resource IDs are grouped by (curve, start_time, end_time).
        - Large groups are split into smaller chunks based on MAX_RESOURCE_IDS_PER_BLOCK each.
        - Each (chunk X time window) combination becomes one API call block.

        Example:
            If curve "axpo_pfc" has 100 IDs from 2025-01-01 to 2025-01-10 and
            full_load_interval = 2 days → creates 5 time windows X 10-ID chunks = 10 API blocks total.

        For non-streaming endpoints:
        - Each resource_id gets its own time window blocks.
        """
        if not timestamps:
            context.logger.info("No timestamps available for block calculation. Returning empty time_blocks list.")
            return []

        api_url = config.inputs.get("api_url", "").lower()
        time_blocks = []
        block_counter = 0

        if "streaming" in api_url:
            grouped = defaultdict(list)

            # Group by (curve, start_time, end_time)
            for ts in timestamps:
                key = (ts["curve"], ts["start_time"], ts["end_time"])
                grouped[key].append(ts["resource_id"])

            context.logger.info(f"Streaming load: Grouped into {len(grouped)} curve+time windows.")

            for (curve, start_timestamp, end_timestamp), resource_ids in grouped.items():
                block_width_days = full_load_interval if full_load else delta_load_interval
                num_blocks = ceil((end_timestamp - start_timestamp).total_seconds() / (block_width_days * 86400))

                # Adjust chunk size based on size of resource_ids
                chunk_size = MAX_RESOURCE_IDS_PER_BLOCK

                # Split resource_ids into chunks based on max_resource_ids_per_block
                for chunk_start in range(0, len(resource_ids), chunk_size):
                    chunk_ids = resource_ids[chunk_start : chunk_start + chunk_size]

                    for i in range(num_blocks):
                        block_start_time = start_timestamp + timedelta(days=i * block_width_days)
                        block_end_time = min(
                            end_timestamp, start_timestamp + timedelta(days=(i + 1) * block_width_days)
                        )

                        time_blocks.append(
                            self.create_time_block(
                                chunk_ids, curve, block_counter, block_start_time, block_end_time, full_load, config
                            )
                        )
                        block_counter += 1
        else:
            context.logger.info("Default block generation: one per resource_id")
            for ts in timestamps:
                resource_id = ts["resource_id"]
                curve = ts["curve"]
                start_timestamp = ts["start_time"]
                full_load_flag = ts["full_load"]
                end_timestamp = ts["end_time"]
                window_days = (end_timestamp - start_timestamp).days
                if window_days > delta_load_interval:
                    block_width_days = full_load_interval
                else:
                    block_width_days = delta_load_interval
                num_blocks = ceil((end_timestamp - start_timestamp).total_seconds() / (block_width_days * 86400))

                for i in range(num_blocks):
                    block_start_time = start_timestamp + timedelta(days=i * block_width_days)
                    block_end_time = min(end_timestamp, start_timestamp + timedelta(days=(i + 1) * block_width_days))

                    time_blocks.append(
                        self.create_time_block(
                            resource_id, curve, block_counter, block_start_time, block_end_time, full_load_flag, config
                        )
                    )
                    block_counter += 1

        return time_blocks

    def create_time_block(
        self,
        resource_id: str | list[str],
        curve: str,
        block_num: int,
        start_time: datetime,
        end_time: datetime,
        full_load: bool,
        config: SetDeltaLoadParametersConfig,
    ) -> dict[str, Any]:
        """Create a time block entry for a resource ID or a list of resource IDs.

        Args:
            resource_id (str | list[str]): The resource ID or a list of resource IDs.
            curve (str): The curve name.
            block_num (int): The block number.
            start_time (datetime): The start time for the block.
            end_time (datetime): The end time for the block.
            full_load (bool): Indicates if a full load is required.
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.

        Returns:
            dict[str, Any]: A dictionary containing the time block entry for the resource ID(s).
        """
        return {
            "resource_id": resource_id,
            "curve": curve,
            "block_num": block_num,
            "start_time": start_time.strftime(config.inputs["time_format"]),
            "end_time": end_time.strftime(config.inputs["time_format"]),
            "delta_days": (end_time - start_time).total_seconds() / (60 * 60 * 24),
            "write_mode": "append" if not full_load else "overwrite",
        }

    def save_outputs(
        self, context: TaskContext, config: SetDeltaLoadParametersConfig, time_blocks: list[dict[str, Any]]
    ) -> None:
        """Save the output parameters to the task context.

        Args:
            context (TaskContext): The context for logging and retrieving properties.
            config (SetDeltaLoadParametersConfig): Configuration object containing load parameters.
            time_blocks (list[dict[str, Any]]): The calculated time blocks to be saved.

        Raises:
            ValueError: If there is an error saving the output parameters.
        """
        try:
            context.logger.info(f"Saving the output to namespace '{config.outputs['namespace']}'")
            context.put_property(namespace=config.outputs["namespace"], key=config.outputs["key"], value=time_blocks)
            context.logger.info(f"Saved to namespace '{config.outputs['namespace']}', key '{config.outputs['key']}'")
        except Exception as e:
            context.logger.error(f"Failed to save the output: {e}")
            raise ValueError("Failed to save the results to the context.") from e


class RewriteJsonFileFromIndexToRecordsTask(ETLTask):
    """Task used to rewrite a json file of type 'index' to a 'records' type json file.

    See the 'orient' parameter in
    https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_json.html
    The code finds all unprocessed files in a given volume and it rewrites them (i.e. processes them)
    into a new 'records' json type file written in the same volume with a different file name.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[RewriteJsonFileFromIndexToRecordsConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Finds all unprocessed json file and rewrites them to a 'records' type json file.
    """

    task_name: str = "RewriteJsonFileFromIndexToRecordsTask"
    dataclass = RewriteJsonFileFromIndexToRecordsConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the RewriteJsonFileFromIndexToRecordsTask.

        Finds all unprocessed json file and rewrites them to a 'records' type json file.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        # context.logger.info("running SimpleBatchWriterTask")
        context.logger.info(f"\n\n\t running task:   {self.task_name}")

        # map the config to the dataclass definition
        _conf = self.dataclass(**conf.as_dict())
        context.logger.info(_conf)

        # define the input & output directories
        input_dir = f"{_conf.volume}/{_conf.input_dir}/"
        output_dir = f"{_conf.volume}/{_conf.output_dir}/"

        # find all the new unprocessed files in the volume
        dbutils = get_dbutils(context.spark)
        dbutils.fs.mkdirs(input_dir)  # type: ignore
        input_files = dbutils.fs.ls(input_dir)  # type: ignore
        dbutils.fs.mkdirs(output_dir)  # type: ignore
        output_files = dbutils.fs.ls(output_dir)  # type: ignore
        unprocessed_files = [x.name for x in input_files if x.name not in [y.name for y in output_files]]
        context.logger.info(f"Found the following new (unprocessed) files:   {unprocessed_files}")

        # rewrite the files
        for org_file in unprocessed_files:
            context.logger.info(f"Rewriting file '{org_file}' ...")
            pandas_df = pd.read_json(f"{input_dir}/{org_file}", orient="index")
            pandas_df[_conf.index_column_name] = pandas_df.index
            pandas_df.to_json(f"{output_dir}/{org_file}", orient="records")
