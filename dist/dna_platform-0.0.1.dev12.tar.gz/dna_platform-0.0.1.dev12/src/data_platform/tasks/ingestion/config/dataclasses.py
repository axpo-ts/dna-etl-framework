from dataclasses import dataclass, field

from data_platform.tasks.ingestion.constants import TIME_FORMAT


@dataclass
class GetTimeBlocksConfig:
    """Configuration class for GetTimeBlocksTask.

    This class is used to split a [start_timestamp, end_timestamp] into blocks of 'block_width_days' days each
    (except last block). The configuration is declared in a YAML file and is unique to each task.

    Attributes:
        task_name (str): The name of the task.
        outputs dict[str, str]: Dictionary for providing the following output parameters:
            namespace (str): namespace where to save the output
            key (str): key under which to save the output
        inputs dict[str, str]: Dictionary for providing the input parameters:
            namespace (str): namespace under which the input parameters are saved
            start_timestamp (str): key for the start timestamp
            end_timestamp (str): key for the end timestamp
            block_width_days (str): key for the block width
            write_mode (str): key for the output table write mode
        start_timestamp (str): provide the start timestamp as a string (alternative to 'input' field).
        end_timestamp (str): provide the end timestamp as a string (alternative to 'input' field).
        block_width_days (str): provide the block width as a string (alternative to 'input' field).
        write_mode (str): used to determine if a task will append or overrwrite a table. Select
                        between "append" and "overwrite". If the latter, the first time block
                        will be marked as "overwrite" and subsequent ones as "append".
    """

    task_name: str
    outputs: dict[str, str]
    inputs: dict[str, str] = field(default_factory=dict)
    start_timestamp: str = ""
    end_timestamp: str = ""
    block_width_days: str = ""
    write_mode: str = "append"
    time_format: str = TIME_FORMAT


@dataclass
class SetDatabricksParameterConfig:
    """Configuration class for SetDatabricksParameterTask.

    This class is used to create a Databricks job parameters used for 'for each' task loops.

    Attributes:
        task_name (str): The name of the task.
        inputs dict[str, str]: Dictionary used to provide the input variables:
            'namespace' : the task context namespace of the input variable
            'key' : the task context key needed to read the input variable
        parameter_name (str): the name of the task parameter where to save the variable.
    """

    task_name: str
    inputs: dict[str, str] = field(default_factory=dict)
    parameter_name: str = ""


@dataclass
class SetDeltaLoadParametersConfig:
    """Configuration class for SetDeltaLoadParametersBulkTask.

    This class is used to create the full or delta load parameters for API data ingestion.

    Attributes:
        task_name (str): The name of the task.
        inputs dict[str, str]: Dictionary used to provide the input variables:
            namespace (str): the namespace storing the Dataframe of the ingestion table
            key (str): the key storing the Dataframe of the ingestion table
            window_end_time_column (str): the column name storing the last timestamp for which
                API data has been ingested.
            volume (str): the full path to the volume storing the API response as json files.
                If volume is empty, this variable is used to set 'full_load = True'.
            file_name_contains (str): Search only for file names containing this string.
            full_load (str): 'True' if full load, delta load otherwise
            full_load_start_time (str): start timestamp for a full load
            full_load_window_days (str): window length in days used to perform a full load
            end_time (str): the end timestamp for a full or delta load
            delta_load_window_days (str): number of past days to load data for a delta load
            time_format (str): format for the start & end timestamps
        outputs dict[str, str]: Dictionary for output variables:
            namespace (str): namespace where to save the output variables
            start_time (str): key for saving the start timestamp
            end_time (str): key for saving the end timestamp
            block_width_days (str): key for saving the block width
            write_mode (str): key for saving the write mode to file
            key (str): key for timeblocks to be saved
    """

    task_name: str
    inputs: dict[str, str] = field(default_factory=dict)
    outputs: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Add dictionary default values if missing."""
        self.inputs = {**{"end_time": "", "time_format": TIME_FORMAT, "volume": ""}, **self.inputs}
        return None


@dataclass
class RewriteJsonFileFromIndexToRecordsConfig:
    """Configuration class for RewriteJsonFileFromIndexToRecords.

    This class rewrites a json file of type 'index' to a 'records' type json file. See the 'orient' parameter
    in https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.read_json.html
    The code finds all unprocessed files in a given volume and it rewrites them (i.e. processes them)
    into a new 'records' json type file written in the same volume with a different file name.

    Attributes:
        task_name (str): The name of the task.
        volume (str): The volume where to look for json files
        input_dir (str): The name of the folder where the input files are found
        output_dir (str): The name of the folder where the output (processed) files will be placed
        index_column_name (str): The column name under which the index values will be saved as
    """

    task_name: str
    volume: str
    input_dir: str
    output_dir: str
    index_column_name: str
