from pyspark.sql import DataFrame
from pyspark.sql.functions import col, expr, lit, regexp_extract, when


# Parse UTC offset and apply it to from_datetime
def apply_utc_offset(df: DataFrame, datetime_col: str, offset_col: str, output_col: str) -> DataFrame:
    """Apply UTC offset to a datetime column and create a new adjusted datetime column.

    Args:
        df: Input DataFrame.
        datetime_col: Name of the datetime column to adjust.
        offset_col: Name of the column containing UTC offset information.
        output_col: Name of the output column with adjusted datetime.

    Returns:
        DataFrame with the adjusted datetime column.
    """
    return (
        df.withColumn("sign", when(col(offset_col).rlike(r"UTC\+"), -1).otherwise(1))
        .withColumn("offset_hours", regexp_extract(col(offset_col), r"UTC[+-](\d{2})", 1).cast("int"))
        .withColumn("offset_mins", regexp_extract(col(offset_col), r"UTC[+-]\d{2}(\d{2})", 1).cast("int"))
        .withColumn("total_offset_minutes", col("sign") * (col("offset_hours") * 60 + col("offset_mins")))
        .withColumn(output_col, expr(f"{datetime_col} + make_interval(0, 0, 0, 0, 0, total_offset_minutes, 0)"))
        .drop("sign", "offset_hours", "offset_mins", "total_offset_minutes")
    )


def add_meteologica_standard_columns(df: DataFrame) -> DataFrame:
    """Get standard meteologica metadata columns.

    Args:
        df: Input DataFrame to transform.

    Returns:
        DataFrame with added standard metadata columns.
    """
    df = df.withColumn("license", lit("METEOLOG_WINDPWRCAST_METEOLOG"))
    df = df.withColumn("data_source", lit("meteologica"))
    df = df.withColumn("data_system", lit("meteologica"))

    return df
