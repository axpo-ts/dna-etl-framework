import io
import os
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Any

import pandas as pd
import requests
import xarray as xr
from databricks.sdk.runtime import dbutils

from data_platform.data_model import FileVolumeIdentifier
from data_platform.etl.etl_task import ETLTask


class MeteomaticsTokenManager:
    """Token manager for Meteomatics API authentication.

    Handles token requests and authentication with the Meteomatics API service.
    """

    def request_new_token(self, key_vault_scope: str) -> str:
        """Request a new token from Meteomatics API.

        Retrieves authentication credentials from Databricks secret scope and
        requests an OAuth2 access token from Microsoft Azure login endpoint.

        Returns:
            Access token string for API authentication.

        Raises:
            requests.RequestException: If token request fails.
        """
        client_id = dbutils.secrets.get(key_vault_scope, "meteomatics-client-id")
        client_secret = dbutils.secrets.get(key_vault_scope, "meteomatics-client-secret")
        tenant_id = dbutils.secrets.get(key_vault_scope, "meteomatics-tenant-id")
        api_scope = dbutils.secrets.get(key_vault_scope, "meteomatics-api-scope")

        auth_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

        data = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": api_scope,
        }
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        try:
            response = requests.post(auth_url, data=data, headers=headers)
            response.raise_for_status()
            access_token = response.json().get("access_token")
            return access_token
        except requests.RequestException:
            raise


@dataclass(kw_only=True)
class MeteomaticsApiClient(ETLTask):
    """Base Client for Meteomatics API endpoints.

    Provides methods for interacting with the Meteomatics weather API,
    including data retrieval, processing, and storage.

    Args:
        token: OAuth2 access token for API authentication.
    """

    token: str | None = None

    def __post_init__(self) -> None:
        """Initialize the Meteomatics API client.

        Sets up base URL and authorization headers for API requests.

        Raises:
            ValueError: If token is not provided.
        """
        self.meteologica_base_url = "https://fs_gateway.prod.axponet.ch/dsl"
        self.headers = {"Authorization": f"Bearer {self.token}", "Content-Type": "application/json"}

        if not self.token:
            raise ValueError("Token is required for MeteologicaApiClient initialization.")

    def _days_diff(self, input_str: str, days: int = -3) -> str:
        """Calculate a date offset from the input timestamp.

        Args:
            input_str: ISO format timestamp string (YYYY-MM-DDTHH:MM:SSZ).
            days: Number of days to offset (negative for past dates). Defaults to -3.

        Returns:
            ISO format timestamp string with applied offset.
        """
        input_time = datetime.strptime(input_str, "%Y-%m-%dT%H:%M:%SZ")
        result_time = input_time + timedelta(days=days)

        return result_time.strftime("%Y-%m-%dT%H:%M:%SZ")

    def execute(self) -> None:
        """Execute the meteomatics client task.

        This method is currently a placeholder and needs implementation.
        """
        pass

    def get_latest_time_ranges(
        self, parameters: list[str], model: str, timeout: str, timedelta: int
    ) -> list[dict[str, str]]:
        """Fetch latest available time ranges for specified parameters.

        Queries the Meteomatics API to get the most recent data availability
        for given parameters and applies a day offset for processing.

        Args:
            parameters: List of parameter names to query.
            model: Weather model identifier.
            timeout: Request timeout value.
            timedelta: Number of days to offset from max available date.

        Returns:
            List of dictionaries containing parameter, min_date, and max_date.
        """
        url = (
            f"https://fs_gateway.prod.axponet.ch/dsl/v1/meteo/get_time_range?"
            f"model={model}&parameters={','.join(parameters)}&timeout={timeout}"
        )
        response = requests.get(url, headers=self.headers, verify=False)
        time_ranges = pd.read_csv(io.BytesIO(response.content), sep=";")
        time_ranges_dict = time_ranges.to_dict("list")
        ranges_to_iterate = [
            {"parameter": parameter, "min_date": self._days_diff(max_date, timedelta), "max_date": max_date}
            for parameter, max_date in zip(time_ranges_dict["parameter"], time_ranges_dict["max_date"])
        ]
        return ranges_to_iterate

    def get_init_dates_for_intraday(
        self, parameters: list[str], now_formatted: str, model: str = "mm-euro1k"
    ) -> pd.DataFrame:
        """Fetch initialization dates for intraday weather forecasts.

        Retrieves available model run initialization dates for specified parameters
        and filters results to include only valid entries and lookahead window.

        Args:
            parameters: List of parameter names to query.
            now_formatted: Current time in ISO format (YYYY-MM-DDTHH:MM:SSZ).
            model: Weather model identifier. Defaults to "mm-euro1k".

        Returns:
            DataFrame containing filtered initialization dates for parameters.
        """
        url = (
            f"https://fs_gateway.prod.axponet.ch/dsl/v1/meteo/get_init_date?"
            f"model={model}&valid_date={now_formatted}P3D:PT15M&parameters={','.join(parameters)}"
        )
        response_dev = requests.get(url, headers=self.headers, verify=False)
        init_dates = pd.read_csv(io.BytesIO(response_dev.content), sep=";")

        # Filter out rows with invalid timestamp entries
        init_dates_filtered = init_dates[(init_dates != "0000-00-00T00:00:00Z").all(axis=1)]
        self.context.logger.info(f"All available models {init_dates_filtered.to_dict(orient='records')}")

        format_style = "%Y-%m-%dT%H:%M:%SZ"
        lookahead_time = datetime.strptime(now_formatted, format_style) + timedelta(hours=4)
        lookahead_time_formatted = lookahead_time.strftime("%Y-%m-%dT%H:%M:%SZ")
        init_dates_filtered = init_dates[init_dates["validdate"] == lookahead_time_formatted]

        self.context.logger.info(f"Latest available models 4 hours ahead: {init_dates_filtered.to_dict()}")

        return init_dates_filtered

    def _generate_latest_model_run_by_curve(
        self, init_dates: pd.DataFrame, parameter_combinations: list[dict[str, Any]]
    ) -> dict[str, str]:
        """Map latest model run timestamps to curve names.

        Extracts the latest model run information from initialization dates
        and matches it to corresponding curve names based on parameter combinations.

        Args:
            init_dates: DataFrame with initialization dates.
            parameter_combinations: List of parameter combination dictionaries.

        Returns:
            Dictionary mapping curve names to latest model run timestamps.
        """
        # Get latest model run for each parameter from first row
        latest_model_runs = (init_dates.drop("validdate", axis=1).iloc[0]).to_dict()

        # Generate curve names by combining parameter, model, and duration
        curve_names = [
            f"{parameter_combination['parameter']}_{parameter_combination['model']}"
            f"_{parameter_combination['duration']}".lower()
            .replace("-", "_")
            .replace(":", "_")
            for parameter_combination in parameter_combinations
        ]

        # Match latest model runs to curve names
        latest_model_run_by_curve = {}
        for curve_name in curve_names:
            for key, model_run_timestamp in latest_model_runs.items():
                param_beginning = key.split(":")[0].replace("initdate_", "")
                parts = curve_name.rsplit("_")
                curve_beginning = "_".join(parts[:-4])
                if param_beginning == curve_beginning:
                    latest_model_run_by_curve[curve_name] = model_run_timestamp

        return latest_model_run_by_curve

    def filter_curves_to_download(
        self, init_dates: pd.DataFrame, parameter_combinations: list[dict[str, Any]]
    ) -> dict[str, str]:
        """Filter curves that have newer model runs available.

        Checks the intraday_helper table to determine which curves have
        fresher model runs available for download.

        Args:
            init_dates: DataFrame with initialization dates.
            parameter_combinations: List of parameter combination dictionaries.

        Returns:
            Dictionary mapping curve names to latest model run timestamps for download.
        """
        latest_model_run_by_curve = self._generate_latest_model_run_by_curve(init_dates, parameter_combinations)

        curves_to_pass_on = {}
        for curve_name, latest_run in latest_model_run_by_curve.items():
            selection_sql_query = f"""
                SELECT
                    CASE
                        WHEN max(latest_model_load) IS NULL THEN true
                        WHEN '{latest_run}' > max(latest_model_load) THEN true
                        ELSE false
                    END AS is_fresher
                FROM {self.context.catalog_prefix}bronze.{self.context.schema_prefix}meteomatics.intraday_helper
                WHERE curve_name = '{curve_name}'
                    AND successful_load = true
            """

            is_fresher_list = self.context.spark.sql(selection_sql_query).collect()

            # Check if we have a fresh new model run available
            decision_criteria = is_fresher_list[0]["is_fresher"]
            if decision_criteria:
                curves_to_pass_on[curve_name] = latest_run

        return curves_to_pass_on

    def get_intraday_data_for_param(self, now_formatted: str, parameter_combination: dict[str, Any]) -> pd.DataFrame:
        """Fetch intraday weather forecast data for a parameter.

        Requests NetCDF formatted weather data from the API and converts
        it to a pandas DataFrame.

        Args:
            now_formatted: Current time in ISO format (YYYY-MM-DDTHH:MM:SSZ).
            parameter_combination: Dictionary with parameter, model, duration, and coordinates.

        Returns:
            DataFrame with weather forecast data.

        Raises:
            requests.HTTPError: If API request fails.
        """
        payload = {
            "datetime": f"{now_formatted}P2D:{parameter_combination['duration']}",
            "parameters": parameter_combination["parameter"],
            "source": parameter_combination["model"],
            "location": parameter_combination["coordinates"],
            "outputFormat": "netcdf",
        }

        response = requests.post(
            f"{self.meteologica_base_url}/v3/meteo?", json=payload, headers=self.headers, verify=False
        )

        response.raise_for_status()
        ds = xr.open_dataset(io.BytesIO(response.content))
        df = ds.to_dataframe().reset_index()

        return df

    def _prep_payload(
        self, datetime_start: str, datetime_end: str, parameter: str, location: str, source: str, output_format: str
    ) -> dict[str, str]:
        """Prepare API request payload for actuals data.

        Constructs the JSON payload for requesting historical weather data
        from the Meteomatics API.

        Args:
            datetime_start: Start datetime in ISO format.
            datetime_end: End datetime in ISO format.
            parameter: Weather parameter to retrieve.
            location: Geographic location coordinates.
            source: Data source identifier.
            output_format: Desired output format (e.g., 'netcdf').

        Returns:
            Dictionary containing formatted API request payload.
        """
        payload = {
            "datetime": f"{datetime_start}--{datetime_end}:P1D",
            "parameters": parameter,
            "location": location,
            "source": source,
            "outputFormat": output_format,
        }
        return payload

    def get_actuals_data_for_param(
        self, datetime_start: str, datetime_end: str, parameter: str, location: str, source: str, output_format: str
    ) -> pd.DataFrame:
        """Fetch historical weather data for a parameter.

        Requests historical weather data from the Meteomatics API for the
        specified date range and converts NetCDF response to DataFrame.

        Args:
            datetime_start: Start datetime in ISO format.
            datetime_end: End datetime in ISO format.
            parameter: Weather parameter to retrieve.
            location: Geographic location coordinates.
            source: Data source identifier.
            output_format: Desired output format (e.g., 'netcdf').

        Returns:
            DataFrame with historical weather data.

        Raises:
            requests.HTTPError: If API request fails.
        """
        payload = self._prep_payload(datetime_start, datetime_end, parameter, location, source, output_format)

        url = f"{self.meteologica_base_url}/v3/meteo?"

        response = requests.post(url=url, json=payload, headers=self.headers, verify=False)

        response.raise_for_status()
        ds = xr.open_dataset(io.BytesIO(response.content))
        df = ds.to_dataframe().reset_index()
        return df

    def save_parquet_file(self, df: pd.DataFrame, volume: FileVolumeIdentifier, current_param: str) -> None:
        """Save DataFrame to parquet file in Unity Catalog volume.

        Writes a pandas DataFrame to a parquet file in the specified volume
        with a timestamped filename.

        Args:
            df: DataFrame to save.
            volume: Target volume identifier.
            current_param: Parameter name for filename generation.

        Raises:
            IOError: If file write operation fails.
        """
        volume_path = self.context.full_file_name(volume)

        now = datetime.now()
        date_str = now.strftime("%Y%m%d_%H%M%S")
        filename = f"{current_param}_{date_str}.parquet"

        full_path = os.path.join(volume_path, filename)

        df.to_parquet(full_path, engine="pyarrow", index=False)
        self.context.logger.info(f"File saved to path: {full_path}")

    def generate_sql_statement_for_intraday(self, curve_name: str, latest_model_load: str, successful_load: str) -> str:
        """Generate SQL INSERT statement for intraday_helper table.

        Constructs a SQL INSERT statement for recording intraday weather
        forecast metadata in the helper tracking table.

        Args:
            curve_name: Name of the weather curve.
            latest_model_load: Timestamp of the latest model load.
            successful_load: Timestamp of successful load completion.

        Returns:
            Formatted SQL INSERT statement ready for execution.
        """
        insert_statement = f"""
            INSERT INTO
            {self.context.catalog_prefix}bronze.{self.context.schema_prefix}meteomatics.intraday_helper
            (curve_name, latest_model_load, successful_load)
            VALUES
            ('{curve_name}', '{latest_model_load}', '{successful_load}')
        """
        return insert_statement
