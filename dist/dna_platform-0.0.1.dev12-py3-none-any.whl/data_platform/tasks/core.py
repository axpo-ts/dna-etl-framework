from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from logging import Logger
from typing import Any

from pyspark.sql import SparkSession


class Configuration:
    """Configuration class for managing task configurations.

    This class allows for the management and retrieval of task configurations using a dictionary.
    As majority of the table parameters are written in key pair values within YAML files
    this allows a universal interpretation and ease of execution for the various tasks related to the tables.

    Args:
        config (Dict[str, Dict[str, Any]]): A dictionary containing task configurations.
    """

    def __init__(self, config: dict[str, dict[str, Any]]) -> None:
        """Initialize the TaskUtility object.

        Args:
            config (Dict[str, Dict[str, Any]]): A dictionary containing the configuration for the task.

        Returns:
            None
        """
        self.config = config

    def as_dict(self) -> dict[str, Any]:
        """Returns the task configurations as a dictionary."""
        return self.config

    def get_int(self, key: Any) -> int | None:
        """Get an integer configuration value by its key."""
        return self.get_value(key, int)

    def get_float(self, key: Any) -> float | None:
        """Get a floating-point configuration value by its key."""
        return self.get_value(key, float)

    def get_string(self, key: Any) -> str | None:
        """Get a string configuration value by its key."""
        return self.get_value(key, str)

    def get_boolean(self, key: Any) -> bool | None:
        """Get a boolean configuration value by its key."""
        return self.get_value(key, bool)

    def get_value(self, key, func=lambda x: x) -> Any | None:  # noqa: ANN001
        """Get a configuration value by its key, with an optional transformation function."""
        if self.config.get(key) is not None:
            return func(self.config.get(key))
        else:
            return None

    def get_tree(self, key) -> "Configuration":  # noqa: ANN001
        """Get a subtree of configuration based on a key."""
        return Configuration(self.config.get(key, {}))


@dataclass
class TaskContext:
    """A container for managing task-related context.

    This class provides a way to store and retrieve properties within different namespaces
    to manage task-related configurations and state.

    Args:
        configuration (Configuration): The task configuration.
        logger (Logger): The logger instance.
        spark (Union[SparkSession, None]): The Spark session, if available, otherwise None.

    Attributes:
        __state (Dict[str, Dict[str, Any]]): A dictionary to store properties organized by namespaces.
    """

    configuration: Configuration
    logger: Logger
    spark: SparkSession
    __state: dict[str, dict[str, Any]] = field(default_factory=dict)

    def put_property(self, namespace: str, key: str, value: Any) -> None:
        """Adds or updates a property in the specified namespace.

        Args:
            namespace (str): The namespace of the property.
            key (str): The key of the property.
            value (Any): The value of the property.
        """
        if self.__state.get(namespace):
            self.__state[namespace].update({key: value})
        else:
            self.__state[namespace] = {key: value}

    def get_property(self, namespace: str, key: str, optional: bool = False) -> Any:
        """Retrieves a property value from the specified namespace and key.

        Args:
            namespace (str): The namespace of the property.
            key (str): The key of the property.
            optional (bool, optional): Whether the property is optional. Defaults to False.

        Returns:
            Any: The value of the property.

        Raises:
            KeyError: If the property for the given key and namespace is not found.
        """
        try:
            return self.__state.get(namespace, {}).get(key) if optional else self.__state[namespace][key]
        except KeyError:
            raise KeyError(f"Property for key: '{key}' in namespace: '{namespace}' not found")


class ETLTask(ABC):
    """Abstract base class for ETL (Extract, Transform, Load) tasks.

    Args:
        ABC (_type_): A metaclass for defining abstract base classes.

    Attributes:
        name = None
        id = None
        dataclass = None

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Abstract method that must be implemented by concrete ETL tasks.

    """

    task_name: str = ""
    id: str | None = None
    dataclass: Any = None

    @abstractmethod
    def execute(self, context: TaskContext, conf: Configuration) -> Any:
        """Execute the ETL task within the provided context and configuration.

        Args:
            context (TaskContext): The task context in which the task should be executed.
            conf (Configuration): The configuration for the ETL task.

        """
        pass

    def start_task(self, context: TaskContext, conf: Configuration) -> Any:
        """DRY block to handle initial log & conf parsing all tasks must do."""
        context.logger.info(f"running {self.task_name}")
        _conf = self.dataclass(**conf.as_dict())
        context.logger.info(_conf)
        return _conf
