from abc import ABC
from dataclasses import dataclass


@dataclass(kw_only=True)
class BaseCatalogConfig(ABC):
    """A base task config most can inherit from for catalog operations.

    Args:
       task_name (str): The name of the task.
       df_namespace (str): The namespace of the input DataFrame in the task context.
       df_key (str): The key for retrieving the input DataFrame from the task context.
       table_name (str, optional): The name of the output table where data will be written.
       schema_name (str, optional): The name of the schema for the output table.
       catalog_name (str, optional): The name of the catalog (if used) for the output table.
    """

    task_name: str
    df_key: str
    df_namespace: str
    table_name: str | None = None
    schema_name: str | None = None
    catalog_name: str | None = None
