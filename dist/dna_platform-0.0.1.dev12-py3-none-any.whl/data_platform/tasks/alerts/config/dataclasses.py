from dataclasses import dataclass


@dataclass
class ApplyAlertSQLTaskConfig:
    """Dataclass representing the configuration for the ApplyAlertSQLTask.

    Attributes:
        task_name (str): The name of the task.
        alerts_config (str): Path to the alerts configuration file.
        workspace_path_prefix (str): Prefix for the workspace path.
        env_catalog_identifier (str): Identifier for the environment catalog.
        schema_prefix (str): Prefix for the schema.
        df_output_namespace (str): Namespace to use for storing the output DataFrame in the task context.
        df_output_key (str): Key to use for storing the output DataFrame in the task context.
    """

    task_name: str
    alerts_config: str
    workspace_path_prefix: str
    env_catalog_identifier: str
    schema_prefix: str
    df_output_namespace: str
    df_output_key: str


@dataclass
class SendTeamsAlertConfig:
    """Dataclass representing the configuration for the SendTeamsAlert.

    Attributes:
        task_name (str): The name of the task.
        alerts_application_name (str): The name of the alerts application.
        df_input_namespace (str): Namespace to use for retrieving the input DataFrame from the task context.
        df_input_key (str): Key to use for retrieving the input DataFrame from the task context.
        alerts_url (str): URL to send the alerts to.
    """

    task_name: str
    alerts_application_name: str
    df_input_namespace: str
    df_input_key: str
    alerts_url: str
