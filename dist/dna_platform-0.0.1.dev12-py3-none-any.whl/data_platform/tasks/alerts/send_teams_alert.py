import requests

from data_platform.tasks.alerts.config.dataclasses import SendTeamsAlertConfig
from data_platform.tasks.core import Configuration, ETLTask, TaskContext


class SendTeamsAlertTask(ETLTask):
    """A task that sends alerts based on the alerts data.

    This task takes a alerts data list as input, formats the alert data, and sends it to a specified Teams URL.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SendAlertTaskConfig]): The configuration dataclass.
    """

    task_name = "SendTeamsAlertTask"
    dataclass = SendTeamsAlertConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SendTeamsAlertTask by retrieving the alert data from the context.

           and sending it as a message card.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)
        context.logger.info("Retrieving the alerts data from the context")
        alerts_data_list: list = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)

        card_json = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": "0078D7",
            "title": _conf.alerts_application_name,
            "text": "The following validations were executed:",
            "sections": alerts_data_list,
            "potentialAction": [],
        }
        context.logger.info("Sending alerts to the configured URL")
        context.logger.info(f"Alerts URL: {_conf.alerts_url}")
        context.logger.info(f"Card JSON: {card_json}")
        response = requests.post(_conf.alerts_url, json=card_json, timeout=10)
        response.raise_for_status()
        context.logger.info("Alerts sent successfully")
