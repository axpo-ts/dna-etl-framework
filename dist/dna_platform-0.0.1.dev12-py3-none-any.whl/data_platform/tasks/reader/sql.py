from pyspark.sql import DataFrame

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.config.dataclasses import SimpleReaderConfig
from data_platform.tasks.reader.utils import get_filter_conditions, get_watermark_filter
from data_platform.tasks.utils import CatalogUtilities


class SimpleSQLTableReaderTask(ETLTask):
    """Task for reading streaming data from a table.

    This class defines a task for reading streaming data from a table data source. It takes a configuration object
    with information about the data source, such as the table name and reader options.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.

    """

    task_name = "SimpleSQLTableReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleTableReaderTask.

        Reads data from a stream and makes it available for other tasks as a task context.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task a YAML file containing information such as the table name, schema,
                data format etc.

        """
        _conf = self.start_task(context, conf)

        df: DataFrame

        # define table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        # Apply if any filter
        if _conf.filter_options and "target_table" in _conf.filter_options:
            context.logger.info(f"filter options: {_conf.filter_options}")
            if context.spark.catalog.tableExists(_conf.filter_options["target_table"]):
                _filter = context.spark.sql(f"{_conf.filter_options['table_exists']}").collect()[0][0]
            else:
                _filter = context.spark.sql(f"{_conf.filter_options['table_not_exists']}").collect()[0][0]

            context.logger.info(
                f"Watermark Scripts : select * from {table_name} \
                                where {_conf.filter_options['filter_clause']} '{_filter}'"
            )
            sql_query = f"select * from {table_name} where {_conf.filter_options['filter_clause']} '{_filter}'"
            context.logger.info(sql_query)

            df = context.spark.sql(sql_query)
        else:
            df = context.spark.sql(f"select * from {table_name}")

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)


class SimpleBatchWatermarkReaderTask(ETLTask):
    """Task for reading batch data from a table.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[SimpleReaderConfig]): The configuration dataclass.
    """

    task_name = "SimpleBatchWatermarkReaderTask"
    dataclass = SimpleReaderConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the SimpleBatchReaderTask.

        Retrieves data from a table, creates a dataframe then puts that dataframe on the task_context
        so its available downstream to any other tasks.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration, a YAML file containing information
                                such as the table name, schema, data format etc.
        """
        _conf = self.start_task(context, conf)

        # Get table name
        table_name = CatalogUtilities.build_table_name_from_conf(_conf)

        # Build base query
        pushdown_query = f"SELECT * FROM {table_name}"

        # Only add filters if table exists
        if context.spark.catalog.tableExists(table_name):
            # Collect all filter conditions
            filter_conditions = []

            # Add watermark filter if configured
            if _conf.watermark_days and _conf.watermark_filter_col:
                watermark_filter = get_watermark_filter(
                    context,
                    table_name,  # Use current table for watermark
                    _conf.watermark_filter_col,
                    _conf.watermark_days,
                )
                if watermark_filter:
                    filter_conditions.append(watermark_filter)

            # Add custom filters if configured
            if _conf.filter_options:
                custom_filters = get_filter_conditions(context, _conf.filter_options)
                filter_conditions.extend(custom_filters)

            # Add WHERE clause if there are any filters
            if filter_conditions:
                pushdown_query += f" WHERE {' AND '.join(filter_conditions)}"

        context.logger.info(f"Executing query: {pushdown_query}")

        # Execute query directly
        df = context.spark.sql(pushdown_query)

        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)
