from typing import cast

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.config.dataclasses import ApiReaderConfig, BaseApiReaderConfig
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy


class TennetAuthHeader(HttpHeaderStrategy):
    """Class to add Tennet Authentication Header."""

    def append_header(self, context: TaskContext, conf: BaseApiReaderConfig, headers: dict) -> dict:
        """Append header based on access token retrieved from configuration."""
        conf = cast(ApiReaderConfig, conf)
        try:
            conf_namespace = getattr(conf, "secret_namespace")
            conf_api_key = getattr(conf, "secret_token")
            api_key = context.get_property(namespace=conf_namespace, key=conf_api_key)
        except Exception as e:
            context.logger.error(f"Failed to obtain access token: {e}")
            raise ValueError("Failed to obtain access token:") from e
        apikey_header = {"apikey": api_key}
        headers.update(apikey_header)
        return headers
