import io
import time
from calendar import monthrange
from datetime import datetime, timedelta
from typing import Any

import pandas as pd
from requests import Response

from data_platform.tasks.core import Configuration, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig
from data_platform.tasks.reader.api.http.request_reader import RequestsApiReaderTask


class BaseRegelleistungApiReaderTask(RequestsApiReaderTask):
    """Base task for reading aFRR data from the Regelleistung API and converting Excel to CSV."""

    task_name = "BaseRegelleistungApiReaderTask"
    verify = True
    file_name_prefix: str = "regelleistung"
    file_extension: str = "csv"
    base_url = "https://www.regelleistung.net/apps/cpp-publisher/api/v1/download/tenders"
    market_type: str = ""
    product_type: str = "aFRR"

    # New class constants for default date handling
    DEFAULT_DELTA_DAYS = 30

    def __init__(self) -> None:
        """Initialize the task with default configuration."""
        super().__init__()
        self.dataclass = BaseApiReaderConfig

    def execute(self, context: TaskContext, conf: Configuration, params: dict[str, Any] | None = None) -> None:
        """Execute the task to download and process data."""
        # Set logger from context
        self.logger = context.logger
        self.logger.info(f"Starting {self.task_name}")

        # Start the task and get the proper config
        _conf = self.start_task(context, conf)

        params = params or {}
        today = datetime.today()
        first_day = datetime(today.year, today.month, 1)

        # Priority: params > conf > default
        from_date_str = params.get("from_date") if params else None
        if not from_date_str and hasattr(_conf, "from_date") and _conf.from_date:
            from_date_str = _conf.from_date

        to_date_str = params.get("to_date") if params else None
        if not to_date_str and hasattr(_conf, "to_date") and _conf.to_date:
            to_date_str = _conf.to_date

        full_load = params.get("full_load", "false").lower() == "true" if params else False
        if not full_load and hasattr(_conf, "full_load"):
            full_load = str(getattr(_conf, "full_load", "false")).lower() == "true"

        delta_days = (
            int(params.get("delta_load_window_days", self.DEFAULT_DELTA_DAYS)) if params else self.DEFAULT_DELTA_DAYS
        )
        if hasattr(_conf, "delta_load_window_days"):
            delta_days = int(getattr(_conf, "delta_load_window_days", self.DEFAULT_DELTA_DAYS))

        # Determine date range based on full_load or other parameters
        if full_load:
            from_date = datetime(2018, 7, 1)
            to_date = today
        elif not from_date_str and not to_date_str:
            to_date = today
            from_date = today - timedelta(days=delta_days)
        else:
            # Parse provided dates or use defaults
            from_date = self._parse_date(from_date_str) if from_date_str else first_day
            to_date = self._parse_date(to_date_str) if to_date_str else today

        self.logger.info(f"Processing data from {from_date} to {to_date}")

        # Process data by date ranges
        all_dataframes = []
        current_date = from_date
        request_count = 0
        max_requests_per_batch = 5

        while current_date <= to_date:
            if request_count > 0 and request_count % max_requests_per_batch == 0:
                self.logger.info(f"Pausing for 3 seconds after {request_count} requests...")
                time.sleep(3)

            # Check if we can download a full month
            if current_date.day == 1:
                # Calculate last day of the month
                last_day_of_month = datetime(
                    current_date.year, current_date.month, monthrange(current_date.year, current_date.month)[1]
                )

                # If the entire month is within our date range and not in the future
                if last_day_of_month <= to_date and last_day_of_month < today:
                    # Try to download the full month
                    df = self._download_month_data(current_date, last_day_of_month, context)
                    request_count += 1

                    if df is not None:
                        all_dataframes.append(df)
                        # Move to the next month
                        if current_date.month == 12:
                            current_date = datetime(current_date.year + 1, 1, 1)
                        else:
                            current_date = datetime(current_date.year, current_date.month + 1, 1)
                        continue
                    else:
                        self.logger.info(
                            f"Month download failed for {current_date.strftime('%Y-%m')}, running daily downloads.."
                        )

            # Skip future dates
            if current_date > today:
                self.logger.info(f"Skipping future date: {current_date.strftime('%Y-%m-%d')}")
                current_date += timedelta(days=1)
                continue

            # Download single day data
            df = self._download_single_day_data(current_date, context)
            request_count += 1

            if df is not None:
                all_dataframes.append(df)

            # Add delay between individual requests
            time.sleep(0.4)

            # Move to next day
            current_date += timedelta(days=1)

        # Combine all dataframes
        if all_dataframes:
            combined_df = pd.concat(all_dataframes, ignore_index=True)
            combined_df = combined_df.drop_duplicates()
            csv_data = combined_df.to_csv(index=False)

            # Ensure the config has the required attributes for handle_response
            if not hasattr(_conf, "df_key"):
                _conf.df_key = None
            if not hasattr(_conf, "df_namespace"):
                _conf.df_namespace = None

            if _conf.volume_storage_path:
                self._current_filename = f"{self.file_name_prefix}_{from_date.strftime('%Y%m%d')}.csv"
            elif _conf.df_namespace and _conf.df_key:
                _conf.df_key = f"{self.file_name_prefix}_{from_date.strftime('%Y%m%d')}"

            self.logger.info(f"Processing {len(combined_df)} rows of data")
            self.logger.info(f"Data columns: {list(combined_df.columns)}")

            self.handle_response(context, _conf, csv_data)
        else:
            self.logger.warning("No data was retrieved for the specified date range")

    def _download_month_data(
        self, start_date: datetime, end_date: datetime, context: TaskContext
    ) -> pd.DataFrame | None:
        """Download data for a full calendar month using the files endpoint."""
        try:
            # Build URL for full month download
            # Format: RESULT_OVERVIEW_CAPACITY_MARKET_aFRR_2024-01-01_2024-01-31.xlsx
            filename = f"RESULT_OVERVIEW_{self.market_type}_MARKET_{self.product_type}_{start_date.strftime('%Y-%m-%d')}_{end_date.strftime('%Y-%m-%d')}.xlsx"  # noqa: E501
            url = f"{self.base_url}/files/{filename}"

            self.logger.info(f"Downloading full month data from: {url}")

            # Create a temporary config for this specific request
            temp_conf = BaseApiReaderConfig(task_name=self.task_name, df_key="", df_namespace="", api_url=url)

            try:
                response = self.execute_request(context, temp_conf, payload={}, params=None)

                if response and response.status_code == 200:
                    df = self._process_response(response)
                    if df is not None:
                        self.logger.info(f"Successfully downloaded month data for {start_date.strftime('%Y-%m')}")
                        return df
            except ValueError as e:
                if "404" in str(e):
                    self.logger.warning(f"Month file not found for {start_date.strftime('%Y-%m')}")
                    return None
                else:
                    raise

        except Exception as e:
            self.logger.warning(f"Failed to download month data for {start_date.strftime('%Y-%m')}: {e}")

        return None

    def _download_single_day_data(self, date: datetime, context: TaskContext) -> pd.DataFrame | None:
        """Download data for a single day using the resultsoverview endpoint."""
        try:
            # Build URL for single day download
            url = f"{self.base_url}/resultsoverview"
            params = {
                "date": date.strftime("%Y-%m-%d"),
                "exportFormat": "xlsx",
                "market": self.market_type,
                "productTypes": self.product_type,
            }

            self.logger.info(f"Downloading single day data for: {date.strftime('%Y-%m-%d')} from {url}")

            # Create a temporary config for this specific request
            temp_conf = BaseApiReaderConfig(task_name=self.task_name, df_key="", df_namespace="", api_url=url)

            try:
                response = self.execute_request(context, temp_conf, payload={}, params=params)

                if response and response.status_code == 200:
                    df = self._process_response(response)
                    if df is not None:
                        self.logger.info(f"Successfully downloaded day data for {date.strftime('%Y-%m-%d')}")
                        return df
            except ValueError as e:
                if "404" in str(e):
                    self.logger.warning(f"Data not found for {date.strftime('%Y-%m-%d')}")
                    return None
                else:
                    raise

        except Exception as e:
            self.logger.warning(f"Failed to download day data for {date.strftime('%Y-%m-%d')}: {e}")

        return None

    def _parse_date(self, date_str: str) -> datetime:
        """Parse date string to datetime object."""
        try:
            return datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            self.logger.error(f"Invalid date format: {date_str}. Expected YYYY-MM-DD")
            raise

    def _process_response(self, response: Response) -> pd.DataFrame | None:
        """Process API response and convert Excel to DataFrame."""
        try:
            df = pd.read_excel(io.BytesIO(response.content), engine="openpyxl")

            # Log the shape of the data
            self.logger.info(f"Downloaded data shape: {df.shape}")

            return df
        except Exception as e:
            self.logger.error(f"Failed to process Excel response: {e}")
            return None

    def save_to_volume(self, content: str, context: TaskContext, conf: BaseApiReaderConfig) -> None:
        """Save the CSV content to a file in the specified volume using Databricks utilities.

        Args:
            content (str): The CSV string content to save.
            context (TaskContext): The context for task execution.
            conf (BaseApiReaderConfig): The configuration containing storage path.
        """
        if not conf.volume_storage_path:
            context.logger.warning("No volume_storage_path specified in configuration")
            return

        from data_platform.common import get_dbutils

        if hasattr(self, "_current_filename"):
            filename = self._current_filename
        else:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{self.file_name_prefix}_{timestamp}.csv"

        file_path = f"{conf.volume_storage_path}/{filename}"

        try:
            dbutils = get_dbutils(context.spark)
            if dbutils:
                dbutils.fs.put(file_path, content, overwrite=True)
                context.logger.info(f"Successfully saved data to volume: {file_path}")
            else:
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
                context.logger.info(f"Successfully saved data to volume (fallback): {file_path}")

        except Exception as e:
            context.logger.error(f"Failed to save data to volume: {e}")
            raise


class RegelleistungAfrrCapacityReaderTask(BaseRegelleistungApiReaderTask):
    """Task for reading aFRR capacity prices from Regelleistung API."""

    task_name = "RegelleistungAfrrCapacityReaderTask"
    file_name_prefix = "regelleistung_afrr_capacity"
    market_type = "CAPACITY"


class RegelleistungAfrrEnergyReaderTask(BaseRegelleistungApiReaderTask):
    """Task for reading aFRR energy prices from Regelleistung API."""

    task_name = "RegelleistungAfrrEnergyReaderTask"
    file_name_prefix = "regelleistung_afrr_energy"
    market_type = "ENERGY"
