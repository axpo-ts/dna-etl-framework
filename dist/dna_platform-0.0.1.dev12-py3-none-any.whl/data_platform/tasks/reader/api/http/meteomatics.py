# CPD-OFF - suppress copy paste detection on imports
# CPD-ON - suppress copy paste detection on imports
import io
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from io import BytesIO, StringIO
from typing import Any, cast

import pandas as pd
from pyspark.sql import DataFrame
from requests import Response

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import BaseApiReaderConfig, BearerApiReaderConfig
from data_platform.tasks.reader.api.http.headers.access_token_bearer import AccessTokenBearerAuthHeader
from data_platform.tasks.reader.api.http.headers.http_header_strategy import HttpHeaderStrategy
from data_platform.tasks.reader.api.http.headers.json_content_type import JsonContentTypeHeader
from data_platform.tasks.reader.api.http.request_reader import RequestsApiReaderTask
from data_platform.tasks.transform.config.dataclasses import MeteomaticsIterateApiConfig


@dataclass(kw_only=True)
class MeteomaticsApiReaderConfig(BearerApiReaderConfig):
    """Configuration class for Meteomatics API Reader.

    This class extends BearerApiReaderConfig and includes additional parameters
    specific to the Meteomatics API, such as API URL parameters.
    """

    api_url_params: dict | None = field(default_factory=dict)


class MeteomaticsApiReaderTask(RequestsApiReaderTask):
    """Task for downloading API data from Meteomatics.

    Needs it's own implemenation due to bespoke way API url can be overridden from Spark and
    how the response is extracted and processed
    """

    task_name = "MeteomaticsApiReaderTask"

    def __init__(self) -> None:
        """Setup http_headers to implement in init block."""
        self.http_headers: list[HttpHeaderStrategy] = [JsonContentTypeHeader(), AccessTokenBearerAuthHeader()]
        self.dataclass = MeteomaticsApiReaderConfig
        self.timeout = 1800

    def prepare_request(self, context: TaskContext, conf: BaseApiReaderConfig) -> dict:  # is this receiving params
        """Prepare the request payload for GET or POST."""
        # Use the config to determine the method and coordinates
        api_method = getattr(conf, "api_method", "GET")
        coordinates = None
        # Try to get coordinates from api_url_params if available
        if hasattr(conf, "api_url_params") and conf.api_url_params:
            coordinates = conf.api_url_params.get("api_location_range")
            context.logger.info(f"Coordinates: {coordinates}")
        # For POST, return the JSON body
        if api_method == "POST":
            context.logger.info(f"!Coordinates (forced): {coordinates}")
            return {"UrlBody": coordinates or "DEBUG-EMPTY"}
        # For GET, return empty dict (no body)
        return {}

    def override_config(self, context: TaskContext, conf: Any) -> Any:
        """Override so can switch api_url to come from spark if flag set."""
        _conf = cast(BearerApiReaderConfig, conf)
        if _conf.api_url_sql:
            _conf.api_url = context.spark.sql(_conf.api_url).collect()[0][0]
        return _conf

    def extract_content(self, context: TaskContext, conf: BaseApiReaderConfig, response: Response) -> object:
        """Extract Meteomatrics Response."""
        # Check the sample response
        response_text = response.text[0:12]

        # Check if data is available for the given date range.
        """
            There are scenarios where the response is OK (200)
            but the returned data is blank or contains an error message.
            This generally happens if there is no data for the given dates or
            if the requested data exceeds the API response size limit.
        """
        conf = cast(BearerApiReaderConfig, conf)
        if response_text.strip() == "" or response_text == "Server error":
            context.logger.error(f"Failed to get response for URL : {conf.api_url}")
            context.logger.error(f"Error message: {response_text}")
            raise ValueError("Failed to get response for given url")

        # Process the netCDF response
        return response.content


class MeteomaticsIterateApiTask(ETLTask):
    """A task that iterates over a date range to fetch data from the Meteomatics API and processes it.

    This task fetches weather data from the Meteomatics API for specified locations and time periods.
    The data is retrieved in NetCDF format and can be processed in two ways:

    1. Using predefined location ranges:
       - Fetches data for a fixed set of latitude/longitude coordinates
       - Coordinates are specified in the API URL parameters

    2. Using a DataFrame with locations:
       - Takes a DataFrame containing resource_id and coordinate pairs
       - Makes API calls for each unique coordinate in the DataFrame
       - Allows dynamic location specification

    The task splits large date ranges into smaller intervals to optimize API calls and handles
    the combination of multiple NetCDF responses into a single dataset.

    Attributes:
        task_name (str): The name of the task, set to "MeteomaticsIterateApiTask"
        dataclass (Type[MeteomaticsIterateApiConfig]): Configuration class defining API parameters,
            credentials, and data handling options

    Methods:
        _split_date_range_by_days(start_date, end_date, diff_days, date_format):
            Splits a date range into smaller intervals for manageable API calls

        _union_netcdf(keys_lst, context):
            Combines multiple NetCDF responses into a single consolidated dataset

        _get_coordinates_from_df(context, df_key):
            Extracts unique coordinate pairs from the provided DataFrame

        _make_api_call(context, conf, coordinates, date_range):
            Makes an API call to Meteomatics for given coordinates and date range

        _process_api_response(context, response, coordinates):
            Processes the API response and converts it to a NetCDF dataset

        execute(context: TaskContext, conf: MeteomaticsIterateApiConfig):
            Main execution method that orchestrates the API calls and data processing
    """

    task_name = "MeteomaticsIterateApiTask"
    dataclass = MeteomaticsIterateApiConfig

    @staticmethod
    def _split_date_range_by_days(
        *, start_date: datetime, end_date: datetime, diff_days: int, date_format: str
    ) -> list:
        """Splits the date range into smaller intervals.

        Args:
            start_date (datetime): The start date of the range.
            end_date (datetime): The end date of the range.
            diff_days (int): The number of days in each interval.
            date_format (str): The format of the date.

        Returns:
            list: A list of tuples containing the start and end dates of each interval.
        """
        date_ranges = []
        current_start_date = start_date

        while current_start_date < end_date:  # Changed <= to < to avoid same dates
            current_end_date = min(current_start_date + timedelta(days=diff_days), end_date)
            if current_start_date != current_end_date:  # Only add if dates are different. 1 day returns a matrix
                date_ranges.append((current_start_date.strftime(date_format), current_end_date.strftime(date_format)))
            current_start_date = current_end_date + timedelta(days=1)

        return date_ranges

    @staticmethod
    def _union_netcdf(*, keys_lst: list, context: TaskContext) -> bytes:
        """Combines multiple NetCDF files into a single NetCDF file.

        Args:
            keys_lst (list): A list of keys representing the NetCDF files.
            context (TaskContext): Task context containing logger and other utilities.

        Returns:
            bytes: The combined NetCDF file as bytes.
        """
        import xarray as xr  # type: ignore

        datasets = []
        for res in keys_lst:
            file_obj = BytesIO(res)
            try:
                dataset = xr.open_dataset(file_obj, engine="h5netcdf")  # Use engine explicitly
            except (ValueError, OSError) as e:
                context.logger.error(f"Error opening dataset with h5netcdf engine: {e!s}")
                raise Exception(f"Failed to open NetCDF dataset: {e!s}")

            datasets.append(dataset)

        combined_dataset = xr.concat(datasets, dim="time")
        return combined_dataset.to_netcdf()

    @staticmethod
    def _union_csv(*, keys_lst: list, context: TaskContext) -> DataFrame:
        """Combines multiple CSV responses into a single CSV file using PySpark.

        Args:
            keys_lst (list): A list of CSV content as bytes.
            context (TaskContext): Task context containing logger and other utilities.

        Returns:
            bytes: The combined CSV file as bytes.
        """
        import pandas as pd

        combined_df = None

        for res in keys_lst:
            csv_data = StringIO(res.decode("utf-8"))
            pandas_df = pd.read_csv(csv_data)
            temp_df = context.spark.createDataFrame(pandas_df)
            if combined_df is None:
                combined_df = temp_df
            else:
                combined_df = combined_df.unionAll(temp_df)
        return combined_df  # type: ignore

    @staticmethod
    def _create_api_url(
        *,
        context: TaskContext,
        base_url: str,
        date_range: tuple[str, str],
        resource_id: str,
        coordinates: str,
        output_format: str,
        model: str,
        duration: str,
        api_version: str,
        api_endpoint: str,
        api_method: str,
    ) -> str:
        """Create the Meteomatics API URL with the given parameters."""
        api_from_date, api_to_date = date_range
        if api_method == "GET":
            api_url = (
                f"{base_url}{api_version}/{api_endpoint}/{api_from_date}--{api_to_date}:{duration}/"
                f"{resource_id}/{coordinates}/{output_format}?model={model}&remoteUser=DNA&timeout=1800000"
            )
        elif api_method == "POST":
            api_url = f"{base_url}{api_version}/{api_endpoint}/longURL"
        context.logger.info(f"api_url: {api_url}")
        return api_url

    @staticmethod
    def _create_api_config(*, df_key: str, api_url: str, _conf: MeteomaticsIterateApiConfig) -> dict:
        """Create the API reader configuration."""
        return {
            "task_name": "MeteomaticsApiReaderTask",
            "df_key": df_key,
            "df_namespace": _conf.df_namespace,
            "api_url": api_url,
            "secret_namespace": _conf.secret_namespace,
            "api_name": _conf.api_name,
            "api_method": _conf.api_method,
            "access_token_key": _conf.access_token_key,
            "api_url_params": _conf.api_url_params,
        }

    @staticmethod
    def _build_post_params(*, params: dict, date_range: tuple | None = None) -> dict:
        # Use date_range if provided, else use params["start_date"] and params["end_date"]
        if date_range:
            start_date, end_date = date_range
        else:
            start_date, end_date = params["start_date"], params["end_date"]
        return {
            "time": f"{start_date}--{end_date}:{params['api_duration']}",
            "parameters": params["api_parameter"],
            "format": params["api_output_format"],
            "calibrated": "TRUE",
            "timeout": "900000",
            "remoteUser": "DNA",
            "model": params["api_model"],
        }

    @staticmethod
    def _fetch_api_data(
        *, context: TaskContext, api_config: dict, params: dict | None = None, api_call_counter: list[int] | None = None
    ) -> bytes:
        """Execute API request and return response."""
        context.logger.info(f"API Reader Config: {api_config}")
        api_reader_task = MeteomaticsApiReaderTask()
        api_reader_task.execute(context, Configuration(api_config), params=params)

        # Increment API call counter if provided
        if api_call_counter is not None:
            api_call_counter[0] += 1
            context.logger.info(f"API call #{api_call_counter[0]} completed")

        return context.get_property(namespace=api_config["df_namespace"], key=str(api_config["df_key"]))

    @staticmethod
    def _process_single_location(
        *,
        context: TaskContext,
        params: dict,
        date_range: tuple,
        _conf: MeteomaticsIterateApiConfig,
        location: str | None = None,
        api_call_counter: list | None = None,
    ) -> bytes:
        """Process API request for a single location."""
        # Use provided location or fall back to params
        coordinates = location or params["api_location_range"]
        context.logger.info(f"-> coordinates: {coordinates}")

        api_url = MeteomaticsIterateApiTask._create_api_url(
            context=context,
            base_url=params["api_base_url"],
            date_range=date_range,
            resource_id=params["api_parameter"],
            coordinates=coordinates,
            output_format=params["api_output_format"],
            model=params["api_model"],
            duration=params["api_duration"],
            api_version=params["api_version"],
            api_endpoint=params["api_endpoint"],
            api_method=_conf.api_method or "GET",  # Provide default value to fix linter errors
        )
        context.logger.info(f"api_url: {api_url}")
        api_config = MeteomaticsIterateApiTask._create_api_config(
            df_key=f"{_conf.df_key}_default", api_url=api_url, _conf=_conf
        )
        post_params = None
        if _conf.api_method == "POST":
            post_params = MeteomaticsIterateApiTask._build_post_params(params={**params}, date_range=date_range)
        return MeteomaticsIterateApiTask._fetch_api_data(
            context=context, api_config=api_config, params=post_params, api_call_counter=api_call_counter
        )

    @staticmethod
    def _process_curve_location(
        *,
        context: TaskContext,
        row: dict,
        params: dict,
        date_range: tuple,
        _conf: MeteomaticsIterateApiConfig,
        api_call_counter: list | None = None,
    ) -> bytes | None:
        """Process API request for a curve location."""
        if row["resource_id"] != params["api_parameter"]:
            return None

        context.logger.info(f"Processing Meteomatics API for {row['resource_id']}")
        context.logger.info(f"params: {params}")
        api_url = MeteomaticsIterateApiTask._create_api_url(
            context=context,
            base_url=params["api_base_url"],
            date_range=date_range,
            resource_id=row["resource_id"],
            coordinates=row["coordinates"],
            output_format=params["api_output_format"],
            model=params["api_model"],
            api_version=params["api_version"],
            api_endpoint=params["api_endpoint"],
            duration=params["api_duration"],
            api_method=_conf.api_method or "GET",  # Provide default value to fix linter error
        )
        api_config = MeteomaticsIterateApiTask._create_api_config(
            df_key=f"{_conf.df_key}_{row['resource_id']}_{row['coordinates']}", api_url=api_url, _conf=_conf
        )
        post_params = None
        if _conf.api_method == "POST":
            # Use row values for resource_id and coordinates
            post_params = MeteomaticsIterateApiTask._build_post_params(
                params={
                    **params,
                    "api_parameter": row["resource_id"],
                    "api_location_range": row["coordinates"],
                },
                date_range=date_range,
            )
        return MeteomaticsIterateApiTask._fetch_api_data(
            context=context, api_config=api_config, params=post_params, api_call_counter=api_call_counter
        )

    @staticmethod
    def split_rectangle_by_longitude(*, rectangle: str, lon_step: int) -> list[str]:
        """Splits a Meteomatics-style rectangle string into smaller chunks based on longitude.

        This is used to avoid the API request size limit.

        Args:
            rectangle (str): Input rectangle in the format "lat1,lon1_lat2,lon2:latres,lonres"
            lon_step (int): Step size (in degrees) to chunk the longitude range

        Returns:
            List[str]: List of rectangle strings split by longitude
        """
        coord_part, resolution_part = rectangle.split(":")
        lat1, lon1 = map(float, coord_part.split("_")[0].split(","))
        lat2, lon2 = map(float, coord_part.split("_")[1].split(","))
        lat_res, lon_res = resolution_part.split(",")

        lon_start = min(lon1, lon2)
        lon_end = max(lon1, lon2)

        rectangles = []
        for l_start in range(int(lon_start), int(lon_end), lon_step):
            l_end = min(l_start + lon_step, lon_end)
            rect = f"{lat1},{l_start}_{lat2},{l_end}:{lat_res},{lon_res}"
            rectangles.append(rect)

        return rectangles

    @staticmethod
    def parse_date(*, date_str: str, date_format: str) -> datetime:
        """Parse date string using the specified date format.

        Args:
            date_str (str): The date string to parse.
            date_format (str): The expected date format.

        Returns:
            datetime: Parsed datetime object.

        Raises:
            ValueError: If the date string doesn't match the expected format.
        """
        try:
            return datetime.strptime(date_str, date_format)
        except ValueError:
            raise ValueError(f"Date format not supported: {date_str}. Expected format: {date_format}")

    @staticmethod
    def _get_ensemble_time_ranges(
        *, context: TaskContext, _conf: MeteomaticsIterateApiConfig, params: dict
    ) -> pd.DataFrame:
        """Get time ranges for ensemble data from Meteomatics API.

        Args:
            context (TaskContext): Task context containing logger and other utilities.
            _conf (MeteomaticsIterateApiConfig): Configuration containing secret namespace and access token key.
            params (dict): API parameters containing the resource_id/parameter to query.

        Returns:
            pd.DataFrame: DataFrame containing time ranges for each parameter.
        """
        # Use the parameter from the configuration instead of hardcoding
        parameter = params["api_parameter"]

        # Use the base URL from the configuration
        base_url = params["api_base_url"]

        api_version = params["api_version"]

        api_endpoint = params["api_endpoint"]

        api_url_dev = (
            f"{base_url}{api_version}/{api_endpoint}/get_time_range?model={params['api_model']}"
            f"&parameters={parameter}&timeout=900000"
        )

        # Log the full URL for debugging
        context.logger.info(f"Request URL: {api_url_dev}")

        # Create API config for the time range request
        api_config = {
            "task_name": "MeteomaticsApiReaderTask",
            "df_key": "ensemble_time_ranges",
            "df_namespace": str(_conf.df_namespace),
            "api_url": api_url_dev,
            "secret_namespace": str(_conf.secret_namespace),
            "api_name": _conf.api_name,
            "api_method": "GET",
            "access_token_key": str(_conf.access_token_key),
            "api_url_params": _conf.api_url_params,
        }

        # Use the existing API reader task to handle headers and authentication
        api_reader_task = MeteomaticsApiReaderTask()
        api_reader_task.execute(context, Configuration(api_config))

        # Get the response content
        response_content = context.get_property(
            namespace=str(api_config["df_namespace"]), key=str(api_config["df_key"])
        )

        # Parse the CSV response
        time_ranges = pd.read_csv(io.BytesIO(response_content), sep=";")
        time_ranges = time_ranges.set_index("parameter")
        time_ranges.iloc[0, 0] = params["current_date"]  # Replace first date with current_date

        context.logger.info(f"Retrieved time ranges: {time_ranges}")
        return time_ranges

    @staticmethod
    def _process_locations(
        *,
        context: TaskContext,
        _conf: MeteomaticsIterateApiConfig,
        params: dict,
        date_ranges: list,
        api_call_counter: list | None = None,
    ) -> list[bytes]:
        """Process all locations and return list of API responses."""
        api_response_list: list[bytes] = []
        context.logger.info(f"params: {params}")

        # Get the api_location_range string
        api_location_range = params["api_location_range"]

        context.logger.info(f"Processing api_location_range: {api_location_range}")

        # Extract lon_step from params and convert to int if present
        lon_step: int | None = None
        if lon_step_str := params["lon_step"]:
            try:
                lon_step = int(lon_step_str)
            except (ValueError, TypeError):
                pass
        context.logger.info(f"lon_step: {lon_step}")
        context.logger.info(f"date_ranges: {date_ranges}")
        # Process the single rectangle coordinate for each date range and each rectangle
        for date_range in date_ranges:
            try:
                if lon_step:
                    rectangles = MeteomaticsIterateApiTask.split_rectangle_by_longitude(
                        rectangle=api_location_range, lon_step=lon_step
                    )
                    for rectangle in rectangles:
                        response = MeteomaticsIterateApiTask._process_single_location(
                            context=context,
                            params=params,
                            date_range=date_range,
                            _conf=_conf,
                            location=rectangle,
                            api_call_counter=api_call_counter,
                        )
                        if response is not None:
                            api_response_list.append(response)
                else:
                    response = MeteomaticsIterateApiTask._process_single_location(
                        context=context,
                        params=params,
                        date_range=date_range,
                        _conf=_conf,
                        location=api_location_range,
                        api_call_counter=api_call_counter,
                    )
                    if response is not None:
                        api_response_list.append(response)
            except Exception as e:
                context.logger.error(f"Error processing date range {date_range}: {e}")
                # Continue with other date ranges

        return api_response_list

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the MeteomaticsIterateApiTask."""
        _conf = self.start_task(context, conf)

        if not _conf.api_url_params:
            raise ValueError("api_url_params is required but was None")

        # Extract API parameters
        params = _conf.api_url_params

        # Initialize API call counter as a list to allow modification in nested functions
        api_call_counter = [0]

        # Check if this is an ensemble request
        if _conf.member_selection:
            context.logger.info("Processing ensemble data with time range lookup")

            # Get time ranges for ensemble data
            time_ranges_df = self._get_ensemble_time_ranges(context=context, _conf=_conf, params=params)

            # Process each parameter with its available time range
            api_response_list = []
            for parameter in time_ranges_df.index:
                parameter_start = time_ranges_df.loc[parameter, "start"]
                parameter_end = time_ranges_df.loc[parameter, "end"]

                context.logger.info(f"Processing parameter {parameter} from {parameter_start} to {parameter_end}")

                # Update params with parameter-specific date range
                params_copy = params.copy()
                params_copy["start_date"] = parameter_start
                params_copy["end_date"] = parameter_end
                params_copy["resource_id"] = parameter  # Use parameter as resource_id
                context.logger.info(f"params_copy: {params_copy}")
                # Convert string dates to datetime objects using the configured format
                start_date = MeteomaticsIterateApiTask.parse_date(
                    date_str=params_copy["start_date"], date_format=params_copy["api_date_format"]
                )
                end_date = MeteomaticsIterateApiTask.parse_date(
                    date_str=params_copy["end_date"], date_format=params_copy["api_date_format"]
                )

                date_ranges = self._split_date_range_by_days(
                    start_date=start_date,
                    end_date=end_date,
                    diff_days=int(params_copy["api_iterate_days"]),
                    date_format=params_copy["api_date_format"],
                )
                context.logger.info(f"date_ranges for {parameter}: {date_ranges}")

                # Process locations for this parameter
                parameter_responses = self._process_locations(
                    context=context,
                    _conf=_conf,
                    params=params_copy,
                    date_ranges=date_ranges,
                    api_call_counter=api_call_counter,
                )
                api_response_list.extend(parameter_responses)
        else:
            # Original non-ensemble logic
            context.logger.info("Processing standard meteomatics data")

            # Convert string dates to datetime objects using the configured format
            start_date = MeteomaticsIterateApiTask.parse_date(
                date_str=params["start_date"], date_format=params["api_date_format"]
            )
            end_date = MeteomaticsIterateApiTask.parse_date(
                date_str=params["end_date"], date_format=params["api_date_format"]
            )

            date_ranges = self._split_date_range_by_days(
                start_date=start_date,
                end_date=end_date,
                diff_days=int(params["api_iterate_days"]),
                date_format=params["api_date_format"],
            )
            context.logger.info(f"date_ranges: {date_ranges}")
            api_response_list = self._process_locations(
                context=context, _conf=_conf, params=params, date_ranges=date_ranges, api_call_counter=api_call_counter
            )

        context.logger.info(f"api_response_list count: {len(api_response_list)}")

        # Log total API calls made
        context.logger.info(f"Total API calls made: {api_call_counter[0]}")

        merge_content: Any = None
        if params["api_output_format"] == "csv":
            merge_content = self._union_csv(keys_lst=api_response_list, context=context)
        elif params["api_output_format"] == "netcdf":
            merge_content = self._union_netcdf(keys_lst=api_response_list, context=context)
        print(f"merge_content type: {type(merge_content)}")
        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=merge_content)
