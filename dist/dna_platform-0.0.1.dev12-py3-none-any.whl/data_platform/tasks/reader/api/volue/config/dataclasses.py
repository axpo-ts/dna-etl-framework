from dataclasses import dataclass
from typing import Optional


@dataclass(kw_only=True)
class VolueCurveBatchConfig:
    """Configuration class for VolueCurveBatchTask.

    This class defines the configuration parameters required for VolueCurveBatchTask.

    Args:
        task_name (str): The name of the task
        curve_file (str): The file with all curves to split into batches
        items_per_batch (int): The number of curves to put in each batch
        batch_var_name (str): Variable name to put the output JSON as a task parameter to databricks

    """

    task_name: str
    curve_file: str
    items_per_batch: int
    maximum_days_per_batch: int
    target_catalog_name: str
    target_schema_name: str
    delta_load_window_days: int
    delta_column: str
    randomise_batches: bool = False
    prefix_curve_filter: str | None = None
    ingested_dates_task: str | None = None
    curve_params: Optional[dict] = None  # noqa: UP007
