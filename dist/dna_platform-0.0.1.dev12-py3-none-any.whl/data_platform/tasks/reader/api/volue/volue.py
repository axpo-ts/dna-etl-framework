import asyncio
import datetime
import gc
import math
import random
import re
from abc import ABC, abstractmethod
from collections.abc import Generator
from typing import Any, cast

import pandas as pd
import volue_insight_timeseries as vit
from dateutil.parser import isoparse
from pyspark.sql import DataFrame, Row
from pyspark.sql.types import ArrayType, IntegerType, StringType, StructField, StructType, TimestampType
from tenacity import retry, stop_after_attempt, wait_exponential

from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reader.api.config.dataclasses import ApiReaderConfig
from data_platform.tasks.reader.api.volue.config.dataclasses import VolueCurveBatchConfig
from data_platform.tasks.reader.api.volue.config.template import load_curve_file_and_expand

CurveDataResult = tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]


class VolueAbstractApiReaderTask(ETLTask, ABC):
    """Abstract Task to have common API auth functions shared."""

    task_name = "VolueAbstractApiReaderTask"
    dataclass = ApiReaderConfig

    @abstractmethod
    def run_main(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, str], context: TaskContext
    ) -> DataFrame:
        """Method for Async Implementation.

        Parameters:
        - client_credentials: Dictionary of credential groups, each containing client_id and client_secret
        - api_get_params: Dictionary containing API parameters
        - context: Task context for logging and other operations

        Returns:
        - DataFrame containing results
        """
        pass

    def _get_credentials_for_curve(self, curve_name: str, client_credentials: dict[str, dict]) -> str:
        """Determine which credential group to use for a given curve.

        Parameters:
        - curve_name: The name of the curve
        - client_credentials: Dictionary of credential groups

        Returns:
        - The name of the matched credential group or 'default'
        """
        for group, credential in client_credentials.items():
            if group == "default":
                continue
            re_pattern = credential.get("re_pattern")
            if re_pattern and re.match(re_pattern, curve_name):  # Added null check
                print(f"Using credential group '{group}' for curve '{curve_name}'")
                return client_credentials.get(group)
        return client_credentials.get("default")  # Explicit default return

    def get_client_credentials(self, context: TaskContext, conf: Configuration) -> dict[str, dict[str, str]]:
        """Get all credential sets from the configuration.

        Parameters:
        - context: Task context
        - conf: Configuration

        Returns:
        - Dictionary mapping credential groups to client_id and client_secret pairs
        """
        _conf = self.dataclass(**conf.as_dict())
        credentials = {}

        # Get default credentials
        default_client_id = context.get_property(
            namespace=_conf.secret_namespace,
            key=_conf.secret_client_id,
            optional=True,
        )

        default_client_secret = context.get_property(
            namespace=_conf.secret_namespace,
            key=_conf.secret_client_secret,
            optional=True,
        )

        credentials["default"] = {"client_id": default_client_id, "client_secret": default_client_secret}

        # Get additional credentials if specified
        if hasattr(_conf, "additional_credentials") and _conf.additional_credentials:
            for group_name, cred_keys in _conf.additional_credentials.items():
                namespace = cred_keys.get("namespace", _conf.secret_namespace)
                client_id_key = cred_keys.get("client_id_key")
                client_secret_key = cred_keys.get("client_secret_key")
                re_pattern = cred_keys.get("re_pattern")

                if client_id_key and client_secret_key:
                    client_id = context.get_property(
                        namespace=namespace,
                        key=client_id_key,
                        optional=True,
                    )

                    client_secret = context.get_property(
                        namespace=namespace,
                        key=client_secret_key,
                        optional=True,
                    )

                    credentials[group_name] = {
                        "client_id": client_id,
                        "client_secret": client_secret,
                        "re_pattern": re_pattern,
                    }

        return credentials

    def enforce_correct_curve_dates(
        self,
        date_from: str,
        date_to: str,
        curve: Any,
        context: TaskContext,
    ) -> None:
        """Check the dates of the curve and adjust if necessary.

        Parameters:
        - date_from: Start date for data retrieval
        - date_to: End date for data retrieval
        - curve_name: Name of the curve
        - context: Task context for logging and other operations
        - curve: Curve object from the API
        """
        if not isinstance(curve.accessRange, dict):
            context.logger.warning(
                f"Curve {curve.name} does not have a valid access range. Using provided date range instead."
            )

        # No available date interval
        if curve.accessRange.get("empty", False) is True:
            context.logger.error(
                f"Curve {curve.name} has an empty access range response from API. "
                "Most likely due to lack of permissions to that curve."
            )

        curve_datefrom = datetime.datetime.fromisoformat(curve.accessRange["begin"])
        curve_datefrom = curve_datefrom.replace(tzinfo=None)
        date_datefrom = datetime.datetime.fromisoformat(date_from)
        if curve_datefrom > date_datefrom:
            context.logger.warning(
                f"Date from {date_from} for {curve.name} is before the curve date from {curve.accessRange['begin']}."
                f"Using curve date from instead."
            )
            date_from = curve.accessRange["begin"]
        if curve.accessRange["end"] is not None:
            curve_dateto = datetime.datetime.fromisoformat(curve.accessRange["end"])
            curve_dateto = curve_dateto.replace(tzinfo=None)
            date_dateto = datetime.datetime.fromisoformat(date_to)
            if curve_dateto < date_dateto:
                context.logger.warning(
                    f"Date to {date_to} for {curve.name} is after the curve date to {curve.accessRange['end']}. "
                    f"Using curve date to instead."
                )
                date_to = curve.accessRange["end"]

        return date_from, date_to

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Common execute block for all Volue calls."""
        _conf = self.start_task(context, conf)

        # Get all credential sets
        client_credentials = self.get_client_credentials(context, conf)

        df = self.run_main(
            client_credentials=client_credentials,
            api_get_params=_conf.api_get_params,
            context=context,
        )

        context.put_property(namespace=_conf.df_namespace, key=_conf.df_key, value=df)

        # Log the success
        context.logger.info(f"{self.task_name} has successfully run")


class VolueAbstractCurveApiBulkReaderTask(VolueAbstractApiReaderTask, ABC):
    """Task for reading from a given API.

    Attributes:
        task_name (str): The name of the task.
        api_url (str): Full API url.

    """

    @retry(stop=stop_after_attempt(5), wait=wait_exponential(multiplier=1, min=2, max=10))
    async def fetch_with_retry(
        self,
        client_id: str,
        client_secret: str,
        date_from: str,
        date_to: str | None,
        curve_name: str,
        context: TaskContext,
        tags: list[str] | None = None,
    ) -> CurveDataResult:
        """Asynchronously fetch curve data from the API with built-in retry logic.

        This method wraps the actual fetch operation with retry behavior using exponential backoff.
        It's used to make the task more resilient to transient API/network failures.

        Retries:
        - Up to 5 attempts on failure.
        - Waits exponentially between attempts (min: 2s, max: 10s).

        Args:
            client_id (str): API client ID for authentication.
            client_secret (str): API client secret for authentication.
            date_from (str): Start date for the data query (inclusive, format: YYYY-MM-DD).
            date_to (str | None): End date for the data query (inclusive, format: YYYY-MM-DD). Can be None.
            curve_name (str): Name of the curve to fetch data for.
            context (TaskContext): Context object for logging, Spark session, and task state.
            tags (list[str] | None): Optional list of tags for filtering the data.

        Returns:
            CurveDataResult: A structured result containing curve name and its corresponding data (e.g., DataFrame).

        Raises:
            Exception: If all retry attempts fail, the last exception is raised.
        """
        return await self.fetch_curve_data(
            client_id,
            client_secret,
            date_from,
            date_to,
            curve_name,
            context,
            tags,
        )

    @abstractmethod
    async def process_curve(
        self, date_from: str, date_to: str, curve_name: str, context: TaskContext, curve: Any, tags: str | None = None
    ) -> tuple[str, pd.Series] | tuple[str, str, pd.Series] | tuple[str, str, str, pd.Series]:
        """Overideable method that returns a tuple relating to the curve."""
        pass

    async def fetch_curve_data(
        self,
        client_id: str,
        client_secret: str,
        date_from: str,
        date_to: str,
        curve_name: str,
        context: TaskContext,
        tags: str | None = None,
    ) -> CurveDataResult:
        """Execute the fetch_curve_data.

        Retrieves curve name and pandas time series data from an API call.

        Parameters:
        - client_id: Client ID for authentication.
        - client_secret: Client secret for authentication.
        - date_from: Start date for data retrieval.
        - date_to: End date for data retrieval.
        - curve_name: Name of the curve to fetch.
        - context: Task context for logging and other operations.
        - tags: Optional tags to filter the curve data.

        Returns:
        Tuple containing the curve name and its corresponding time series data.
        """
        # Creating session based on client_id & client_secret
        session = vit.Session(client_id=client_id, client_secret=client_secret)

        # Getting a curve object asynchronously
        curve = await asyncio.to_thread(session.get_curve, name=curve_name)

        return await self.process_curve(date_from, date_to, curve_name, context, curve, tags)

    async def fetch_all_curve_data(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, str], context: TaskContext
    ) -> list[CurveDataResult]:
        """Asynchronously fetch all curve data in chunks, with optional per-chunk processing and writing.

        This function resolves a batch of curve requests from a previous orchestration step (via taskValues),
        performs concurrent API fetches using retry logic, and optionally writes results to storage
        chunk-by-chunk to optimize memory and performance.


        Args:
            client_credentials (dict[str, dict[str, str]]):
                Dictionary mapping credential group names to dicts with keys 'client_id' and 'client_secret'.
            api_get_params (dict[str, str]):
                Parameters passed from the orchestrator task (e.g., batch index, flags).
                Expected keys:
                    - 'batch_source_task': Task name where curve batches were stored
                    - 'target_index': Index of the batch to process (e.g., 'chunk_0')
                    - 'group_batch_key': Optional group key if fan-out logic was used
                    - 'write_per_chunk': 'true' or 'false' (default 'false')
                    - 'raise_on_failure': Optional; if 'true', raise fetch errors instead of logging them
            context (TaskContext):
                Task execution context with logger, Spark session, and utilities.

        Returns:
            list[CurveDataResult]:
                List of CurveDataResult objects (curve name and its data) only if write_per_chunk is False.
                Otherwise, returns an empty list after writing each chunk immediately to target sink.

        Raises:
            Exception: Any unrecoverable error during fetching or writing (unless suppressed by config).

        Notes:
            - API calls are limited to 10 concurrent requests (via semaphore).
            - Data is fetched and processed in batches of 20 curves.
            - Uses `process_results` to convert CurveDataResult objects into pandas DataFrames.
            - Uses Spark's `createDataFrame` to convert and write the processed data.
        """
        raise_on_failure = bool(api_get_params.get("raise_on_failure", False))
        chunk_size = int(api_get_params.get("chunk_size", 5))
        buffer_threshold = int(api_get_params.get("history_days_threshold", 365))
        write_per_chunk = api_get_params.get("write_per_chunk", "false").lower() == "true"

        source_task = api_get_params["batch_source_task"]
        group_batch_key = api_get_params.get("group_batch_key")
        current_index_raw = api_get_params.get("target_index")

        curve_batch = self._resolve_curve_batch(source_task, group_batch_key, current_index_raw, context)
        if not curve_batch:
            context.logger.warning("Curve batch is empty. Nothing to fetch.")
            return []

        chunk_size = self._determine_chunk_size(
            curve_batch, default=chunk_size, threshold_days=60, history_days_threshold=buffer_threshold
        )
        context.logger.info(f"Dynamic chunk_size selected: {chunk_size}")

        semaphore = asyncio.Semaphore(10)  # limit concurrent API calls

        total_curves = len(curve_batch)
        total_chunks = math.ceil(total_curves / chunk_size)

        all_results: list[CurveDataResult] = []

        for chunk_idx in range(total_chunks):
            start_idx = chunk_idx * chunk_size
            end_idx = min(start_idx + chunk_size, total_curves)
            chunk = curve_batch[start_idx:end_idx]

            context.logger.info(f"Processing chunk {chunk_idx + 1}/{total_chunks} with {len(chunk)} curves")

            tasks = [
                self._safe_fetch(curve, semaphore, client_credentials, context, raise_on_failure) for curve in chunk
            ]
            raw_results = await asyncio.gather(*tasks)

            # Filter valid results
            chunk_results = cast(list[CurveDataResult], [r for r in raw_results if r is not None])
            context.logger.info(f"Fetched {len(chunk_results)} results for chunk {chunk_idx + 1}")

            if write_per_chunk:
                try:
                    dfs = self.process_results(chunk_results, context)
                    context.logger.info(f"process_results returned {len(dfs)} DataFrames for chunk {chunk_idx + 1}")
                    combined_df = pd.concat([df for df in dfs if not df.empty], ignore_index=True)
                    if not combined_df.empty:
                        df_spark = context.spark.createDataFrame(combined_df)
                        self.process_df(df_spark, context, api_get_params)
                        del combined_df, df_spark, dfs
                    context.logger.info(f"Completed write for chunk {chunk_idx + 1}")
                except Exception as e:
                    context.logger.error(f"Failed to write chunk {chunk_idx + 1}: {e}")
            else:
                all_results.extend(chunk_results)

            gc.collect()

        return all_results if not write_per_chunk else []

    def _determine_chunk_size(
        self, curve_batch: list[dict], default: int, threshold_days: int, history_days_threshold: int
    ) -> int:
        """Decide chunk_size dynamically based on curve window lengths.

        Args:
            curve_batch (list[dict]): Curves with 'date_from' and 'date_to'.
            default (int): Default chunk size when curves are short.
            threshold_days (int): Window length threshold for historical loads.
            history_days_threshold (int): Days threshold to consider a curve as historical.

        Returns:
            int: Chunk size (smaller if large windows are detected).

        Notes:
            - If any curve has a window longer than `threshold_days`, returns 4.
            - Otherwise, returns the provided `default` chunk size.
        """
        today = datetime.date.today()
        for curve in curve_batch:
            try:
                date_from = datetime.datetime.strptime(curve.get("date_from"), "%Y-%m-%d")
                date_to = datetime.datetime.strptime(curve.get("date_to"), "%Y-%m-%d")
                # check per-batch window-size
                if (date_to - date_from).days > threshold_days:
                    return 4  # reduce if any curve exceeds threshold
                # 2. Check historical depth
                if date_from and (today - date_from).days > history_days_threshold:  # type: ignore
                    return 4
            except Exception:
                continue
        return default

    async def _safe_fetch(
        self,
        curve: dict,
        semaphore: asyncio.Semaphore,
        client_credentials: dict[str, dict[str, str]],
        context: TaskContext,
        raise_on_failure: bool,
    ) -> CurveDataResult | None:
        """Asynchronously fetch a single curve's data with controlled concurrency and error handling.

        This method wraps the actual fetch logic in a semaphore to limit the number of concurrent
        API calls. It delegates to `_fetch_curve_data_with_handling` to apply retry logic
        and optionally suppress errors based on configuration.

        Args:
            curve (dict): Dictionary containing curve details: 'curve', 'date_from', 'date_to', and optional 'tags'.
            semaphore (asyncio.Semaphore): Concurrency limiter to prevent API overload.
            client_credentials (dict[str, dict[str, str]]): Credential groups with 'client_id' and 'client_secret'.
            context (TaskContext): Task context for logging and Spark access.
            raise_on_failure (bool): Whether to raise exceptions for failed fetches (if False,will log and return None).

        Returns:
            CurveDataResult | None: The result of the API call, or None if it fails and raise_on_failure is False.

        """
        async with semaphore:
            return await self._fetch_curve_data_with_handling(curve, client_credentials, context, raise_on_failure)

    def _resolve_curve_batch(
        self, source_task: str, group_batch_key: str | None, current_index_raw: str | None, context: TaskContext
    ) -> list[dict[str, Any]]:
        """Resolve the appropriate batch of curves to process from task values.

        This method supports two modes:
            1. **Fan-out mode**: If `group_batch_key` is provided, retrieves a predefined group of batches.
            2. **Chunked mode**: If `group_batch_key` is not provided, uses `target_index` to select a specific chunk.

        Args:
            source_task (str): The task name that produced the curve batches.
            group_batch_key (str | None): Key pointing to a grouped set of curves (e.g., "group_0").
            current_index_raw (str | None): Index of the current chunk as a string (required if not using group key).
            context (TaskContext): Spark task context for accessing job values and logging.

        Returns:
            list[dict[str, Any]]: A list of curve batch dictionaries, each representing an individual fetch job.

        Raises:
            ValueError: If `current_index_raw` is None when chunked mode is required.
        """
        utils = get_dbutils(context.spark)
        if group_batch_key and group_batch_key != "group_batch_key":
            curve_batch = utils.jobs.taskValues.get(source_task, group_batch_key)  # type: ignore
            if curve_batch and isinstance(curve_batch[0], list):
                curve_batch = [item for sublist in curve_batch for item in sublist]
            context.logger.info(f"Using fan-out group batch: {group_batch_key} with {len(curve_batch)} curves.")
        else:
            if current_index_raw is None:
                raise ValueError("current_index_raw cannot be None")
            current_index = int(current_index_raw)
            num_batch_chunks = int(utils.jobs.taskValues.get(source_task, "num_batch_chunks"))  # type: ignore
            all_batches = []
            for i in range(num_batch_chunks):
                all_batches += utils.jobs.taskValues.get(source_task, f"chunk_{i}")  # type: ignore
            if current_index >= len(all_batches):
                context.logger.error(f"Invalid target_index {current_index}, only {len(all_batches)} batches exist.")
                return []
            curve_batch = all_batches[current_index]
            context.logger.info(f"Using chunked batch index: {current_index}, total curves: {len(curve_batch)}")

        return curve_batch

    async def _fetch_curve_data_with_handling(
        self,
        curve: dict,
        client_credentials: dict[str, dict[str, str]],
        context: TaskContext,
        raise_on_failure: bool = False,
    ) -> CurveDataResult | None:
        """Asynchronously fetch data for a single curve with error handling.

        This method:
        - Extracts required fields from the curve dictionary.
        - Resolves credentials based on curve name.
        - Calls `fetch_with_retry` to retrieve data.
        - Gracefully handles and logs failures (unless raise_on_failure is True).

        Args:
            curve (dict): Curve metadata containing at least `curve`, `date_from`, and optionally `date_to`, `tags`.
            client_credentials (dict): Mapping of credential groups with keys `client_id` and `client_secret`.
            context (TaskContext): Spark context for logging and utilities.
            raise_on_failure (bool, optional): If True, exceptions will be raised instead of suppressed. Defaults False.

        Returns:
            CurveDataResult | None: The fetched result if successful, or None if failed or invalid.
        """
        date_from = curve.get("date_from")
        curve_name = curve.get("curve")
        if not date_from or not curve_name:
            context.logger.warning(f"Invalid curve metadata: {curve}")
            return None

        try:
            creds = self._get_credentials_for_curve(curve_name, client_credentials)
            return await self.fetch_with_retry(
                creds["client_id"],
                creds["client_secret"],
                date_from,
                curve.get("date_to"),
                curve_name,
                context,
                curve.get("tags", None),
            )
        except Exception as e:
            context.logger.warning(f"Failed to fetch curve {curve_name}: {e}")
            if raise_on_failure:
                raise
            return None

    @abstractmethod
    def process_results(self, results: list[CurveDataResult], context: TaskContext | None = None) -> list:
        """Overridable method to process resulting dataframes into list."""
        pass

    async def main(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, str], context: TaskContext
    ) -> DataFrame | None:
        """Orchestrates the fetching, processing, and transformation of curve data into a Spark DataFrame.

        This is the main entry point for the task. It:
        - Fetches all required curve data (with chunking, batching, and optional per-chunk writes).
        - Optionally returns `None` if data was written during fetch time (`write_per_chunk` = true).
        - Otherwise processes all fetched results into Pandas and Spark DataFrames.
        - Applies any additional transformation logic via `process_df`.

        Args:
            client_credentials (dict): A mapping of credential groups, each containing `client_id` and `client_secret`.
            api_get_params (dict): Dictionary containing API runtime parameters including flags like `write_per_chunk`.
            context (TaskContext): Task context object for logging and Spark utilities.

        Returns:
            DataFrame | None: A transformed Spark DataFrame containing all fetched curve data, or None
                            if the data was already persisted during earlier steps.
        """
        results = await self.fetch_all_curve_data(client_credentials, api_get_params, context)

        write_per_chunk = api_get_params.get("write_per_chunk", "false").lower() == "true"
        if write_per_chunk:
            context.logger.info("Data was written per curve; returning None.")
            return None

        dfs = self.process_results(results, context)
        if not dfs:
            context.logger.warning("No DataFrames created from results. Returning an empty DataFrame.")
            return context.spark.createDataFrame([], "string")

        pd_df = pd.concat(dfs, ignore_index=True)
        raw_spark_df = context.spark.createDataFrame(pd_df)

        # Apply transformation using process_df
        return self.process_df(raw_spark_df, context, api_get_params)

    @abstractmethod
    def process_df(
        self, df: DataFrame, context: TaskContext | None, api_get_params: dict[str, str] | None
    ) -> DataFrame:
        """Overridable method to process resulting dataframes into list."""
        pass

    def run_main(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, str], context: TaskContext
    ) -> DataFrame:
        """Run the main asynchronous function from a synchronous context.

        This method ensures compatibility with synchronous task runners or orchestration tools
        that cannot await coroutines directly. It safely manages the asyncio event loop, runs
        the async main function, and returns a valid Spark DataFrame.

        Args:
            client_credentials (dict): A mapping of credential groups, each with `client_id` and `client_secret`.
            api_get_params (dict): Dictionary of API parameters, including write options and runtime config.
            context (TaskContext): The task context object providing logging and Spark access.

        Returns:
            DataFrame: A Spark DataFrame containing the processed curve data.
                    If no data is returned (e.g., write-per-curve is enabled), returns an empty DataFrame.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)

        df = loop.run_until_complete(self.main(client_credentials, api_get_params, context))

        # return a Spark DataFrame
        return df if df is not None else context.spark.createDataFrame([], "string")


class VolueCurveBatchTask(ETLTask):
    """Break up complex curves into some iterable chunks."""

    task_name = "VolueCurveBatchTask"
    dataclass = VolueCurveBatchConfig
    max_json_elements = 200

    def check_delta_or_full_load(
        self, context: TaskContext, conf: VolueCurveBatchConfig, curves_list: list, table_name: str
    ) -> pd.DataFrame:
        """This method is used to decide if a curve should be processed as a delta (recent updates) or as a full load.

        Determine the appropriate start date (`max_date`) for each curve, either from existing ingested data
        in the table or from config defaults.

        Behavior:
        - If `conf.ingested_dates_task` is defined, it pulls previously ingested curve dates from task context where
          the task : volue_curves_ingested_dates has already determined it. This helps to reduce the instances
          of multiple queries to same table by parallel tasks.
        - Otherwise, it queries the target Delta table to fetch latest ingested dates and subtracts a delta window.
        - Any curve not found in the existing records (either via task context/DB) will use config-provided from_date.

        Args:
            context (TaskContext): Spark context with access to the SQL engine.
            conf (VolueCurveBatchConfig): Configuration for data loading.
            curves_list (list): List of tuples .
            table_name (str): Name of the table to query.

        Returns:
            pd.DataFrame: DataFrame with columns ['curve_name', 'max_date'] where `max_date` is:
                      - (max(existing_date) - delta_window) if present in DB,
                      - or the `from_date` provided in config for new curves
        Extended logic:
        - Existing curve → (max(existing_date) - delta_window)
        - New curve →
            * If conf.full_load is True → use conf.from_date
            * Else → use today's date (incremental load from now)
            * Legacy fallback → config.from_date
        """
        params = getattr(conf, "curve_params", {}) or {}
        full_load = params.get("full_load", "false").lower() == "true"
        from_date_param = params.get("from_date")
        curves_filter = None
        if params.get("curves_list"):
            curves_filter = [c.strip() for c in params["curves_list"].split(",") if c.strip()]

        # Override: full_load requested
        if full_load and from_date_param:
            selected_curves = [c for c, _ in curves_list]
            if curves_filter:
                selected_curves = [c for c in selected_curves if c in curves_filter]

            return pd.DataFrame([{"curve_name": c, "max_date": from_date_param} for c in selected_curves])

        # Default existing behavior (delta / config from_date)
        if conf.ingested_dates_task:
            utils = get_dbutils(context.spark)
            date_from_dict = utils.jobs.taskValues.get(conf.ingested_dates_task, f"volue_ingested_{table_name.lower()}")  # type: ignore
            context.logger.info("Using curves from dates ingested task, skipping DB query.")
            date_from = (
                pd.DataFrame(date_from_dict) if date_from_dict else pd.DataFrame(columns=["curve_name", "max_date"])
            )
        else:
            full_table_name = f"{conf.target_catalog_name}.{conf.target_schema_name}.{table_name}"
            context.logger.info(f"Querying {full_table_name} for curves from dates.")

            date_from_query = f"""
                SELECT
                    CAST(date_sub(MAX({conf.delta_column}), {conf.delta_load_window_days}) AS DATE) max_date,
                    curve_name
                FROM {full_table_name}
                GROUP BY curve_name
            """
            date_from = context.spark.sql(date_from_query).toPandas()

        # Update max_date if later than today's date.
        today = datetime.date.today()
        delta_load_window_days = int(conf.delta_load_window_days) if conf.delta_load_window_days.isdigit() else 0
        date_from["max_date"] = pd.to_datetime(date_from["max_date"]).dt.date
        date_from_future = date_from["max_date"] >= today
        if date_from_future.any():
            adjusted_date = today - datetime.timedelta(days=delta_load_window_days)
            date_from.loc[date_from_future, "max_date"] = adjusted_date

        existing_curves = set(date_from["curve_name"])

        # For curves not yet seen in table → use yesterday (current_date - 1) instead of config.from_date
        new_rows = [
            {"max_date": datetime.date.today() - datetime.timedelta(days=1), "curve_name": curve_name}
            for curve_name, _ in curves_list
            if curve_name not in existing_curves
        ]

        if new_rows:
            new_df = pd.DataFrame(new_rows)
            date_from = pd.concat([date_from, new_df], ignore_index=True)

        return date_from

    def _split_into_date_batches(
        self,
        date_from: datetime.datetime,
        date_to: datetime.datetime,
        batch_size: int,
        tags: str | None = None,
    ) -> list[dict]:
        """Split a date range into batches of at most batch_size days."""
        batches: list[dict] = []
        start = date_from
        step = datetime.timedelta(days=(batch_size - 1))

        while start < date_to:
            batch_date_from = start.strftime("%Y-%m-%d")
            start += step
            if start > date_to:
                start = date_to
            batch_date_to = start.strftime("%Y-%m-%d")

            batch = {"date_from": batch_date_from, "date_to": batch_date_to}
            if tags:
                batch["tags"] = tags
            batches.append(batch)

        return batches

    def calculate_curve_date_batches(
        self, context: TaskContext, conf: VolueCurveBatchConfig, curves_list: list, table_name: str
    ) -> dict:
        """Return a list of date batch windows depending on the parameters the task is configured with.

        This function uses the result of `check_delta_or_full_load` to determine the start date
        for each curve. It then splits the time range (from `date_from` to a fixed future `date_to`)
        into batches of size `maximum_days_per_batch`.

        Forecast padding is applied by extending `date_to` to (today + 30 days) to ensure
        future data (e.g., forecasts) is included in the batch windows.

        Args:
            context (TaskContext): Spark context for logging and utilities.
            conf (VolueCurveBatchConfig): Config object containing batching parameters.
            curves_list (list): List of tuples (curve_name, config_dict) with optional 'tags' inside config_dict.
            table_name (str): Target table name (used to determine previously ingested dates).

        Returns:
            dict: A dictionary where keys are curve names and values are lists of batch dictionaries,
                each containing:
                - 'date_from': str (YYYY-MM-DD)
                - 'date_to': str (YYYY-MM-DD)
                - 'tags': Optional[str or list], passed through if available in config.
        Extended behavior:
        - If conf.curve_params.full_load is True → override with curve_params.from_date/curve_params.to_date,
            optionally restricted to curve_params.curves_list.
        - Otherwise Legacy behavior (no curve_params):
            - Existing curves → delta from DB max_date
            - New curves → incremental load from today.
        """
        params = getattr(conf, "curve_params", {}) or {}
        full_load = params.get("full_load", "false").lower() == "true"
        from_date_param = params.get("from_date")
        to_date_param = params.get("to_date")
        curves_filter = None
        if params.get("curves_list"):
            curves_filter = [c.strip() for c in params["curves_list"].split(",") if c.strip()]

        batch_size = int(conf.maximum_days_per_batch)
        date_batches: dict = {}
        # Full-load override path
        if full_load and from_date_param and to_date_param:
            date_from = datetime.datetime.strptime(from_date_param, "%Y-%m-%d")
            date_to = datetime.datetime.strptime(to_date_param, "%Y-%m-%d")
            end = date_to

            # Apply curves_list filter if provided
            curve_names = [c for c, _ in curves_list]
            if curves_filter:
                curve_names = [c for c in curve_names if c in curves_filter]

            for curve_name in curve_names:
                # retrieve tags if present
                context.logger.info(f"About to process {curve_name} from {date_from} to {date_to}")
                config_date_from: dict = next((cfg for c, cfg in curves_list if c == curve_name), {})
                tags = config_date_from.get("tags", None)

                date_batches[curve_name] = self._split_into_date_batches(date_from, date_to, batch_size, tags)
            return date_batches

        # Determine how many days to look forward ("date_to_delta_days")
        # based on the table type or the delta column being used:
        # - time_series_n: 730 days (2 years) for normal curves with longer forecast horizons
        # - issued_at delta_column: 0 days (no forward-looking dates)
        # - default: 30 days for standard time series
        match (table_name, conf.delta_column):
            case ("time_series_n", _):
                date_to_delta_days = 730
            case (_, "issued_at"):
                date_to_delta_days = 0
            case _:
                date_to_delta_days = 30

        date_to = datetime.date.today() + datetime.timedelta(days=date_to_delta_days)  # type: ignore
        end = datetime.datetime.strptime(str(date_to), "%Y-%m-%d")

        # Get start dates per curve (from DB or new rows)
        curve_from_dates = self.check_delta_or_full_load(context, conf, curves_list, table_name)
        context.logger.warning("Curves from dates to load have been identified")

        for curve_name, config_date_from in curves_list:
            # Apply curves_list filter if provided
            if curves_filter and curve_name not in curves_filter:
                continue

            # get start date for this curve
            date_from = curve_from_dates[curve_from_dates["curve_name"] == curve_name]["max_date"].iloc[0]
            tags = config_date_from.get("tags", None)
            context.logger.info(f"About to process {curve_name} from {date_from} to {date_to}")

            start = datetime.datetime.strptime(str(date_from), "%Y-%m-%d")
            date_batches[curve_name] = self._split_into_date_batches(start, end, batch_size, tags)

        return date_batches

    def split_array(self, arr: list, n: int) -> list:
        """Split JSON array into smaller arrays which won't exceed task 48K limit."""
        # Calculate the size of each chunk
        return [arr[i : i + n] for i in range(0, len(arr), n)]

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Common execute block for all Volue calls.

        Execute the Volue data loading pipeline by batching curve requests and organizing them
        based on curve type and configuration (tagged or standard).

        This method performs the following:
        - Loads curve configuration from the input file.
        - Filters curves by prefix if applicable.
        - Splits curves into date batches using either full-load or delta-load logic.
        - Groups batches per `items_per_batch` setting.
        - Handles two different batching models:
            1. **Fan-Out Mode** (for tagged instances):
            - If table name contains 'tagged_instances':
                - Curves with prefix "pro" or "tt" → split into **3 groups**.
                - All others → single group.
            - Each group is saved as `group_0`, `group_1`, etc. with `num_groups` metadata.
            2. **Standard Mode** (for timeseries or normal curves):
            - Batches are randomized (if enabled) and then chunked based on JSON size constraints.
            - Saved as `chunk_0`, `chunk_1`, etc. with `num_batch_chunks` metadata.

        """
        _conf = self.start_task(context, conf)

        curve_file = _conf.curve_file
        items_per_batch = int(_conf.items_per_batch)

        prefix_curve_filter = getattr(_conf, "prefix_curve_filter", None)

        utils = get_dbutils(context.spark)

        data = load_curve_file_and_expand(curve_file)

        batched_curves = []
        batch_indexes = []
        batch_table_names = []
        index = 0

        if not data:
            context.logger.warning("No curve data loaded. Exiting execute early.")
            utils.jobs.taskValues.set("batch_indexes", [])  # type: ignore
            utils.jobs.taskValues.set("num_batch_chunks", 0)  # type: ignore
            return

        for table in data:
            # For each table in configuration file
            if not table:
                context.logger.warning("Encountered an empty table, skipping.")
                continue
            table_name = next(iter(table.keys()))
            curves = table[table_name]  # Get the dictionary of curves
            if prefix_curve_filter:
                context.logger.warning(f"Prefix curve filter applied: {prefix_curve_filter}")
                curves = {curve: value for curve, value in curves.items() if curve.startswith(prefix_curve_filter)}
            context.logger.info(f"Processing table {table_name}")
            current_batch_count = 0
            current_batch = []
            # Load date_from for all curves in this table
            date_batches = self.calculate_curve_date_batches(context, _conf, list(curves.items()), table_name)
            context.logger.warning("curves date batches been found")
            for curve_name in date_batches.keys():
                for date_batch in date_batches[curve_name]:
                    # for each curve in current table
                    context.logger.info(f"Processing curve name {curve_name}")
                    current_batch_count += 1
                    item = {}
                    item["curve"] = curve_name
                    item = item | date_batch
                    current_batch.append(item)
                    if current_batch_count == items_per_batch:
                        context.logger.info("Batch produced pushing to return object")
                        batch_indexes.append({"t": table_name, "i": str(index)})
                        batch_table_names.append(table_name)
                        index += 1
                        batched_curves.append(current_batch)
                        current_batch_count = 0
                        current_batch = []
            if current_batch_count > 0:
                context.logger.info("End of curves for table pushing current batch to return object")
                batch_indexes.append({"t": table_name, "i": str(index)})
                batch_table_names.append(table_name)
                index += 1
                batched_curves.append(current_batch)

        if any(keyword in table_name.lower() for keyword in ["tagged_instances", "instances_f"]):
            # prefix_curve_filter in ("pro", "tt"):
            context.logger.info("Fan-out mode activated")
            total_batches = len(batched_curves)

            if total_batches == 0:
                num_groups = 3
                context.logger.warning("No batches to process. Skipping fan-out logic.")
                utils.jobs.taskValues.set("num_groups", 0)  # type: ignore
                for i in range(num_groups):
                    utils.jobs.taskValues.set(f"group_{i}", [])  # type: ignore
                return

            # Adjust number of groups based on available data
            num_groups = 3 if prefix_curve_filter in ("pro", "tt") and "tagged_instances" in table_name.lower() else 1

            # Divide entire batched_curves into N groups
            grouped_batches = self.split_array(batched_curves, math.ceil(total_batches / num_groups))

            for i in range(num_groups):
                if i < len(grouped_batches):
                    group = grouped_batches[i]
                    context.logger.info(f"Creating group_{i} with {len(group)} curves")
                    utils.jobs.taskValues.set(f"group_{i}", group)  # type: ignore
                else:
                    context.logger.warning(f"No data for group_{i}, setting empty list")
                    utils.jobs.taskValues.set(f"group_{i}", [])  # type: ignore

            utils.jobs.taskValues.set("num_groups", num_groups)  # type: ignore

        else:
            # helps avoids partition conflicts if loading multiple time windows against same curve
            if _conf.randomise_batches:
                random.shuffle(batched_curves)
            context.logger.info(batched_curves)

            utils.jobs.taskValues.set("batch_indexes", batch_indexes)  # type: ignore
            # Use math.ceil to ensure the chunk size is large enough to include all
            split_batched_curves = self.split_array(batched_curves, math.ceil(self.max_json_elements / items_per_batch))
            context.logger.info(f"splitted batch curves {len(split_batched_curves)}")
            utils.jobs.taskValues.set("num_batch_chunks", len(split_batched_curves))  # type: ignore
            for index, array in enumerate(split_batched_curves):
                utils.jobs.taskValues.set("chunk_" + str(index), array)  # type: ignore

        # Log the success
        context.logger.info(f"{self.task_name} has successfully run")


class VolueApiMetadataBulkReaderTask(VolueAbstractApiReaderTask):
    """Task for reading metadata attributes from the Volue API."""

    task_name = "VolueApiMetadataBulkReaderTask"

    def run_main(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, Any], context: Any
    ) -> DataFrame:
        """Entrypoint for synchronous task execution.

        Parameters:
            client_credentials (Dict[str, Dict[str, str]]): Client credentials grouped by identifier.
            api_get_params (Dict[str, Any]): Parameters for the API call.
            context (Any): Context object for logging and Spark session.

        Returns:
            DataFrame: Spark DataFrame containing curve metadata.
        """
        return self._fetch_and_prepare_data(client_credentials, api_get_params, context)

    def _fetch_and_prepare_data(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, Any], context: Any
    ) -> DataFrame:
        """Fetches data and converts it into a Spark DataFrame.

        Parameters:
            client_credentials (Dict[str, Dict[str, str]]): Client credentials grouped by identifier.
            api_get_params (Dict[str, Any]): Parameters for the API call.
            context (Any): Context object for logging and Spark session.

        Returns:
            DataFrame: Spark DataFrame containing curve metadata.
        """
        curves = self._fetch_all_curve_metadata(client_credentials, api_get_params, context)
        rows = [self._transform_curve_to_row(curve, context) for curve in curves]
        schema = self._define_schema()
        return context.spark.createDataFrame(rows, schema=schema)

    def _fetch_all_curve_metadata(
        self, client_credentials: dict[str, dict[str, str]], api_get_params: dict[str, Any], context: Any
    ) -> list[Any]:
        """Fetches metadata for all curves from Volue API.

        Parameters:
            client_credentials (Dict[str, Dict[str, str]]): Client credentials grouped by identifier.
            api_get_params (Dict[str, Any]): Parameters for the API call.
            context (Any): Context object for logging.

        Returns:
            List[Any]: List of curve metadata objects.
        """
        curves_list = self._load_curve_names(api_get_params)
        grouped_curves = self._group_curves_by_credentials(curves_list, client_credentials)

        all_metadata = []
        for credentials, curve_chunk in self._generate_chunks(grouped_curves):
            context.logger.info(f"Fetching metadata chunk: {curve_chunk}")
            metadata_chunk = self._fetch_curve_metadata_chunk(credentials, curve_chunk)
            all_metadata.extend(metadata_chunk)

        return all_metadata

    def _fetch_curve_metadata_chunk(self, credentials: dict[str, str], curve_chunk: list[str]) -> list[Any]:
        """Fetch metadata for a single chunk of curves.

        Parameters:
            credentials (Dict[str, str]): Credentials for Volue API.
            curve_chunk (List[str]): List of curve names to fetch.
            context (Any): Context object for logging.

        Returns:
            List[Any]: List of curve metadata objects.
        """
        session = vit.Session(client_id=credentials["client_id"], client_secret=credentials["client_secret"])
        return session.search(name=curve_chunk)

    def _load_curve_names(self, api_get_params: dict[str, Any]) -> list[str]:
        """Loads curve names from configuration.

        Parameters:
            api_get_params (Dict[str, Any]): Parameters containing the path to configuration.

        Returns:
            List[str]: List of curve names.
        """
        data = load_curve_file_and_expand(api_get_params["config_path"])
        curve_names = []
        for table in data:
            # For each table in configuration file
            table_name = next(iter(table.keys()))
            curves = table[table_name]  # Get the dictionary of curves
            curve_names.extend(curves.keys())
        return curve_names

    def _group_curves_by_credentials(
        self, curves_list: list[str], client_credentials: dict[str, dict[str, str]]
    ) -> dict[str, dict[str, Any]]:
        """Groups curves by the credentials needed to fetch their metadata.

        Parameters:
            curves_list (List[str]): List of curve names.
            client_credentials (Dict[str, Dict[str, str]]): Client credentials grouped by identifier.

        Returns:
            Dict[str, Dict[str, Any]]: Dictionary of curves grouped by client credentials.
        """
        grouped = {}
        for curve_name in curves_list:
            creds = self._get_credentials_for_curve(curve_name, client_credentials)
            client_id = creds["client_id"]
            grouped.setdefault(client_id, {"credentials": creds, "curves": []})["curves"].append(curve_name)
        return grouped

    def _generate_chunks(
        self, grouped_curves: dict[str, dict[str, Any]], chunk_size: int = 50
    ) -> Generator[tuple[dict[str, str], list[str]], None, None]:
        """Generates chunks of curves respecting API limits.

        Parameters:
            grouped_curves (Dict[str, Dict[str, Any]]): Dictionary of curves grouped by client credentials.
            chunk_size (int, optional): Maximum number of curves per chunk. Defaults to 50.

        Yields:
            Generator: Tuple containing credentials and a chunk of curve names.
        """
        for group in grouped_curves.values():
            credentials = group["credentials"]
            curves = group["curves"]
            for i in range(0, len(curves), chunk_size):
                yield credentials, curves[i : i + chunk_size]

    def _transform_curve_to_row(self, curve: Any, context: Any) -> Row:
        """Transforms a single curve metadata object into a Spark Row."""

        def safe_to_timestamp(value: str) -> Any:
            try:
                return isoparse(value) if value else None
            except Exception as e:
                context.logger.error(f"Timestamp parsing error for value '{value}': {e}")
                return None

        attributes = {
            "id": curve.id,
            "name": curve.name,
            "frequency": curve.frequency,
            "time_zone": curve.time_zone,
            "curve_type": curve.curve_type,
            "curve_state": curve.curve_state,
            "created": safe_to_timestamp(curve.created),
            "modified": safe_to_timestamp(curve.modified),
            "area": curve.area,
            "categories": curve.categories,
            "commodity": curve.commodity,
            "unit": curve.unit,
            "has_access": curve.hasAccess,
            "access_range_begin": safe_to_timestamp(curve.accessRange.get("begin")) if curve.accessRange else None,
            "access_range_end": safe_to_timestamp(curve.accessRange.get("end")) if curve.accessRange else None,
            "data_type": curve.data_type,
            "description": curve.description,
        }

        row = Row(**attributes)
        return row

    def _define_schema(self) -> StructType:
        """Defines the Spark schema for curve metadata DataFrame.

        Returns:
            StructType schema definition.
        """
        return StructType(
            [
                StructField("id", IntegerType(), True),
                StructField("name", StringType(), True),
                StructField("frequency", StringType(), True),
                StructField("time_zone", StringType(), True),
                StructField("curve_type", StringType(), True),
                StructField("curve_state", StringType(), True),
                StructField("created", TimestampType(), True),
                StructField("modified", TimestampType(), True),
                StructField("area", StringType(), True),
                StructField("categories", ArrayType(StringType()), True),
                StructField("commodity", StringType(), True),
                StructField("unit", StringType(), True),
                StructField("has_access", StringType(), True),
                StructField("access_range_begin", TimestampType(), True),
                StructField("access_range_end", TimestampType(), True),
                StructField("data_type", StringType(), True),
                StructField("description", StringType(), True),
            ]
        )
