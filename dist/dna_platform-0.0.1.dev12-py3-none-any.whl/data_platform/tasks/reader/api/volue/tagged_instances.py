# CPD-OFF - ignore imports
import asyncio
from typing import Any

import nest_asyncio  # type: ignore
import pandas as pd
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as f

from data_platform.etl.transform.transform import convert_columns_type
from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.volue.volue import VolueAbstractCurveApiBulkReaderTask

# CPD-ON - ignore imports

nest_asyncio.apply()  # type: ignore


def get_spark_session() -> SparkSession:
    """Get the Spark session."""
    return SparkSession.builder.getOrCreate()


class VolueTaggedInstancesApiBulkReaderWriterTask(VolueAbstractCurveApiBulkReaderTask):
    """Task for reading tagged-instance curves from the Volue API.

    The method performs the following steps:
        1. Adjusts the requested date range to valid boundaries using `enforce_correct_curve_dates`.
        2. Searches available instances metadata (without data) between the date range.
        3. Filters the instances by the provided tags (if any). If no tags provided, all instance tags are included.
        4. Concurrently fetches the full time series data for each matching tagged instance.
        5. Returns a list of tuples containing (curve_name, issue_date, tag, ts_data) for each fetched instance.

    Args:
        date_from (str): Start date for fetching instances (ISO format YYYY-MM-DD).
        date_to (str): End date for fetching instances (ISO format YYYY-MM-DD).
        curve_name (str): The name of the curve to fetch.
        context (TaskContext): Context providing logging and Spark session.
        curve (Any): Curve object providing `search_instances` and `get_instance` methods.
        tags (str | None, optional): Comma-separated string of tags to filter instances. If None, fetches all tags.

    Returns:
        List[Tuple[str, str, str, pd.Series]]: A list of tuples, each containing:
            - curve_name (str)
            - issue_date (str)
            - tag (str)
            - time series data as a Pandas Series
    """

    task_name = "VolueTaggedInstancesApiBulkReaderWriterTask"

    # CPD-OFF - ignore multiline method signature across implementations
    async def process_curve(
        self,
        date_from: str,
        date_to: str,
        curve_name: str,
        context: TaskContext,
        curve: Any,
        tags: str | None = None,
    ) -> list[tuple[str, str, str, pd.Series]]:
        # CPD-ON - ignore multiline method signature across implementations
        """Return a list of ``(curve_name, issue_date, tag, ts_data)`` tuples for the given curve."""
        # 1️⃣ Correct dates if needed
        date_from, date_to = self.enforce_correct_curve_dates(
            date_from=date_from,
            date_to=date_to,
            curve=curve,
            context=context,
        )

        # 2️⃣ Search for available instances (metadata only)
        search_params = {
            "issue_date_from": date_from,
            "issue_date_to": date_to,
            "with_data": "false",
        }
        context.logger.info(f"curve_name={curve_name} | search params={search_params}")
        ts_list = await asyncio.to_thread(curve.search_instances, **search_params)

        # 3️⃣ Tag filtering
        if not tags:
            tags = [ts.tag for ts in ts_list if ts.tag]

        wanted_tags = {cleaned for raw in tags if raw and (cleaned := raw.strip())}
        ts_list = [ts for ts in ts_list if ts.tag in wanted_tags]

        context.logger.info(f"curve_name={curve_name} | {len(ts_list)} instance(s) left after tag filter {wanted_tags}")
        if not ts_list:
            context.logger.warning(f"curve_name={curve_name} | no instances match tags={wanted_tags}")
            return []

        # 4️⃣ Helper to fetch one tagged instance
        async def get_tagged_instance(ts_metadata: Any) -> tuple[str, str, str, pd.Series]:
            api_params = {
                "issue_date": ts_metadata.issue_date,
                "tag": ts_metadata.tag,
            }
            ts_data = await asyncio.to_thread(curve.get_instance, **api_params)
            context.logger.info(f"Fetched {curve_name}-{ts_data.issue_date}-{ts_data.tag}")
            return curve_name, ts_data.issue_date, ts_data.tag, ts_data

        # 5️⃣ Concurrently fetch all instances
        return await asyncio.gather(*[get_tagged_instance(ts) for ts in ts_list])

    # CPD-OFF - ignore multiline method signature across implementations
    def process_results(self, results: list[Any], context: TaskContext) -> list[pd.DataFrame]:  # type: ignore[override]
        """Convert the raw instance data into a list of Pandas DataFrames.

        Each element in `results` is expected to be a list of tuples representing forecasts for a single curve.
        Each tuple should contain:
            (curve_name: str, issued_at: str, tag: str, series: pd.Series)

        The function:
            - Validates the tuple format.
            - Converts the time series into a DataFrame with columns:
                ['value_at', 'value', 'curve_name', 'issued_at', 'tag'].
            - Combines all forecasts per curve into a single DataFrame.
            - Collects DataFrames per curve into a list and returns it.

        Args:
            results (list[Any]): List of curves, where each curve is a list of forecast tuples.
            context (TaskContext | None): Task context for logging.

        Returns:
            list[pandas.DataFrame]: List of DataFrames, one per curve.
        """
        context.logger.info(f"Received results with {len(results)} curves")

        dfs: list[pd.DataFrame] = []

        for curve_idx, curve in enumerate(results):
            curve_dfs: list[pd.DataFrame] = []
            for forecast_idx, forecast in enumerate(curve):
                if not isinstance(forecast, tuple) or len(forecast) != 4:
                    context.logger.warning(
                        f"Unexpected forecast format at curve {curve_idx}, forecast {forecast_idx}: {forecast}"
                    )
                    continue

                curve_name, issued_at, tag, series = forecast
                try:
                    df = (
                        series.to_pandas()
                        .to_frame(name="value")
                        .reset_index()  # index becomes 'value_at'
                        .assign(curve_name=curve_name, issued_at=issued_at, tag=tag)
                    )
                    df.columns = ["value_at", "value", "curve_name", "issued_at", "tag"]
                    curve_dfs.append(df)
                except Exception as e:
                    context.logger.warning(
                        f"Failed to process forecast at curve {curve_idx}, forecast {forecast_idx}: {e}"
                    )

            if curve_dfs:
                dfs.append(pd.concat(curve_dfs, ignore_index=True))

        return dfs

    def process_df(
        self, df: DataFrame, context: TaskContext | None, api_get_params: dict[str, str] | None
    ) -> DataFrame:
        """Final Spark-side column selection/ordering.

        Args:
            df (DataFrame): Input Spark DataFrame with curve data.
            context (TaskContext | None): Context object with logger.
            api_get_params (dict[str, str] | None): Parameters including catalog/schema/table.
            spark (SparkSession): Spark session used for DataFrame operations.

        Returns:
            DataFrame: An empty DataFrame if written to table, else the processed DataFrame.
        """
        spark = get_spark_session()
        if not context:
            raise ValueError("Context cannot be None when processing DataFrame.")

        df = df.select(
            f.col("tag"),
            f.col("issued_at"),
            f.col("curve_name"),
            f.col("value_at"),
            f.col("value"),
        )

        df = convert_columns_type(df=df, logger=context.logger, input_col="issued_at", col_type="timestamp")

        target_table = (
            f"{api_get_params['catalog_name']}.{api_get_params['schema_name']}.{api_get_params['table']}"
            if api_get_params and all(api_get_params.get(key) for key in ["catalog_name", "schema_name", "table"])
            else None
        )

        if target_table:
            df.write.mode("append").saveAsTable(target_table)
            context.logger.warning(f"Data written into table: {target_table}")
            del df  # To free up memory
            return spark.createDataFrame([], "string")

        context.logger.warning("Target table is not specified. Skipping saveAsTable operation.")
        return df
