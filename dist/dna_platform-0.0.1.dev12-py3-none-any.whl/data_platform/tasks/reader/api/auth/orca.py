from typing import cast

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.auth.basic import BasicOauthTask
from data_platform.tasks.reader.api.auth.config.dataclasses import BaseOauthConfig, OrcaOauthConfig


class OrcaOauthTask(BasicOauthTask):
    """Task for retrieving OAuth2 tokens using secrets from task context for Basic authentication.

    Attributes:
        task_name (str): Name of the task.
        dataclass (Type[AzureOauthConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the AzureOauthTask by using secrets stored in the task context to get an OAuth2 token.
    """

    task_name = "OrcaOauthTask"
    verify = True

    def __init__(self) -> None:
        """Set dataclass."""
        self.dataclass = OrcaOauthConfig

    def prepare_oauth_body(self, context: TaskContext, conf: BaseOauthConfig) -> dict | str:
        """Prepare Orca Oauth Token Request."""
        conf = cast(OrcaOauthConfig, conf)
        # Retrieve secrets from the task context
        username = context.get_property(conf.namespace, conf.username_key)
        password = context.get_property(conf.namespace, conf.password_key)
        # Prepare data for token request
        body = {"grant_type": conf.granttype_key, "client_id": username, "client_secret": password}
        context.logger.info("done body")
        return body

    def prepare_http_headers(self, context: TaskContext, conf: BaseOauthConfig) -> dict | None:
        """Orca sends no additional headers on it's requests."""
        return None
