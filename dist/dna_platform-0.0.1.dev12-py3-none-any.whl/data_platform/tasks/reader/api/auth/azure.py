from typing import cast

from data_platform.tasks.core import TaskContext
from data_platform.tasks.reader.api.auth.basic import BasicOauthTask
from data_platform.tasks.reader.api.auth.config.dataclasses import BaseOauthConfig
from data_platform.tasks.reader.api.config.dataclasses import AzureOauthConfig


class AzureOauthTask(BasicOauthTask):
    """Task for retrieving OAuth2 tokens using secrets from task context for Azure Entra authentication.

    Attributes:
        task_name (str): Name of the task.
        dataclass (Type[AzureOauthConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the AzureOauthTask by using secrets stored in the task context to get an OAuth2 token.
    """

    task_name = "AzureOauthTask"
    verify = True

    def __init__(self) -> None:
        """Set dataclass."""
        self.dataclass = AzureOauthConfig

    def prepare_oauth_body(self, context: TaskContext, conf: BaseOauthConfig) -> dict | str:
        """Prepare Oauth request for Azure."""
        conf = cast(AzureOauthConfig, conf)
        # Retrieve secrets from the task context
        client_id = context.get_property(conf.namespace, conf.client_id_key)
        client_secret = context.get_property(conf.namespace, conf.client_secret_key)
        tenant_id = context.get_property(conf.namespace, conf.tenant_id_key)
        api_scope = context.get_property(conf.namespace, conf.api_scope_key)

        # Ensure all required secrets are available
        if not all([client_id, client_secret, tenant_id, api_scope]):
            raise ValueError(
                "Missing required secrets in the task context. \
                             Ensure 'client-id', 'client-secret', api-scope, and 'tenant-id' are available."
            )

        # Prepare data for token request
        body = {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": api_scope,
        }

        return body

    def get_url(self, context: TaskContext, conf: BaseOauthConfig) -> str:
        """Hardcoded return."""
        conf = cast(AzureOauthConfig, conf)
        tenant_id = context.get_property(conf.namespace, conf.tenant_id_key)
        return f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"

    def prepare_http_headers(self, context: TaskContext, conf: BaseOauthConfig) -> dict | None:
        """Hardcoded return."""
        return {"Content-Type": "application/x-www-form-urlencoded"}

    def get_auth_token_name(self, context: TaskContext, conf: BaseOauthConfig) -> str:
        """Hardcoded return."""
        return "access_token"
