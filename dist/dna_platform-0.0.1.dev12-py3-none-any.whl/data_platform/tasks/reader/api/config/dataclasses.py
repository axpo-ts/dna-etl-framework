from dataclasses import dataclass, field

from data_platform.tasks.reader.api.auth.config.dataclasses import BaseOauthConfig


@dataclass(kw_only=True)
class BaseApiReaderConfig:
    """Configuration class for ApiReaderTasks.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        task_name (str): The name of the task.
        df_key (str): The key to use for storing the DataFrame in the task context.
        df_namespace (str): The namespace to use for storing the DataFrame in the task context.
        api_url (str): Full API url
        secret_namespace (str, optional): The namespace in which the secret is stored in the task context.

    """

    task_name: str
    df_key: str
    df_namespace: str
    api_url: str
    return_content_type: str = "text"
    secret_namespace: str = ""
    volume_storage_path: str = ""
    file_format: str = ""


@dataclass(kw_only=True)
class ApiReaderConfig(BaseApiReaderConfig):
    """Configuration class for ApiReaderTasks.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        schema (str, optional): Optional option to provide string schema to use on read
        additional_credentials (dict): Defines additional credential sets by group name
    """

    secret_token: str = ""
    secret_client_id: str = ""
    secret_client_secret: str = ""
    schema: str | None = None
    api_data_filter_params: dict[str, str] = field(default_factory=dict)
    api_get_params: dict[str, str] = field(default_factory=dict)
    additional_credentials: dict[str, dict] = field(default_factory=dict)


@dataclass(kw_only=True)
class ApiEndpointConfig:
    """Common configuration for API endpoints.

    Attributes:
        api_name (str) : name used to call the API data endpoint
        api_method (str) : method used to call the API data endpoint ('GET' or 'POST')
        api_parameters (str) : the parameters used to call the API data endpoint
        api_url_sql (str) : SQL query for API URL construction
        api_time_window(dict) : provide parameters to download API data only in a specific window
    """

    api_name: str | None = None
    api_method: str | None = None
    api_parameters: dict | None = None
    api_url_sql: str | None = None
    api_time_window: dict[str, str] = field(default_factory=dict)


@dataclass(kw_only=True)
class BearerApiReaderConfig(BaseApiReaderConfig, ApiEndpointConfig):
    """Configuration class for ApiReaderTasks.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        access_token_key (str): key used to store the API access token
    """

    access_token_key: str


@dataclass(kw_only=True)
class AzureOauthConfig(BaseOauthConfig):
    """Configuration class for AzureOauthTask.

    Attributes:
        api_scope_key (str): The API scope key required for the access token from Task Context.
        tenant_id_key (str): The tenant ID key required for the access token from Task Context.
        client_id_key (str): The client ID key required for the access token from Task Context.
        client_secret_key (str): The client secret key required for the access token from Task Context.
    """

    tenant_id_key: str
    client_id_key: str
    client_secret_key: str
    api_scope_key: str


@dataclass(kw_only=True)
class VolumeApiReaderConfig(BearerApiReaderConfig):
    """Configuration class for VolumeApiReaderConfig.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        task_name (str): The name of the task.
        df_key (str): The key to use for storing the DataFrame in the task context.
        df_namespace (str): The namespace to use for storing the DataFrame in the task context.
        api_url (str): Full API url
        volume_storage_path (str): Path to the volume storage
    """

    volume_storage_path: str


@dataclass(kw_only=True)
class PythonicApiReaderConfig:
    """Configuration class for PythonicApiReaderConfig.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        api_url (str): Full API url
        api_method (str) : method used to call the API data endpoint ('GET' or 'POST')
        api_parameters (str) : the parameters used to call the API data endpoint
        volume_storage_path (str): Path to the volume storage
    """

    api_url: str
    api_method: str | None = None
    api_parameters: dict | None = None
    volume_storage_path: str


@dataclass(kw_only=True)
class BasicAuthApiReaderConfig(BaseApiReaderConfig, ApiEndpointConfig):
    """Configuration class for BasicAuthApiReaderConfig.

    Attributes:
        username_key (str): Key to retrieve username from task context secrets
        password_key (str): Key to retrieve password from task context secrets
    """

    username_key: str = "username"
    password_key: str = "password"


@dataclass(kw_only=True)
class EliaApiReaderConfig(BaseApiReaderConfig):
    """Configuration class for EliaApiReaderConfig.

    The configuration is declared in a YAML file and is unique to each table.

    Attributes:
        api_method (str) : method used to call the API data endpoint ('GET' or 'POST')
        api_parameters (str) : the parameters used to call the API data endpoint
        file_format (str): The format of the file to be processed (e.g., 'json', 'csv').
        df_key (str, optional): The key used to identify the data frame. Defaults to an empty string.
        df_namespace (str, optional): The namespace associated with the data frame. Defaults to an empty string.
    """

    api_method: str
    api_parameters: dict
    return_content_type: str = "content"
    df_key: str = ""
    df_namespace: str = ""
