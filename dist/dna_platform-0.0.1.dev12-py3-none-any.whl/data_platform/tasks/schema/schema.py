from pyspark.sql import DataFrame

from data_platform import constants
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.schema.config.dataclasses import CreateSchemaCommentsConfig, CreateSchemaConfig


class CreateSchemaTask(ETLTask):
    """Task for creating a schema in the data lake.

    Args:
        ETLTask (class): Abstract base class for ETL (Extract, Transform, Load) tasks.
    """

    task_name: str = "CreateSchemaTask"
    dataclass = CreateSchemaConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Create a schema in the data lake.

        Args:
            context (TaskContext): The context object for the task.
            conf (Configuration): The configuration object for the task.
        """
        _conf = self.start_task(context, conf)

        if _conf.catalog_name:
            full_schema_name = f"`{_conf.catalog_name}`.`{_conf.schema_name}`"
        else:
            full_schema_name = f"`{_conf.schema_name}`"

        context.logger.info(f"Creating schema {full_schema_name}")
        context.spark.sql(f"CREATE SCHEMA IF NOT EXISTS {full_schema_name}")
        context.logger.info(f"Schema {full_schema_name} created successfully.")

        if _conf.create_validation_table:
            context.logger.info(f"Creating validation table in {full_schema_name}.validations.")
            df = context.spark.createDataFrame(
                context.spark.sparkContext.emptyRDD(), constants.VALIDATION_TABLE_STRUCTURE
            )
            df.write.format("delta").mode("ignore").saveAsTable(f"{full_schema_name}.validations")

            context.logger.info(f"Validation table created in {full_schema_name}.validations.")


class CreateSchemaCommentsTask(ETLTask):
    """Task for setting schema comment.

    This task will set comments on schemas by checking existing comments in the Unity Catalog.
    """

    task_name: str = "CreateSchemaCommentsTask"
    dataclass = CreateSchemaCommentsConfig

    @staticmethod
    def _get_view_based_comments(context: TaskContext, view_name: str) -> DataFrame:
        """Get schema comments from a view.

        Args:
            context (TaskContext): The task context.
            view_name (str): The name of the view containing comment data.

        Returns:
            DataFrame: DataFrame containing schema comments.
        """
        sql_query = f"""SELECT
            dd.catalog_name,
            dd.schema_name,
            dd.schema_comment
        FROM
            {view_name} dd
        """
        context.logger.info(f"Using SQL query: {sql_query}")
        comments_df = context.spark.sql(sql_query)
        context.logger.info(f"Using view '{view_name}' for schema comments. Rows: {comments_df.count()}")
        return comments_df

    @staticmethod
    def _apply_schema_comment(
        context: TaskContext,
        catalog_name: str,
        schema_name: str,
        comment: str,
    ) -> None:
        """Apply a comment to a specific schema.

        Args:
            context (TaskContext): The task context.
            catalog_name (str): The catalog name.
            schema_name (str): The schema name.
            comment (str): The comment to apply.
        """
        if not comment:
            return

        try:
            # Keep single quotes and double quotes intact by using triple quotes in the SQL later
            escaped_comment = comment.replace("'", "\\'").replace('"', '\\"')
            sql_query = f"""COMMENT ON SCHEMA {catalog_name}.{schema_name}
                IS '{escaped_comment}'"""
            context.logger.info(sql_query)
            context.spark.sql(sql_query)
            context.logger.info(f"""Added comment: {escaped_comment}, to schema
                {catalog_name}.{schema_name}""")
        except Exception as e:
            context.logger.error(f"Could not add comment to schema {catalog_name}.{schema_name}: {e}")

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Set schema comments based on input.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        try:
            if not _conf.view_name:
                context.logger.error("No view name provided for schema comments")
                return

            # Use view-based comment configuration
            comments_df = self._get_view_based_comments(context, _conf.view_name)

            # Process each row to update schema comments
            for row in comments_df.collect():
                self._apply_schema_comment(
                    context,
                    row["catalog_name"],
                    row["schema_name"],
                    row["schema_comment"],
                )

        except Exception as e:
            context.logger.error(f"Schema comments did not set, error: {e}")
