from dataclasses import dataclass


@dataclass
class VolumeConfig:
    """Configuration class for the Volume Tasks.

    Attributes:
        task_name (str): The name of the task.
        schema_name (str): The name of the schema.
        catalog_name (str): The name of the catalog.
        volume_name (str): The name of the volume.
        comment (Optional[str]): Metadata comment to describe the volume (optional).
    """

    task_name: str
    schema_name: str
    catalog_name: str
    volume_name: str
    comment: str | None = None
    paths: str | None = None
