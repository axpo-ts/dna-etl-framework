from dataclasses import dataclass


@dataclass
class CreateColumnCommentsConfig:
    """Configuration class for the Tables Tasks.

    Attributes:
        task_name (str): The name of the task.
        df_namespace (str): The namespace of the data dictionary DataFrame.
        df_key (str): The key of the data dictionary DataFrame.
    """

    task_name: str
    df_namespace: str
    df_key: str
    pause_yaml_comments: bool | None = True
    view_name: str | None = None


@dataclass
class CreateColumnTagsConfig:
    """Configuration class for adding tags to columns in a specified table.

    Attributes:
        task_name (str): The name of the task.
        df_namespace (str): The namespace where the data dictionary DataFrame is stored.
        df_key (str): The key to retrieve the data dictionary DataFrame.
    """

    task_name: str
    df_namespace: str
    df_key: str
