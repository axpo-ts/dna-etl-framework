from pyspark.sql.functions import col

from data_platform.tasks.core import TaskContext


class SchemaUtils:
    """Class of static methods for validation routines against Catalog/Schema/Tables."""

    @staticmethod
    def table_exists(context: TaskContext, catalog_name: str, schema_name: str, table_name: str) -> bool:
        """Returns if a table exists in a given catalog and schema."""
        return (
            context.spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}")
            .filter(col("tableName") == table_name)
            .count()
            > 0
        )

    @staticmethod
    def column_exists(
        context: TaskContext, catalog_name: str, schema_name: str, table_name: str, column_name: str
    ) -> bool:
        """Returns if a column exists in a given catalog, schema and table."""
        if SchemaUtils.table_exists(context, catalog_name, schema_name, table_name):
            column_exists = (
                context.spark.sql(f"DESCRIBE TABLE {catalog_name}.{schema_name}.{table_name}")
                .filter(col("col_name") == column_name)
                .count()
                > 0
            )
            if not column_exists:
                context.logger.warning(
                    f"Column {column_name} does not exist in table {catalog_name}.{schema_name}.{table_name}."
                )
            return column_exists
        else:
            context.logger.warning(f"Table {catalog_name}.{schema_name}.{table_name} does not exist.")
            return False
