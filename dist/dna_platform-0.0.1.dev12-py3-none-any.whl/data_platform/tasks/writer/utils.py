from collections.abc import Callable
from typing import Any

from delta.tables import DeltaTable
from pyspark.sql import DataFrame

from data_platform.tasks.core import TaskContext
from data_platform.tasks.utils import CatalogUtilities, file_provider
from data_platform.tasks.writer.config.dataclasses import SimpleStreamingWriteConfig


class WriterUtilities:
    """Common writer functions to be shared across Tasks."""

    @staticmethod
    def build_update_column_list(target: DeltaTable, exclude_list: list[Any]) -> list[str]:
        """Helper method to construct columns to update."""
        update_columns = [col for col in target.toDF().columns if col not in exclude_list]
        return update_columns

    @staticmethod
    def write_df_with_function(context: TaskContext, conf: Any, df: DataFrame, function: Callable) -> None:
        """Write to dataframe with a batch function."""
        # Set up the streaming writer with logging for writer options and trigger settings
        context.logger.info(f"Writer options: {conf.writer_options}")
        context.logger.info(f"Trigger options: {conf.trigger_kwargs}")

        writer = (
            df.writeStream.options(**conf.writer_options).trigger(**conf.trigger_kwargs).foreachBatch(function).start()
        )

        # Await termination of the streaming job
        context.logger.info("Starting streaming job and awaiting termination.")
        writer.awaitTermination()
        context.logger.info("Streaming job terminated.")

    @staticmethod
    def build_query(context: TaskContext, conf: Any) -> str:
        """Build SQL query and return as string."""
        sql_file: str | None = conf.sql_file
        sql_file_vars: dict[str, str] | None = conf.sql_file_vars
        sql: str | None = conf.sql

        query: str = file_provider(sql_file, lambda f: "".join(f.readlines())) if sql_file else sql

        # Format the SQL query if variables are provided
        if sql_file and sql_file_vars is not None:
            context.logger.info(f"Formatting query with sql_file_vars: {sql_file_vars}")
            query = query.format(**sql_file_vars)

            # Replace variables in the SQL query if provided
            for key, value in sql_file_vars.items():
                query = query.replace(key, value)

            context.logger.info(f"Resolved query: {query}")

        else:
            context.logger.info(f"Using query: {query}")

        return query


def insert_metadata(_conf: SimpleStreamingWriteConfig, context: TaskContext) -> DataFrame | None:
    """Inserts metadata into the specified table in the catalog.

    Args:
        _conf (SimpleStreamingWriteConfig): The configuration object containing the metadata information.
        context (TaskContext): The task context object.

    Returns:
        DataFrame | None: The result of the SQL query if successful, otherwise None.
    """
    full_table_name = CatalogUtilities.build_table_name(_conf.catalog_name, _conf.schema_name, "metadata")
    query_get_table = f"""SELECT * FROM {full_table_name} WHERE `table_name` == '{_conf.table_name}'"""
    metadata_tables = context.spark.sql(query_get_table)

    if metadata_tables.count() == 0:
        query = f"""INSERT INTO {full_table_name} \
        (schema, table_name) VALUES ("{_conf.schema_name}", "{_conf.table_name}")"""
        return context.spark.sql(query)
    return None
