from dataclasses import dataclass


@dataclass
class JsonToVolumeWriterTaskConfig:
    """Configuration class for JsonToVolumeWriterTask.

    This class defines the configuration parameters required for JsonToVolumeWriterTask.

    Args:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame in the task context.
        df_input_key (str): The key for retrieving the input DataFrame from the task context.
        schema_name (str): The name of the schema.
        catalog_name (str): The name of the catalog.
        volume_name (str): The name of the volume.
        file_name
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    schema_name: str
    catalog_name: str
    volume_name: str
    file_name: str
    add_timestamp: str | bool | None = "False"
    use_dbutils: bool = True

    def __post_init__(self) -> None:
        """Function that transforms the params frther if needed."""
        self.add_timestamp = self.add_timestamp in ["True", "TRUE", "true", "T", "t", "1"]


@dataclass
class VolumeWriterTaskConfig:
    """Configuration class for VolumeWriterTask classes.

    This class defines the configuration parameters required for JsonToVolumeWriterTask.

    Args:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame in the task context.
        df_input_key (str): The key for retrieving the input DataFrame from the task context.
        schema_name (str): The name of the schema.
        catalog_name (str): The name of the catalog.
        volume_name (str): The name of the volume.
        file_name
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    schema_name: str
    catalog_name: str
    volume_name: str
    file_name: str
    file_format: str
    file_delimiter: str | None = ","
    add_timestamp: str | bool | None = "False"
    data_content_type: str | None = "string"
    number_of_partitions: str | int | None = "1"

    def __post_init__(self) -> None:
        """Function that transforms the params further if needed."""
        self.add_timestamp = self.add_timestamp in ["True", "TRUE", "true", "T", "t", "1"]
        # Convert number_of_partitions to int with validation
        if self.number_of_partitions is not None and str(self.number_of_partitions).lower() != "null":
            try:
                self.number_of_partitions = int(self.number_of_partitions)
            except (ValueError, TypeError):
                raise ValueError(f"number_of_partitions must be a valid integer, got: {self.number_of_partitions}")
        else:
            self.number_of_partitions = 1
