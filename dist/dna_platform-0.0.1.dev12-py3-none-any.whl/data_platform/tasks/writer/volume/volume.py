import datetime
import json
import zipfile
from io import BytesIO

from pyspark.sql import DataFrame

from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.writer.volume.config.dataclasses import JsonToVolumeWriterTaskConfig, VolumeWriterTaskConfig


class WriterToVolumeError(Exception):
    """Writting to volume error.

    A class to handle different types of exceptions for writing to databricks volumes.
    """


class JsonToVolumeWriterTask(ETLTask):
    """Task for writing json data to volumes.

    This class represents a task that writes json to a databricks volume.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[JsonToVolumeWriterTaskConfig]): The configuration dataclass.

    """

    task_name = "JsonToVolumeWriterTask"
    dataclass = JsonToVolumeWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the JsonToVolumeWriterTask.

        Fetches json data and write it to a databricks volume.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        # Set the dataframe to view name
        _conf = self.start_task(context, conf)

        # volume to write the json object
        volume_location = f"/Volumes/{_conf.catalog_name}/{_conf.schema_name}/{_conf.volume_name}"
        context.logger.info(volume_location)

        # get json object from context
        content: str = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)

        # location to write the json object
        if _conf.add_timestamp:
            time_now = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            file_location = f"{volume_location}/{_conf.file_name}_{time_now}.json"
        else:
            file_location = f"{volume_location}/{_conf.file_name}.json"

        context.logger.info(file_location)
        try:
            # write json object to databricks volume
            use_dbutils = str(_conf.use_dbutils)
            context.logger.info(f"use dbutils: {use_dbutils}")
            if json.loads(use_dbutils.lower()):
                dbutils = get_dbutils(context.spark)
                dbutils.fs.put(file_location, json.loads(json.dumps(content)), overwrite=True)  # type: ignore
            else:
                with open(file_location, "w") as file:
                    json.dump(content, file)
            context.logger.info(f"inserted file at {file_location}")
        except Exception as e:
            raise WriterToVolumeError(f"error writing to volume {file_location}, error: {e}")


class ObjectToVolumeWriterTask(ETLTask):
    """Task for writing data to volumes.

    This class represents a task that writes any object to a databricks volume.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[VolumeWriterTaskConfig]): The configuration dataclass.

    """

    task_name = "ObjectToVolumeWriterTask"
    dataclass = VolumeWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ObjectToVolumeWriterTask.

        Fetches json data and write it to a databricks volume.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        # Set the dataframe to view name
        _conf = self.start_task(context, conf)

        # volume to write the object
        volume_location = f"/Volumes/{_conf.catalog_name}/{_conf.schema_name}/{_conf.volume_name}"

        # get file format object from context
        file_format = _conf.file_format

        # get optional file delimiter
        file_delimiter = _conf.file_delimiter

        # location to write the object
        if _conf.add_timestamp:
            time_now = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            file_location = f"{volume_location}/{_conf.file_name}_{time_now}.{file_format}"

        else:
            file_location = f"{volume_location}/{_conf.file_name}.{file_format}"

        try:
            # get response object from context or view
            if _conf.data_content_type == "string":
                content: str = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)

                # write object to databricks volume
                dbutils = get_dbutils(context.spark)

                dbutils.fs.put(file_location, content, overwrite=True)  # type: ignore

            elif _conf.data_content_type == "DataFrame":
                df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
                context.logger.info(f"df.count(): {df.count()}")
                df.coalesce(1).write.option("header", True).option("sep", file_delimiter).csv(file_location)

            context.logger.info(f"inserted file at {file_location}")
        except Exception as e:
            raise WriterToVolumeError(f"error writing to volume {file_location}, error: {e}")


class VolumeFileLocationMixin:
    """Mix-in class providing shared file location functionality for volume writer tasks."""

    @staticmethod
    def get_file_location(volume_location: str, filename: str, config: VolumeWriterTaskConfig) -> str:
        """Determines the file location for writing based on config settings."""
        if config.add_timestamp:
            time_now = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            base_filename = filename.replace(".csv", "")
            return f"{volume_location}/{base_filename}_{time_now}.csv"
        else:
            return f"{volume_location}/{filename}"


class ZipCSVObjectToVolumeWriterTask(ETLTask, VolumeFileLocationMixin):
    """Task for writing CSV files from a zip archive to a Databricks volume.

    This class extracts CSV files from a zip archive and writes them
    to a specified Databricks volume location.
    """

    task_name: str = "ZipCSVObjectToVolumeWriterTask"
    dataclass = VolumeWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ZipCSVObjectToVolumeWriterTask.

        Extracts CSV files from a zip archive and writes them to a Databricks volume.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        context.logger.info("Running ZipCSVObjectToVolumeWriterTask")
        _conf = self.dataclass(**conf.as_dict())

        volume_location = self.get_volume_location(_conf)

        try:
            zip_content = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
            context.logger.info(f"zip_type = {type(zip_content)} -- zip_content: {len(zip_content)}")

            self.process_zip_content(zip_content, volume_location, _conf, context)

        except Exception as e:
            raise WriterToVolumeError(f"Error writing CSV files from zip to volume {volume_location}, error: {e}")

    @staticmethod
    def get_volume_location(config: VolumeWriterTaskConfig) -> str:
        """Constructs the volume location path."""
        return f"/Volumes/{config.catalog_name}/{config.schema_name}/{config.volume_name}"

    @staticmethod
    def process_zip_content(
        zip_content: bytes, volume_location: str, config: VolumeWriterTaskConfig, context: TaskContext
    ) -> None:
        """Processes the zip content and writes CSV files to the volume."""
        with zipfile.ZipFile(BytesIO(zip_content)) as z:
            for filename in z.namelist():
                if filename.endswith(".csv"):
                    context.logger.info(f"Processing file: {filename}")
                    with z.open(filename) as f:
                        csv_content = f.read()
                        file_location = ZipCSVObjectToVolumeWriterTask.get_file_location(
                            volume_location, filename, config
                        )

                        ZipCSVObjectToVolumeWriterTask.write_file(file_location, csv_content)

    @staticmethod
    def write_file(file_location: str, content: bytes) -> None:
        """Writes the given content to a file."""
        print(f"Writing file to: {file_location}")
        with open(file_location, "wb") as temp_file:
            temp_file.write(content)


class CSVObjectToVolumeWriterTask(ETLTask, VolumeFileLocationMixin):
    """Task for writing CSV files from a zip archive to a Databricks volume.

    This class extracts CSV files from a zip archive and writes them
    to a specified Databricks volume location.
    """

    task_name: str = "CSVObjectToVolumeWriterTask"
    dataclass = VolumeWriterTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the CSVObjectToVolumeWriterTask.

        Writes dataframe to a CSV file in a Databricks volume.

        Args:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        context.logger.info("Running CSVObjectToVolumeWriterTask")
        _conf = self.dataclass(**conf.as_dict())

        volume_location = self.get_volume_location(_conf)

        try:
            df = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
            if df is not None and not df.isEmpty():
                file_location = self.get_file_location(volume_location, _conf.file_name, _conf)
                context.logger.info(f"CSVObjectToVolumeWriterTask:>> Writing file to: {file_location}")
                self.write_file(df, file_location, context, _conf.number_of_partitions)
            else:
                context.logger.info("CSVObjectToVolumeWriterTask:>> No data to write")
                return

        except Exception as e:
            raise WriterToVolumeError(f"Error writing CSV files from zip to volume {volume_location}, error: {e}")

    @staticmethod
    def get_volume_location(config: VolumeWriterTaskConfig) -> str:
        """Constructs the volume location path."""
        return f"/Volumes/{config.catalog_name}/{config.schema_name}/{config.volume_name}"

    @staticmethod
    def write_file(df: DataFrame, file_location: str, context: TaskContext, number_of_partitions: int = 1) -> None:
        """Writes the given content to a file."""
        context.logger.info(f"Writing file to: {file_location} with {number_of_partitions} partitions")
        df.repartition(number_of_partitions).write.option("header", True).csv(file_location)
