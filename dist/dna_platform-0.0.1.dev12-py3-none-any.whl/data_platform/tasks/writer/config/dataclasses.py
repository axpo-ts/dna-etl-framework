from dataclasses import dataclass, field
from typing import Any

from data_platform.tasks.config.dataclasses import BaseCatalogConfig


@dataclass(kw_only=True)
class SimpleStreamingWriteConfig(BaseCatalogConfig):
    """Configuration class for SimpleStreamingWriterTask and SimpleBatchWriterTask.

    This class defines the configuration parameters required for both SimpleStreamingWriterTask and
    SimpleBatchWriterTask, including details about the input DataFrame, output table, output format, and writer options.

    Args:
        _format (str): The format in which data will be written (e.g., "parquet", "delta").
        output_mode (str): The output mode for streaming writers.
        writer_options (Dict[str, str], optional): Additional writer options as a dictionary
                                                (default is an empty dictionary).

    """

    output_mode: str
    _format: str = "delta"
    writer_options: dict[str, str] = field(default_factory=dict)


@dataclass(kw_only=True)
class SimpleStreamingUpsertConfig(BaseCatalogConfig):
    """Configuration class for the SimpleBatchUpsertTask.

    This class defines the configuration parameters required for the SimpleBatchUpsertTask, including
    details about the input DataFrame, output table, output format, and writer options.

    Args:
        primary_keys (str | list[str]): The list of primary keys. Can be supplied as a comma separated str.
        trigger_kwargs (Dict[str, Any]): What options to use for trigger when streaming. Eg {"once": True}
        writer_options (Dict[str, str], optional): Additional writer options as a dictionary when streaming
                                                (default is an empty dictionary).
        drop_duplicates (bool, optional): Optional flag to drop duplicates on primary keys. Default is False
    """

    primary_keys: str | list[str]
    created_columns: str | list[str] = "created_at, created_by"
    updated_columns: str | list[str] = "updated_at, updated_by"
    ignore_columns: str | list[str] = "table_id"
    trigger_kwargs: dict[str, Any] = field(default_factory=dict)
    writer_options: dict[str, str] = field(default_factory=dict)
    drop_duplicates: bool = False
    use_append: bool = False

    def __post_init__(self) -> None:
        """Post initialization method to convert a primary key str to list."""
        if isinstance(self.primary_keys, str):
            self.primary_keys = [x.strip() for x in self.primary_keys.split(",")]
        if isinstance(self.created_columns, str):
            self.created_columns = [x.strip() for x in self.created_columns.split(",")]
        if isinstance(self.updated_columns, str):
            self.updated_columns = [x.strip() for x in self.updated_columns.split(",")]
        if isinstance(self.ignore_columns, str):
            self.ignore_columns = [x.strip() for x in self.ignore_columns.split(",")]


@dataclass
class StreamingSQLWriterTaskConfig:
    """Configuration class for StreamingSQLWriterTask.

    This class defines the configuration parameters required for StreamingSQLWriterTask.

    Args:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame in the task context.
        df_input_key (str): The key for retrieving the input DataFrame from the task context.
        df_alias (str): The temporary table name to give to the input DataFrame from the task context.
        trigger_kwargs (Dict[str, Any]): What options to use for trigger. Eg {"once": True}
        sql (str, optional): The SQL query to apply (if not using a file).
        sql_file (str, optional): The path to an SQL file containing the query (if not using inline SQL).
        sql_file_vars (Dict[str, str], optional): A dictionary of variables within the SQL file
        writer_options (Dict[str, str], optional): Additional writer options as a dictionary
                                                (default is an empty dictionary).
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    df_alias: str
    trigger_kwargs: dict[str, Any]
    sql: str | None = None
    sql_file: str | None = None
    sql_file_vars: dict[str, str] | None = None
    writer_options: dict[str, str] = field(default_factory=dict)


@dataclass
class BatchSQLWriterTaskConfig:
    """Configuration class for BatchSQLWriterTask.

    This class defines the configuration parameters required for BatchSQLWriterTask.

    Args:
        task_name (str): The name of the task.
        df_input_namespace (str): The namespace of the input DataFrame in the task context.
        df_input_key (str): The key for retrieving the input DataFrame from the task context.
        df_alias (str): The temporary table name to give to the input DataFrame from the task context.
        sql (str, optional): The SQL query to apply (if not using a file).
        sql_file (str, optional): The path to an SQL file containing the query (if not using inline SQL).
        sql_file_vars (Dict[str, str], optional): A dictionary of variables within the SQL file
    """

    task_name: str
    df_input_namespace: str
    df_input_key: str
    df_alias: str
    sql: str | None = None
    sql_file: str | None = None
    sql_file_vars: dict[str, str] | None = None


@dataclass
class CloneTableTaskConfig:
    """Configuration class for CloneTableTask.

    This class defines the configuration parameters required for CloneTableTask.

    Args:
        task_name (str): The name of the task.
        source_catalog (str): The source catalog name.
        source_schema_name (str): The source schema name.
        source_table_name (str): The source table name.
        target_catalog (str): The target catalog name.
        target_schema_name (str): The target schema name.
        target_table_name (str): The target table name.
        clone_type (str, optional): The clone type. If not specified it will use Deep
        table_properties (Dict[str, str], optional): Optionally sets one or more user-defined properties.
        location (str, optional): Optionally creates an external table, with the provided location.
    """

    task_name: str
    source_schema_name: str
    source_table_name: str
    target_schema_name: str
    target_table_name: str
    source_catalog: str | None = None
    target_catalog: str | None = None
    clone_type: str | None = "SHALLOW"
    table_properties: dict[str, str] = field(default_factory=dict)
    location: str | None = None
