from pyspark.sql import DataFrame

from data_platform.etl.core.task_context import TaskContext as NewTaskContext
from data_platform.etl.transform.reference_mapping import ApplyReferenceMappingsGroupsTask
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.reference.config.dataclasses import ApplyReferenceMappingConfig


class ApplyReferenceMappingTask(ETLTask):
    """Task for applying reference mappings to a DataFrame.

       This class represents a task that applies reference mappings to a DataFrame based on the provided configuration.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplyReferenceMappingConfig]): The configuration dataclass.

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the ApplyReferenceMappingTask by creating reference tables
            based on the provided YAML configuration.
    """

    task_name: str = "ApplyReferenceMappingTask"
    dataclass = ApplyReferenceMappingConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ApplyReferenceMappingTask."""
        _conf = self.start_task(context, conf)
        context.logger.info("Starting ApplyReferenceMappingTask...")

        mapping_ref_groups = _conf.mapping_ref_groups
        rename_to_group = _conf.rename_to_group
        df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
        new_context = NewTaskContext(
            catalog_prefix=_conf.catalog_prefix,
            schema_prefix=_conf.schema_prefix,
        )

        context.logger.info(f"Applying reference mappings to DataFrame with {df.count()} rows")
        df = ApplyReferenceMappingsGroupsTask(
            context=new_context, mapping_ref_groups=mapping_ref_groups, rename_to_group=rename_to_group
        ).execute(df)
        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df)
