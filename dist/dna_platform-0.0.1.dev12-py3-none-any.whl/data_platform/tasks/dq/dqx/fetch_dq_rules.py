import json
from pathlib import Path
from typing import cast

from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, lower, trim

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.dq.dqx.config.dataclasses import DataQualityRulesConfig


class DataQualityRulesTask(ETLTask):
    """A class to read JSON files and create a unified DataFrame.

    This class reads all JSON files named 'dq.json' from a specified directory and its subdirectories,
    and unions them into a single DataFrame.

    Attributes:
        task_name (str): The name of the task.
    """

    task_name = "DataQualityRulesTask"
    dataclass = DataQualityRulesConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the reading and unioning of JSON DataFrames.

        Returns:
            DataFrame | None: The union of all DataFrames or None if no DataFrames were found.
        """
        context.logger.info("Starting processing...")
        conf = self.start_task(context, conf)

        _conf = cast(DataQualityRulesConfig, conf)

        dataframes = self.read_json_files(context, _conf.search_directory)

        df = self.union_dataframes(dataframes)

        final_df = self.prioritize_template_rules(df, _conf, context)

        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=final_df)

    @staticmethod
    def read_json_files(context: TaskContext, search_directory: str) -> list[DataFrame]:
        """Reads JSON files from the directory and returns them as a list of DataFrames.

        Args:
            context (TaskContext): The task context containing Spark session and logger.
            search_directory (str): The directory to search for JSON files.

        Returns:
            list[DataFrame]: A list of DataFrames created from JSON files.
        """
        dataframes = []
        for path in Path(search_directory).rglob("*dq.json"):
            filepath = str(path)
            print(f"Reading JSON file: {filepath}")
            try:
                with open(filepath) as f:
                    data = json.load(f)

                df = context.spark.createDataFrame(data)
                dataframes.append(df)
            except (FileNotFoundError, json.JSONDecodeError) as e:
                print(f"Error reading {filepath}: {e}")

        return dataframes

    @staticmethod
    def union_dataframes(dataframes: list[DataFrame]) -> DataFrame | None:
        """Unions all DataFrames into a single DataFrame and displays it.

        Args:
            dataframes (list[DataFrame]): A list of DataFrames to union.

        Returns:
            DataFrame | None: The union of all DataFrames or None if no DataFrames were found.
        """
        if dataframes:
            final_df = dataframes[0]
            for df in dataframes[1:]:
                final_df = final_df.union(df)
            return final_df
        else:
            print("No JSON files found.")
            return None

    @staticmethod
    def prioritize_template_rules(
        codebase_rules_df: DataFrame | None, conf: DataQualityRulesConfig, context: TaskContext
    ) -> DataFrame:
        """Prioritize template rules over codebase rules.Ignore codebase rules if template rule exists.

        Args:
            codebase_rules_df (DataFrame): The DataFrame containing codebase rules.
            conf (Configuration): The task configuration.
            context (TaskContext): The task context containing Spark session and logger.

        Returns:
            DataFrame: The DataFrame with prioritized template rules.
        """
        existing_rules_df = context.spark.read.table(conf.dq_rules_table).filter('Source="Template"')
        if codebase_rules_df is None:
            return context.spark.createDataFrame([], existing_rules_df.schema)

        codebase_rules_df = codebase_rules_df.dropDuplicates()
        codebase_rules_df = codebase_rules_df.withColumn("Source", lit("DQConfig"))

        codebase_rules_df = codebase_rules_df.alias("codebase").join(
            existing_rules_df.alias("existing"),
            (lower(trim(col("codebase.Table"))) == lower(trim(col("existing.Table"))))
            & (lower(trim(col("codebase.Schema"))) == lower(trim(col("existing.Schema"))))
            & (lower(trim(col("codebase.Dimension"))) == lower(trim(col("existing.Dimension"))))
            & (lower(trim(col("codebase.Name"))) == lower(trim(col("existing.Name")))),
            "left_anti",
        )

        return codebase_rules_df
