import functools

from pyspark.sql import DataFrame

from data_platform.etl.transform import transform
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.transform.config.dataclasses import ApplyPysparkConfig


class ApplyPysparkTask(ETLTask):
    """A task that applies transform funcs on a DataFrame.

    This task takes a DataFrame as input, applies an SQL query to it, and stores the result in another DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplySQLTaskConfig]): The configuration dataclass.

    """

    task_name = "ApplyPysparkTask"
    dataclass = ApplyPysparkConfig

    @staticmethod
    def _lookup_transformations(transformations: list[dict]) -> list[dict]:
        return [{"func": getattr(transform, t["func"]), "args": t["args"]} for t in transformations]

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ApplyPysparkTask by dissecting the key pair values of the configuration.

        Then executing the SQL query.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        context.logger.info("get the input dataframe")
        init_df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
        context.logger.info(init_df.schema)
        # add the Task Context to the function arguments
        context.logger.info("adding the logger to each function")
        _transformation_list = _conf.transformations
        for _transf in _transformation_list:
            _transf["args"]["logger"] = context.logger

        # apply the transformations
        transformations = self._lookup_transformations(_transformation_list)
        df_out = functools.reduce(lambda df, func: df.transform(func["func"], **func["args"]), transformations, init_df)

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df_out)
