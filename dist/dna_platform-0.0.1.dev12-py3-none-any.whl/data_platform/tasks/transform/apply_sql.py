import importlib.resources as impresources

from pyspark.sql import DataFrame

from data_platform import constants
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.transform.config.dataclasses import ApplySQLTaskConfig
from data_platform.tasks.utils import file_provider


class ApplySQLTask(ETLTask):
    """A task that applies SQL queries on a DataFrame.

    This task takes a DataFrame as input, applies an SQL query to it, and stores the result in another DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplySQLTaskConfig]): The configuration dataclass.

    """

    task_name = "ApplySQLTask"
    dataclass = ApplySQLTaskConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the ApplySQLTask.

        Args:
            context (TaskContext): The context object for the task.
            conf (Configuration): The configuration object for the task.
        """
        _conf = self.start_task(context, conf)

        context.logger.info("get dataframe")
        df: DataFrame = context.get_property(namespace=_conf.df_input_namespace, key=_conf.df_input_key)
        df.createOrReplaceTempView(_conf.df_alias)

        # get sql query
        sql_file: str = _conf.sql_file
        sql_file_vars: dict[str, str] | None = _conf.sql_file_vars

        query: str
        try:
            query = file_provider(sql_file, lambda f: "".join(f.readlines()))
        except FileNotFoundError:  # pragma: no cover
            context.logger.info(f"Loading file from package resources: {constants.PACKAGE_SQL} {sql_file}")
            imp_file = impresources.files(constants.PACKAGE_SQL) / sql_file
            query = file_provider(imp_file, lambda f: "".join(f.readlines()))

        # apply sql on dataframe
        if sql_file_vars:
            context.logger.info(f"sql_file_vars: {sql_file_vars}")
            for key, value in sql_file_vars.items():
                query = query.replace(key, value)

        context.logger.info(f"apply sql {query}")

        # Process dynamic columns
        dynamic_columns = _conf.dynamic_columns.split(", ") if _conf.dynamic_columns else []

        if "dynamic_columns_unpacking" in query:
            if dynamic_columns:
                dynamic_unpacked = ",\n".join([f"{col}" for col in dynamic_columns])
                query = query.replace("dynamic_columns_unpacking", dynamic_unpacked)
                context.logger.info(f"Dynamic columns unpacked and added to query: {dynamic_unpacked}")
            else:
                context.logger.warning(
                    "Either 'dynamic_columns_unpacking' placeholder is missing or the dynamic columns list is empty."
                )
        context.logger.info(f"Final SQL Query after processing dynamic columns:\n{query}")

        df_out = context.spark.sql(query)  # type: ignore

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df_out)
