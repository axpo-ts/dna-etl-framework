from pyspark.sql import DataFrame

from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.transform.config.dataclasses import (
    IncrementalTablesReaderTaskConfig,
    JoinDataFrameConfig,
    UnionDataFrameConfig,
)


class JoinDataFrameTask(ETLTask):
    """A task that applies transform funcs on a DataFrame.

    This task takes a DataFrame as input, applies an SQL query to it, and stores the result in another DataFrame.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplySQLTaskConfig]): The configuration dataclass.

    """

    task_name = "JoinDataFrameTask"
    dataclass = JoinDataFrameConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ApplyPysparkTask by dissecting the key pair values of the configuration.

        Then executing the SQL query.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        context.logger.info("get dataframe")
        df_left: DataFrame = context.get_property(namespace=_conf.df_input_namespace_left, key=_conf.df_input_key_left)
        df_right: DataFrame = context.get_property(
            namespace=_conf.df_input_namespace_right, key=_conf.df_input_key_right
        )

        df = df_left.join(df_right, _conf.join_on, _conf.join_how)

        # add dataframe onto task context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df)

        context.logger.info("return dataframe")


class UnionByNameDataFrameTask(ETLTask):
    """A task that unions two daframes by column names.

    This task takes two DataFrames as input and applyes the 'unionByName' operation.

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[ApplySQLTaskConfig]): The configuration dataclass.

    """

    task_name = "UnionByNameDataFrameTask"
    dataclass = UnionDataFrameConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the ApplyPysparkTask by dissecting the key pair values of the configuration.

        Then executing the SQL query.

        Parameters:
            context (TaskContext): The task context.
            conf (Configuration): The task configuration.
        """
        _conf = self.start_task(context, conf)

        context.logger.info("get the two dataframes")
        df_1: DataFrame = context.get_property(namespace=_conf.df_input_namespace_first, key=_conf.df_input_key_first)
        df_2: DataFrame = context.get_property(namespace=_conf.df_input_namespace_second, key=_conf.df_input_key_second)

        context.logger.info("taking the union of the two dataframes")
        df = df_1.unionByName(df_2, allowMissingColumns=bool(_conf.allow_missing_columns))

        # add dataframe onto task context
        context.logger.info("returning the output dataframe")
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df)


class IncrementalTablesReaderTask(ETLTask):
    """A task that unions multiple source tables incrementally based on a configurable watermark column.

    This task reads multiple available source tables, applies incremental filtering based on the maximum value

    Attributes:
        task_name (str): The name of the task.
        dataclass (Type[UnionIncrementalTablesTaskConfig]): The configuration dataclass.

    """

    task_name = "IncrementalTablesReaderTask"
    dataclass = IncrementalTablesReaderTaskConfig

    def _is_valid_name(self, table_name: str) -> bool:
        """Check if the given table name is syntactically valid and non-empty."""
        return bool(table_name and table_name.strip() and not table_name.endswith(".") and ".." not in table_name)

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Execute the UnionIncrementalTablesTask by unioning multiple source tables incrementally."""
        _conf = self.start_task(context, conf)
        spark = context.spark
        logger = context.logger

        source_tables: dict[str, str] = _conf.source_tables or {}
        target_table: str = _conf.target_table
        watermark_col: str = _conf.watermark_column or "updated_at"
        watermark_filter: str | None = getattr(_conf, "watermark_filter", None)

        logger.info(f"Source tables: {source_tables}, Target table: {target_table}, Watermark column: {watermark_col}")
        if watermark_filter:
            logger.info(f"Applying watermark filter before computing max watermark: {watermark_filter}")

        # Compute max watermark from target table
        try:
            if spark.catalog.tableExists(target_table):
                filter_clause = f"WHERE {watermark_filter}" if watermark_filter else ""
                query = f"""
                    SELECT COALESCE(MAX({watermark_col}), '1900-01-01 00:00:00') AS max_watermark
                    FROM {target_table}
                    {filter_clause}
                """
                logger.info(f"Computing max watermark with query: {query.strip()}")
                max_date_df = spark.sql(query)
                max_watermark = max_date_df.collect()[0]["max_watermark"]
                logger.info(f"Max {watermark_col} found: {max_watermark}")
            else:
                max_watermark = "1900-01-01 00:00:00"
                logger.warning(
                    f"Target table '{target_table}' does not exist. Using default watermark: {max_watermark}"
                )
        except Exception as e:
            max_watermark = "1900-01-01 00:00:00"
            logger.warning(f"Unable to compute max({watermark_col}) from target table: {e}")

        # Read and incrementally filter tables
        dataframes: list[DataFrame] = []
        for alias, table_name in source_tables.items():
            if not self._is_valid_name(table_name) or not spark.catalog.tableExists(table_name):
                logger.warning(f"Skipping invalid or non-existent table for alias: {alias} -> {table_name}")
                continue

            logger.info(f"Reading source table: {table_name}")
            df = spark.table(table_name)

            # Apply watermark filter for incremental tables
            if watermark_col in df.columns:
                df = df.filter(df[watermark_col] > max_watermark)
                logger.info(f"Applied incremental filter on {table_name}")
            else:
                logger.warning(f"{watermark_col} not found in table '{table_name}'. No filter applied.")

            dataframes.append(df)

        if not dataframes:
            raise ValueError("No valid source tables found in configuration")

        logger.info(f"Unioning {len(dataframes)} tables")
        df_union = dataframes[0]
        for df in dataframes[1:]:
            df_union = df_union.unionByName(df, allowMissingColumns=True)

        if _conf.drop_duplicates:
            audit_cols = ["created_at", "updated_at", "created_by", "updated_by"]
            logger.info("Dropping duplicates from the unioned DataFrame, ignoring audit columns")
            columns_to_consider = [col for col in df_union.columns if col not in audit_cols]
            df_union = df_union.dropDuplicates(subset=columns_to_consider)

        # Save result to context
        context.put_property(namespace=_conf.df_output_namespace, key=_conf.df_output_key, value=df_union)
