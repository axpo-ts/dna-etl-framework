from data_platform.common import get_dbutils
from data_platform.tasks.core import Configuration, ETLTask, TaskContext
from data_platform.tasks.secrets.config.dataclasses import GetSecretConfig


class GetSecretTask(ETLTask):
    """Task for retrieving a secret from databricks secrets via dbutils.

    Attributes:
        task_name (str): Name of the task
        dataclass (Type[GetSecretConfig]): The configuration dataclass

    Methods:
        execute(self, context: TaskContext, conf: Configuration):
            Execute the GetSecretTask by retrieving the secret value from secrets in databricks.
    """

    task_name = "GetSecretTask"
    dataclass = GetSecretConfig

    def execute(self, context: TaskContext, conf: Configuration) -> None:
        """Executes the GetSecretTask which retrieves the secret value from databricks.

        and stores it in the task context.

        Parameters:
            context (TaskContext): The task context
            conf (Configuration): The task configuration.

        """
        _conf = self.start_task(context, conf)

        utils = get_dbutils(context.spark)

        # get secret from scope using key
        _conf.secret_key = _conf.secret_key if isinstance(_conf.secret_key, list) else [_conf.secret_key]
        context.logger.info(f"getting the secret for scope = '{_conf.secret_scope}' and keys = '{_conf.secret_key}'")
        for key in _conf.secret_key:
            secret = utils.secrets.get(_conf.secret_scope, key)  # type: ignore
            context.put_property(namespace=_conf.namespace, key=key, value=secret)
