from dataclasses import dataclass


@dataclass
class GetSecretConfig:
    """Configuration class for GetSecretTask.

    This class defines the configuration parameters required for GetSecretTask.

    Args:
        task_name (str): The name of the task
        secret_scope (str): The scope in databricks secrets that contains the secret key.
        secret_key (str): The key of the secret in databricks secrets.
        namespace (str): the namespace to store the secret in the task context.
    """

    task_name: str
    secret_scope: str
    secret_key: str | list
    namespace: str
