-- add audit columns if pure append mode
SELECT
    *,
    CURRENT_TIMESTAMP() AS created_at,
    CURRENT_USER() AS created_by,
    CURRENT_TIMESTAMP() AS updated_at,
    CURRENT_USER() AS updated_by
FROM source_table
