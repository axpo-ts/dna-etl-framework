from data_platform.data_model.bronze.ebx.commodity import commodity_table
from data_platform.data_model.bronze.ebx.country import country_table
from data_platform.data_model.bronze.ebx.currency import currency_table
from data_platform.data_model.bronze.ebx.language import language_table
from data_platform.data_model.bronze.ebx.unit import unit_table
