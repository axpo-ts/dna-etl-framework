from data_platform.data_model.silver.price.power_afrr_prices import (
    power_afrr_energy_table,
    power_afrr_capacity_table,
)
