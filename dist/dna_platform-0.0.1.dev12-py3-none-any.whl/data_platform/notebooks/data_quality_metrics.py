# Databricks notebook source
import re

from pyspark.sql import SparkSession

spark = SparkSession.builder.getOrCreate()

# COMMAND ----------


catalog = dbutils.widgets.get("catalog")  # type: ignore # noqa: F821
catalog_prefix = dbutils.widgets.get("catalog_prefix")  # type: ignore # noqa: F821
schema = dbutils.widgets.get("schema")  # type: ignore # noqa: F821
schema_prefix = dbutils.widgets.get("schema_prefix")  # type: ignore # noqa: F821
dq_metrics_table = dbutils.widgets.get("dq_metrics_table")  # type: ignore # noqa: F821
dq_rules_table = dbutils.widgets.get("dq_rules_table")  # type: ignore # noqa: F821
# COMMAND ----------

dq_metrics_table_name = f"{catalog_prefix}_{catalog}.{schema_prefix}{schema}.{dq_metrics_table}"
print(f"metrics target table : {dq_metrics_table_name}")


# COMMAND ----------

table_list = spark.sql("""
                       SELECT *
                        FROM system_tables_sharing.system_tables_information_schema.tables
                        WHERE table_type IN ('MATERIALIZED_VIEW', 'STREAMING_TABLE')
                        AND table_catalog like '%gold'
""").collect()


# COMMAND ----------

for table in table_list:
    source_table_name = f"{table['table_catalog']}.{table['table_schema']}.{table['table_name']}"
    target_table_name = source_table_name.replace(".", "_")
    dataset = table["table_name"]
    match = re.search(r"(?:.*?_)??([a-zA-Z]+(?:_[a-zA-Z]+)+)$", dataset)

    if match:
        dataset = match.group(1)
        source_table_name_cleaned = f"{table['table_catalog']}.{table['table_schema']}.{dataset}"
        print(f"dataset is {dataset}")
    try:
        df = spark.sql(f"""
            SELECT *,
                CURRENT_TIMESTAMP() AS created_at,
                CURRENT_USER() AS created_by,
                CURRENT_TIMESTAMP() AS updated_at,
                CURRENT_USER() AS updated_by
            FROM (
                SELECT
                    timestamp,
                    "{table["table_schema"]}" as schema,
                    row_expectations.dataset as table,
                    row_expectations.name as name,
                    date_format(timestamp, 'yyyyMMdd_HHmm') as evaluation,
                    SUM(row_expectations.passed_records) as passing_records,
                    SUM(row_expectations.failed_records) as failing_records,
                    SUM(NVL(row_expectations.passed_records, 0)) +
                    SUM(NVL(row_expectations.failed_records, 0))
                    AS total_number_of_records
                FROM (
                    SELECT
                        explode(
                        from_json(
                            details:flow_progress:data_quality:expectations,
                            "array<struct<name: string, dataset: string, passed_records: int, failed_records: int>>"
                        )
                        ) row_expectations,
                        timestamp as timestamp
                    FROM event_log(TABLE({source_table_name}))
                    WHERE event_type = 'flow_progress'
                    AND details:flow_progress:status = "COMPLETED"
                )
                GROUP BY
                    row_expectations.dataset,
                    row_expectations.name,
                    timestamp
            )
            WHERE (table = '{dataset}' or table = '{dataset}_dq_checks')
        """)
        # df.display()
        df.createOrReplaceTempView(target_table_name)
        spark.sql(f"""
                MERGE INTO {dq_metrics_table_name} t
                USING {target_table_name} s
                ON t.name = s.name
                AND t.schema = s.schema
                AND t.timestamp = s.timestamp
                AND t.table = s.table
                WHEN MATCHED THEN UPDATE SET
                    t.evaluation = s.evaluation,
                    t.passing_records = s.passing_records,
                    t.failing_records = s.failing_records,
                    t.total_number_of_records = s.total_number_of_records,
                    t.updated_at = s.updated_at,
                    t.updated_by = s.updated_by
                WHEN NOT MATCHED THEN INSERT
                (
                    schema,
                    table,
                    name,
                    evaluation,
                    passing_records,
                    failing_records,
                    total_number_of_records,
                    timestamp,
                    created_at,
                    created_by,
                    updated_at,
                    updated_by
                )
                VALUES
                (
                    s.schema,
                    s.table,
                    s.name,
                    s.evaluation,
                    s.passing_records,
                    s.failing_records,
                    s.total_number_of_records,
                    s.timestamp,
                    s.created_at,
                    s.created_by,
                    s.updated_at,
                    s.updated_by)
                """)
    except Exception as e:
        if "PERMISSION_DENIED:" in str(e):
            print(f"Permission denied for table {dataset}. Skipping...")
        else:
            raise e


# COMMAND ----------
