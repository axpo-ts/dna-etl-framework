import json
import logging
from collections.abc import Callable, Collection
from importlib.abc import Traversable
from typing import Any, TextIO

import pandas as pd
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as f

logger: logging.Logger
logger = logging.getLogger(__name__)


def get_dlt_config(dlt_config_path: str | None) -> Collection[dict[str, str]]:
    """Get DLT Config."""
    with open(f"{dlt_config_path}") as f:
        dlt_config = json.loads(f.read())
        return dlt_config


def file_provider(path: str | Traversable, call: Callable[[TextIO], Any], mode: str = "r") -> Any:
    """Executes a function on a TextIO object with the given path.

    Args:
        path (Union[str, Traversable]): The path to the file.
        call (Callable[[TextIO], Any]): The function to be executed on the TextIO object.
        mode (str, optional): The mode to open the file with. Defaults to "r".

    Returns:
        Any: The result of the callable.

    Raises:
        FileNotFoundError: If the file specified by the path does not exist.
        PermissionError: If the file specified by the path cannot be opened due to insufficient permissions.
        ValueError: If an invalid mode is provided.

    Example:
        >>> def count_lines(file: TextIO) -> int:
        ...     return len(file.readlines())
        >>> file_provider("path/to/file.txt", count_lines)
        10

    Note:
        This function uses the `open` function to open the file with the specified mode.
        The file is automatically closed after the callable is executed.
    """
    with open(path, mode) as f:  # type: ignore
        return call(f)  # type: ignore


def replace_parameters(sql_file: str, params: dict) -> str:
    """Replace placeholders in the SQL file with actual values from params.

    Args:
        sql_file (str): The path to the SQL file with placeholders.
        params (dict): A dictionary of parameters to replace in the SQL file.

    Returns:
        str: The SQL query with replaced parameters.
    """
    try:
        query = file_provider(sql_file, lambda f: "".join(f.readlines()))
    except FileNotFoundError:  # pragma: no cover
        logger.info(f"SQL file not found {sql_file}")
        raise FileNotFoundError

    for key, value in params.items():
        query = query.replace(f"{{{key}}}", str(value))
    return query


def execute_sql_script(spark: SparkSession, sql_file: str, params: dict) -> DataFrame:
    """Execute the given SQL query with parameters and return the result as a DataFrame.

    Args:
        spark (SparkSession): The Spark session to use for executing the query.
        sql_file (str): The path to the SQL file with the query to execute.
        params (dict): A dictionary of parameters to replace in the SQL query.

    Returns:
        DataFrame: The result of the query execution as a Spark DataFrame.
    """
    query = replace_parameters(sql_file, params)
    logger.info(f"this is the query = {query}")
    return spark.sql(query)


# def get_curve_frequency(spark: SparkSession, sql_file: str, params: dict) -> dict:
def get_curve_frequency(df: DataFrame) -> dict:
    """Retrieve the frequency of each curve from the specified Dataframe.

    The function converts DataFrame to a Dictionary.

    Args:
        df (DataFrame): The Spark DataFrame.

    Returns:
        dict: A dictionary with curve names as keys and their corresponding frequencies as values.
    """
    # df = execute_sql_script(spark, sql_file, params)

    # Convert the DataFrame to a list of rows
    rows = df.collect()

    # Convert the list of rows to a dictionary
    data_dict = {row["value_column"]: row["frequency"] for row in rows}

    return data_dict


def get_linear_interpolation(df_source: DataFrame, conf: dict, schema: str) -> DataFrame:
    """Perform linear interpolation on the specified value column of the input DataFrame.

    Args:
        df_source (DataFrame): The input DataFrame containing the source data.
        conf (dict): Configuration dictionary containing column names.
        freq_dict (dict): Dictionary with curve names as keys and their corresponding frequencies as values.
        schema (str): The schema to apply to the resulting DataFrame.

    Returns:
        DataFrame: The DataFrame with interpolated values.
    """

    def interpolation_udf(key: tuple, pdf: pd.DataFrame, key_col: str, date_col: str, value_cols: str) -> pd.DataFrame:
        """Perform linear interpolation on the specified value column of the input DataFrame.

        Args:
            key: The key for the group of data.
            pdf (pd.DataFrame): The input pandas DataFrame.
            key_col (str): The name of the key column.
            date_col (str): The name of the date column.
            value_cols (str): A comma-separated string of value column names to interpolate.
            date_col_freq (str): The frequency for the date range.

        Returns:
            pd.DataFrame: The DataFrame with interpolated values.
        """
        date_col_freq = key[1]
        # Create a copy of the input DataFrame
        df_interpolated = pdf.copy()

        # Sort the DataFrame by the date column
        df_interpolated = df_interpolated.sort_values(by=[date_col])
        df_interpolated = df_interpolated.set_index(date_col)

        # Create date range based on frequency
        df_date_range = pd.date_range(df_interpolated.index.min(), df_interpolated.index.max(), freq=date_col_freq)
        df_interpolated = df_interpolated.reindex(df_date_range)

        # Perform interpolation on each value column
        value_cols_lst = value_cols.split(",")
        value_cols_len = len(value_cols_lst)

        # Iterate over each column in the value columns list
        for col in value_cols_lst:
            # Strip any leading or trailing whitespace from the column name
            value_col = col.strip()

            # Determine the name for the interpolated column
            if value_cols_len == 1:
                value_col_name = "interpolated_value"
            else:
                value_col_name = f"interpolated_{value_col}"

            # Perform linear interpolation on the column and store the result in a new column
            df_interpolated[value_col_name] = df_interpolated[value_col].interpolate("linear")

        df_interpolated[key_col] = key[0]

        # Reset index to convert it back to a column
        df_interpolated = df_interpolated.reset_index().rename(columns={"index": date_col})
        return df_interpolated

    df_interpolated = df_source.groupBy(conf["key_column_name"], conf["key_column_frequency"]).applyInPandas(
        lambda key, pdf: interpolation_udf(
            key, pdf, conf["key_column_name"], conf["date_column_name"], conf["value_column_names"]
        ),
        schema=schema,
    )

    return df_interpolated


def create_table_ddl(
    spark: SparkSession,
    primary_keys: str,
    target_table: str,
    schema: str = "",
    src_table: str = "",
    add_table_id: bool = True,
) -> tuple[str, list[str]]:
    """Generates a Data Definition Language (DDL) string for creating dlt table.

    Args:
        spark (SparkSession): The Spark session to use for executing the query.
        primary_keys (str): A str with comma separate values of primary key column names.
        target_table (str, optional): The name of target table. Defaults to empty.
        schema (str, optional): Schema of the Table as string. Defaults to empty.
        src_table (str, optional): The name of the catalog. Defaults to empty.
        add_table_id (bool, optional): To add auto generated table_id column to the schema.

    Returns:
        tuple[str, list[str]]: A tuple containing a formatted DDL string representing the table structure,
        includes comments and primary keys(if any), and a list of primary key columns.
    """
    # construct primary key string if primary keys are provided
    primary_key_str = ""
    pk = [key for key in primary_keys.replace(" ", "").split(",") if key]
    if any(pk):
        primary_key_str = f", CONSTRAINT pk_{target_table} PRIMARY KEY({', '.join(pk)})"

    result = []
    table_id_suffix_clause = (
        ", table_id BIGINT not null GENERATED BY DEFAULT AS IDENTITY (START WITH 1 INCREMENT BY 1)"
        if add_table_id
        else ""
    )
    # Retrieve schema from schema(if provided in dlt config), otherwise from source table
    if schema:
        result.append(schema)
    else:
        schema = spark.read.table(src_table).schema.json()
        # Parse the schema JSON
        schema_json = json.loads(schema)

        # Build the DDL string from schema fields
        for metadata in schema_json["fields"]:
            # Skip table_id column if add_table_id is True (we'll add our own table_id)
            if add_table_id and metadata["name"] == "table_id":
                continue

            if isinstance(metadata["type"], dict):
                field_type = f"{metadata['type']['type']}<{metadata['type']['elementType']}>"
            else:
                field_type = metadata["type"]
            comment = f" COMMENT '{metadata['metadata']['comment']}'" if "comment" in metadata["metadata"] else ""
            result.append(f"{metadata['name']} {field_type}{comment}")

    # Combine fields and primary key string
    formatted_str = ", ".join(result) + table_id_suffix_clause + primary_key_str

    return formatted_str, pk


def get_validate_dq_constraints(df: DataFrame) -> DataFrame:
    """Validate dq rules available in any of *dq.json files has valid constraint or expression with _drop_ prefix.

    Args:
        df (DataFrame): Source Dataframe having all data quality config rules

    Returns:
        DataFrame
    """
    df = df.withColumn("Expression", f.expr("get_json_object(Constraint, '$.Expression')")).withColumn(
        "Constraint", f.expr("get_json_object(Constraint, '$.Constraint')")
    )

    # Regular expression to find `.alias()` values
    alias_pattern = r"(?<=\.alias\(\')[^']+"

    # Extract cleaned aliases
    df = df.withColumn("aliases", f.regexp_extract(f.col("Expression"), alias_pattern, 0))

    # Check if `Constraint` starts with `_drop_`
    df = df.withColumn("is_constraint_valid", f.when(f.col("Constraint").startswith("_drop_"), True).otherwise(False))

    # Check if the alias starts with `_drop_`
    df = df.withColumn("is_aliases_valid", f.when(f.col("aliases").startswith("_drop_"), True).otherwise(False))

    # Show the final DataFrame
    return df
