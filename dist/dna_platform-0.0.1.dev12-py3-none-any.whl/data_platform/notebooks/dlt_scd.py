# Databricks notebook source
# MAGIC %md
# MAGIC ### Configuration

# COMMAND ----------

import logging
import re
import sys

import dlt  # type: ignore
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col

spark = SparkSession.builder.getOrCreate()
# allow data_platform to be imported
sys.path.append(f"{spark.conf.get('workspace_root_path')}files/src")
from data_platform.common import build_config_json  # noqa: E402
from data_platform.notebooks.dlt_functions import execute_sql_script  # noqa: E402

# COMMAND ----------
logger: logging.Logger
logger = logging.getLogger(__name__)

# COMMAND ----------

catalog_prefix: str = spark.conf.get("catalog_prefix")
schema_prefix: str = spark.conf.get("schema_prefix")
dlt_config_path: str = spark.conf.get("dlt_config")
scd_type: str = spark.conf.get("scd_type", "2")
audit_columns_sql: str = spark.conf.get("audit_columns_sql")
sql_params: dict = {}

# COMMAND ----------
# MAGIC %md
# MAGIC ### Functions


# COMMAND ----------
def create_dlt_table_with_comment(source_table: str, dlt_config: dict[str, str], scd_type: str) -> None:
    """Create a Delta Live Table (DLT) with SCD Type 1 or SCD Type 2 logic.

    Args:
        source_table (str): Name of the source table to read data from.
        dlt_config (dict): Configuration for the DLT table.
        scd_type (str): Either "1" for SCD Type 1 or "2" for SCD Type 2.

    Returns:
        None
    """

    def to_snake_case(name: str) -> str:
        """Convert a string to snake_case."""
        name = re.sub(r"(?<!^)(?=[A-Z])", "_", name).lower()
        return re.sub(r"[^a-zA-Z0-9_]", "_", name)

    target_table_name = dlt_config["target_table_name"]

    # Extract the config and convert to table properties
    table_properties: dict[str, str] = dlt_config.get("table_properties", {})

    file_schema = dlt_config.get("file_schema", None)

    reader_options: dict[str, str] = dlt_config.get("reader_options", {})
    print(f"reader_options = {reader_options}")
    _format = dlt_config.get("file_format", "csv")

    # Create a DLT view for the source table
    view_name = f"{source_table}_view"

    @dlt.view(name=view_name)
    def source_view() -> DataFrame:
        # Read the source table and rename columns to snake_case
        if file_schema:
            df = (
                spark.readStream.format("cloudFiles")
                .option("cloudFiles.format", _format)
                .schema(file_schema)
                .options(**reader_options)
                .load()
            )
            df = df.withColumn("file_name", df["_metadata.file_path"])

        else:
            df = spark.readStream.table(source_table)
        renamed_columns = [col(col_name).alias(to_snake_case(col_name)) for col_name in df.columns]
        df.select(*renamed_columns).createOrReplaceTempView("source_table")
        df_src_data = execute_sql_script(spark, sql_file=audit_columns_sql, params=sql_params)
        return df_src_data

    # Create the DLT table with SCD logic
    dlt.create_streaming_table(
        name=target_table_name,
        comment=dlt_config["comment"],
        table_properties=table_properties,
    )

    # Apply changes based on the selected SCD type
    if scd_type == "1" or scd_type == "2":
        logger.info(f"scd_type = {scd_type}")
        dlt.apply_changes(
            target=target_table_name,
            source=view_name,
            keys=[to_snake_case(key) for key in dlt_config["keys"]],
            sequence_by=col(to_snake_case(dlt_config["sequence_column"])),
            except_column_list=[to_snake_case(col) for col in dlt_config.get("except_columns", [])],
            stored_as_scd_type=scd_type,
        )
    else:
        logger.info("Incorrect SCD type")
        logger.error(f"SCD Type {scd_type} is not supported.")
        sys.exit(1)


# COMMAND ----------
# MAGIC %md
# MAGIC ### Process Configuration and Create Tables

# COMMAND ----------

dlt_config = build_config_json(
    config_path=dlt_config_path, parameters={"catalog_prefix": catalog_prefix, "schema_prefix": schema_prefix}
)
logger.info(f"dlt_config = {dlt_config}")

for _config in dlt_config:
    """ Preparing source data  """
    source_table_name = f"""
        {catalog_prefix}{_config["source_catalog_name"]}.{schema_prefix}{_config["source_schema_name"]}.{_config["source_table_name"]}
    """
    create_dlt_table_with_comment(source_table_name, _config, scd_type)
