# endpoint.py
# endpoint_descriptor.py
from __future__ import annotations

from collections.abc import Callable
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any

Json = dict[str, Any]


@dataclass(slots=True, frozen=True)
class EndpointDescriptor:
    """Pure-data description of an endpoint.

    All callables are optional hooks overriding BaseHttp behavior.
    """

    url: str
    overrides: dict[str, Any] = field(default_factory=dict)

    # hooks -----------------------------------------------------------
    build_param_chunks: Callable[[], list[Json]] | None = None
    build_params: Callable[[Json], Json] | None = None
    build_payload: Callable[[Json], Json] | None = None
    handle_response: Callable[[Any, Any | None], Any] | None = None
    get_file_name: Callable[[Json], str] | None = None


class EndpointExecutorMixin:
    """Adds `_execute_endpoint()` to any subclass of BaseHttpApiClient.

    Assumes the subclass has a dict attribute `_endpoints: dict[str, EndpointDescriptor]`.
    """

    # -----------------------------------------------------------------
    # helpers - capture & restore state
    # -----------------------------------------------------------------
    def _capture_state(self, keys: dict[str, Any]) -> dict[str, Any]:
        return {k: deepcopy(getattr(self, k)) for k in keys}

    def _restore_state(self, saved: dict[str, Any]) -> None:
        for k, v in saved.items():
            setattr(self, k, v)

    # -----------------------------------------------------------------
    # main public helper
    # -----------------------------------------------------------------
    def _execute_endpoint(self, name: str, **call_overrides: Any) -> Any:
        """Run one endpoint described in `self._endpoints[name]`.

        Parameters
        ----------
        name : str
            Key of the EndpointDescriptor in `self._endpoints`.
        **call_overrides :
            The parameters that get overridden are the ones that we make in the requests call:
            - endpoint_url
            - params
            - headers
            - poll_on_empty, poll_interval_sec, poll_timeout_sec
            - chunk_size_days
            - file_volume
            - raise_exception
            - date-window (window lazy evaluation):
                - lookback
                - lookahead
                - datetime_window
                - min_start_datetime
                - max_end_datetime
                - full_load
            if you need to override more, you would need to define another subclass of the Client and override.

        """
        if name not in self._endpoints:
            raise ValueError(f"Unknown endpoint: {name}")

        desc: EndpointDescriptor = self._endpoints[name]

        # ---------------- save current state -------------------------
        attrs_to_touch = set(desc.overrides) | set(call_overrides) | {"endpoint_url"}
        saved_state = self._capture_state(attrs_to_touch)

        try:
            # ---------------- apply overrides -----------------------
            self.endpoint_url = desc.url
            for k, v in (desc.overrides | call_overrides).items():
                setattr(self, k, v)

            # Any change to these keys invalidates the cached window
            if {"lookback", "lookahead", "datetime_window", "min_start_datetime", "max_end_datetime", "full_load"} & (
                desc.overrides.keys() | call_overrides.keys()
            ):
                self._window_needs_update = True

            # ---------------- wire hooks ----------------------------
            if desc.build_param_chunks:
                self.build_param_chunks = desc.build_param_chunks
            if desc.build_params:
                self.build_params = desc.build_params
            if desc.build_payload:
                self.build_payload = desc.build_payload
            if desc.handle_response:
                self.handle_response = desc.handle_response
            if desc.get_file_name:
                self.get_file_name = desc.get_file_name

            # ---------------- run the reader ------------------------
            return self.execute()  # inherited from BaseHttp

        finally:
            # --------------- restore original state -----------------
            self._restore_state(saved_state)
