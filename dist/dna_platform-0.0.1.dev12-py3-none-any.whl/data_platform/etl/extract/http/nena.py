# data_platform/etl/extract/http/nena.py
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from data_platform.etl.extract.http.async_http_api_client import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin


@dataclass(kw_only=True)
class NenaApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Nena API client for fetching production data."""

    context: Any
    credentials: Any

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url: str = "https://energy-api.stormgeo.com/api/v1/"

    extra_url: str

    series_id: str
    from_dt: date | None = None
    to_dt: date | None = None
    resolution: str = ""

    def __post_init__(self) -> None:
        """Postinit."""
        super().__post_init__()
        self._register_endpoints()

    @staticmethod
    def _month_intervals(start: datetime, end: datetime) -> list[tuple[datetime, datetime]]:
        intervals = []
        s = start
        while s < end:
            # Start of next month
            if s.month == 12:
                n = s.replace(year=s.year + 1, month=1, day=1)
            else:
                n = s.replace(month=s.month + 1, day=1)
            e = min(n, end)
            intervals.append((s, e))
            s = e
        return intervals

    def _register_endpoints(self) -> None:
        self._endpoints = {
            "fundamental_meta": EndpointDescriptor(
                url=f"{self._base_url}fundamental/meta",
                build_param_chunks=lambda: [""],
                build_params=lambda chunk: {
                    "SeriesId": self.series_id,
                    "UserInfo": self.credentials.fetch_token(timeout=self.timeout_sec, verify=self.verify),
                },
            ),
            "fundamental_series": EndpointDescriptor(
                url=f"{self._base_url}fundamental/series",
                build_param_chunks=lambda: [""],
                build_params=lambda chunk: {
                    "FromDateTime": self.from_dt.strftime("%Y-%m-%d"),
                    "ToDateTime": self.to_dt.strftime("%Y-%m-%d"),
                    "Resolution": self.resolution,
                    "SeriesId": self.series_id,
                    "UserInfo": self.credentials.fetch_token(timeout=self.timeout_sec, verify=self.verify),
                },
            ),
            "data": EndpointDescriptor(
                url=f"{self._base_url}/{self.extra_url}",
                build_param_chunks=lambda: [""],
                build_params=lambda chunk: {
                    "FromDateTime": self.from_dt.strftime("%Y-%m-%d"),
                    "ToDateTime": self.to_dt.strftime("%Y-%m-%d"),
                    "Resolution": self.resolution,
                    "SeriesId": self.series_id,
                    "UserInfo": self.credentials.fetch_token(timeout=self.timeout_sec, verify=self.verify),
                },
            ),
        }

    def get_fundamental_metadata(self, **ovr: Any) -> Any:
        """Fetch fundamental metadata."""
        return self._execute_endpoint("fundamental_meta", **ovr)

    def get_fundamental_series(self, **ovr: Any) -> Any:
        """Fetch fundamental timeseries."""
        return self._execute_endpoint("fundamental_series", **ovr)

    def get_data(self, **ovr: Any) -> Any:
        """Fetch data."""
        return self._execute_endpoint("data", **ovr)
