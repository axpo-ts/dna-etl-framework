from __future__ import annotations

import time
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from typing import Any

from dateutil.relativedelta import relativedelta
from pyspark import TaskContext

from data_platform.data_model.file_volume_identifier import FileVolumeIdentifier
from data_platform.etl.auth.token_provider import TokenProvider
from data_platform.etl.extract.http.async_http_api_client import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin


@dataclass(kw_only=True)
class FingridDataApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Fingrid API client for extracting data from Fingrid datasets."""

    context: TaskContext
    credentials: TokenProvider | None = None
    file_volume: str | FileVolumeIdentifier | None = None
    datetime_window: tuple[datetime, datetime] | None = None
    chunk_size_days: int
    chunk_size_months: int
    datetime_name_params: tuple[str, str] = ("startTime", "endTime")
    timeout_sec: float = 10.0
    max_workers: int = 3
    input_chunks: list[dict[str, Any]] | None = None  # used for retry, else None

    dataset_id_list: list[str] | str | None = None
    page_index: int
    page_size: int | None = None
    dataset_id_list_nextpage: list[str] = field(default_factory=list)  # subset which requires next page handling
    min_seconds_per_call: float = 2.0  # seconds - choose larger for full load to avoid overloading the API.

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url_prefix: str = "https://data.fingrid.fi/api/datasets/"

    _response_metadata: dict[str, dict[str, Any]] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        """Initialize the Fingrid client with headers and endpoints."""
        self.headers = {
            **(self.headers or {}),
            "x-api-key": self.credentials.api_key,
        }

        super().__post_init__()
        self._register_endpoints()

    def _fingrid_build_param_chunks(self) -> list[dict[str, Any]]:
        """Build parameter chunks for date-based pagination.

        Creates one chunk per day within the datetime window, with pagination params.

        Returns:
            List of parameter dictionaries for API requests.
        """
        # if chunks are provided (e.g. for retry), return the input chunks.
        if self.input_chunks is not None:
            return self.input_chunks

        # prefer executor-computed window if available
        if hasattr(self, "_ensure_window"):
            try:
                self._ensure_window()
                start = getattr(self, "_window_start", None)
                end = getattr(self, "_window_end", None)
            except Exception:
                start, end = self.datetime_window or (None, None)
        else:
            start, end = self.datetime_window or (None, None)

        if not start or not end:
            raise ValueError("datetime_window (start, end) must be provided to build chunks")

        def to_dt(v: Any) -> datetime:
            if isinstance(v, datetime):
                return v
            if isinstance(v, str):
                return datetime.fromisoformat(v)
            raise TypeError("Unsupported datetime type for chunking")

        start_dt = to_dt(start)
        end_dt = to_dt(end)

        if end_dt <= start_dt:
            raise ValueError("datetime_window end must be after start")

        sname, ename = self.datetime_name_params

        # check if one month jumps is active - otherwise use chunk_size_days
        chunks: list[dict[str, Any]] = []
        cur = start_dt
        while cur < end_dt:
            nxt = min(cur + timedelta(days=self.chunk_size_days) + relativedelta(months=self.chunk_size_months), end_dt)

            chunk: dict[str, Any] = {
                sname: cur.isoformat(),
                ename: nxt.isoformat(),
            }

            # Add dataset_id to chunk so _save() can extract it
            if hasattr(self, "dataset_id") and self.dataset_id:
                chunk["dataset_id"] = str(self.dataset_id)

            # Include pagination params - use override if provided
            effective_page_index = getattr(self, "page_index", None)
            if effective_page_index is not None:
                chunk["page"] = effective_page_index
            if getattr(self, "page_size", None) is not None:
                chunk["pageSize"] = self.page_size

            chunks.append(chunk)
            cur = nxt

        return chunks

    def _register_endpoints(self) -> None:
        """Register endpoints for each dataset ID in dataset_id_list."""
        endpoints: dict[str, EndpointDescriptor] = {}

        for ds in self.dataset_id_list or []:
            url = f"{self._base_url_prefix}{ds}/data/"

            # Store dataset_id so chunks can access it
            self.dataset_id = ds

            endpoints[str(ds)] = EndpointDescriptor(
                url=url,
                build_param_chunks=self._fingrid_build_param_chunks,
                get_file_name=lambda chunk, _ds=ds: (
                    f"/{_ds}/{chunk['startTime']}-{chunk['endTime']}/"
                    f"{datetime.now(UTC).strftime('%Y-%m-%dT%H%M%S')}_page_{self.page_index}.json"
                ),
            )

        self._endpoints.update(endpoints)

    def _save(self, response_data: Any, *, chunk: dict[str, Any] | None = None) -> None:
        """Save to file AND collect pagination metadata.

        Args:
            response_data: Processed response data.
            chunk: Request chunk parameters.
        """
        # Call parent to write files
        super()._save(response_data, chunk=chunk)

        # Extract and store pagination metadata
        try:
            if isinstance(response_data, dict) and chunk:
                dataset_id = str(chunk.get("dataset_id", "unknown"))
                pagination = response_data.get("pagination", {})

                self._response_metadata[dataset_id] = {
                    "pagination": pagination,
                    "record_count": len(response_data.get("data", [])),
                }

                # Track datasets needing more pages
                if isinstance(pagination, dict) and pagination.get("nextPage"):
                    if dataset_id not in self.dataset_id_list_nextpage:
                        self.dataset_id_list_nextpage.append(dataset_id)
        except Exception as e:
            self.context.logger.warning(f"Failed to extract pagination metadata: {e}")

    def get_all_data(self, **ovr: Any) -> dict[str, Any]:
        """Execute endpoints and return pagination metadata.

        Each endpoint execution is rate-limited to take at least `min_seconds_per_call` seconds
        (default: 2.0, scheduled: 5.0, full load: 60.0) to comply with API usage policies.
        The rate limiting duration can be configured via the `min_seconds_per_call` parameter.

        Args:
            **ovr: Override parameters to merge into request chunks.

        Returns:
            Dict mapping dataset_id to pagination metadata:
            {
                "dataset_id": {
                    "pagination": {...},
                    "record_count": int
                }
            }
        """
        min_seconds_per_call = self.min_seconds_per_call  # Minimum number of seconds per call of get_all_data

        for name in list(self._endpoints.keys()):
            # Record start time
            start_time = time.time()

            self.context.logger.info(
                f"Starting execution for endpoint '{name}' at {datetime.now(UTC).strftime('%Y-%m-%d %H:%M:%S')}"
            )

            # Execute endpoint
            self._execute_endpoint(name, **ovr)

            # Calculate elapsed time
            elapsed_time = time.time() - start_time

            self.context.logger.info(f"Endpoint '{name}' completed in {elapsed_time:.2f} seconds")

            # Sleep if execution took less than minimum time
            if elapsed_time < min_seconds_per_call:
                sleep_time = min_seconds_per_call - elapsed_time
                self.context.logger.info(
                    f"Rate limiting: sleeping for {sleep_time:.2f} seconds "
                    f"to meet minimum execution time of {min_seconds_per_call} seconds"
                )
                time.sleep(sleep_time)
            else:
                self.context.logger.info(
                    f"Endpoint '{name}' execution time ({elapsed_time:.2f}s) "
                    f"exceeded minimum threshold ({min_seconds_per_call}s), "
                    f"no rate limiting applied"
                )

        return self._response_metadata  # Returns data about pagination and record counts

    @property
    def failed_chunks(self) -> list[Any]:
        """Get list of chunks that failed during execution.

        Returns:
            List of failed chunk parameters.

        Example:
            >>> client = FingridDataApiClient(...)
            >>> client.get_all_data()
            >>> if client.failed_chunks:
            ...     logger.error(f"Failed chunks: {client.failed_chunks}")
        """
        # Access parent class attribute directly - it's populated during _execute_endpoint
        return getattr(self, "_failed_chunks", [])


@dataclass(kw_only=True)
class FingridAttributeApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """Fingrid API client for extracting attribute from Fingrid datasets."""

    context: TaskContext
    credentials: TokenProvider | None = None
    file_volume: str | FileVolumeIdentifier | None = None
    timeout_sec: float = 10.0
    max_workers: int = 3

    dataset_id_list: list[str] | str | None = None

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url_prefix: str = "https://data.fingrid.fi/api/datasets/"

    def __post_init__(self) -> None:
        """Convert dataset_id_list to list and set headers."""
        self.headers = {**(self.headers or {}), "x-api-key": self.credentials.api_key}

        super().__post_init__()
        self._register_endpoints()

    def _register_endpoints(self) -> None:
        endpoints: dict[str, EndpointDescriptor] = {}
        for ds in self.dataset_id_list or []:
            url = f"{self._base_url_prefix.rstrip('/')}/{ds}/"
            endpoints[str(ds)] = EndpointDescriptor(
                url=url,
                get_file_name=lambda chunk, _ds=ds: (f"/{_ds}/{datetime.now(UTC).strftime('%Y-%m-%dT%H%M%S')}.json"),
            )
        self._endpoints = endpoints

    def get_all_data(self, **ovr: Any) -> dict[str, Any]:
        """Execute each registered attribute endpoint and return mapping id -> result."""
        results: dict[str, Any] = {}
        for name in list(self._endpoints.keys()):
            results[name] = self._execute_endpoint(name, **ovr)
        return results
