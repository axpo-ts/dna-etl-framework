import urllib

import requests


class SharepointClient:
    """Used to set self.sql_server_name and self.sql_database_name at class initialization.

    :param site_id: Sharepoint site ID in this format: {spsite-id}
        (example: b532bcf2-4057-4293-9dc4-8c773e1ec54b)
        - {spsite-id} can be retrieved in couple of ways:
            - if you have access to that Sharepoint site you can use
                    https://developer.microsoft.com/en-us/graph/graph-explorer
                    and use search sites endpoint to find IDs for your site
            - or by visiting this URL:
                - https://axpogrp.sharepoint.com/sites/SUPTFarcasterFactory/_api/site/id
    :param base_path: base path to Sharepoint folder (example: General/Market Risk)
    """

    def __init__(self, *, token: str, site_id: str, base_path: str = "", timeout: int = 60) -> None:
        """Sharepoint initialization."""
        self.token = token
        self.site_id = site_id
        self.base_path = base_path
        self.timeout = timeout
        self.headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
        }

    def _normalize_path(self, relative_path: str) -> str:
        parts = [p for p in [self.base_path, relative_path] if p]
        # Encode each segment to avoid encoding slashes
        return "/".join(urllib.parse.quote(p.strip("/")) for p in parts)

    def _session(self) -> requests.Session:
        s = requests.Session()
        s.headers.update(self.headers)
        return s

    def list_children_items_in_sharepoint_path(self, relative_path: str | None = None) -> list:
        """This method lists children items in SharePoint path.

        :param relative_path: Relative path to SharePoint folder
            (if not provided, base_path from parent class is used).
        """
        path = self._normalize_path(relative_path)
        url = f"https://graph.microsoft.com/v1.0/sites/{self.site_id}/drive/root:/{path}:/children"
        results: list[dict] = []
        with self._session() as s:
            while url:
                res = s.get(url, timeout=self.timeout)
                try:
                    res.raise_for_status()
                except requests.HTTPError as e:
                    raise RuntimeError(f"List children failed: {e}, body={res.text}") from e
                payload = res.json()
                results.extend(payload.get("value", []))
                url = payload.get("@odata.nextLink")
        return results

    def download_files_from_sharepoint(self, file_extension: str, relative_path: str | None = None) -> dict:
        """This method downloads files from Sharepoint folder path.

        :param file_extension: makes sure that only files with a targeted file extension are being downloaded
        :param relative_path: relative path to sharepoint folder
            (if not provided, it will take base_path from parent class)

        Returns dictionary with filename as keys and file content as value: { "filename": "filecontent", ... }
        """
        files_content: dict[str, bytes] = {}
        files = self.list_children_items_in_sharepoint_path(relative_path)

        with self._session() as s:
            for f in files:
                name = f.get("name", "")
                if not name.endswith(file_extension):
                    continue

                url = f.get("@microsoft.graph.downloadUrl")
                if not url:
                    continue

                resp = s.get(url, timeout=self.timeout, stream=True)
                resp.raise_for_status()
                files_content[name] = resp.content

        return files_content
