import json
import zipfile
from dataclasses import dataclass
from io import BytesIO
from typing import Any

import requests

from data_platform.data_model import FileVolumeIdentifier
from data_platform.etl.etl_task import ETLTask


@dataclass(kw_only=True)
class MeteologicaApiClient(ETLTask):
    """Base Client for Meteologica API endpoints.

    We need to retrieve a token that will expire every 30 minutes and include it in calls.
    """

    token: str | None = None

    def __post_init__(self) -> None:
        """Initialize the Meteologica API client."""
        self.meteologica_base_url = "https://api-markets.meteologica.com/api/v1"

        if not self.token:
            raise ValueError("Token is required for MeteologicaApiClient initialization.")

    # PUBLIC API INTERFACE
    def get_contents(self) -> dict:
        """Retrieve all available content from Meteologica API."""
        api_url = f"{self.meteologica_base_url}/contents"

        headers = {"Authorization": f"Bearer {self.token}"}

        self.context.logger.info("Retrieving contents from Meteologica API")

        try:
            response = requests.get(api_url, params={"token": self.token}, headers=headers)

            if response.status_code == 200:
                data = response.json()
                self.context.logger.info("Contents retrieved successfully")
                return data
            else:
                self.context.logger.error("Failed to retrieve contents: %s %s", response.status_code, response.text)
                raise Exception(f"Connection failed: {response.status_code} {response.text}")
        except requests.RequestException as e:
            self.context.logger.error("Request failed: %s", e)
            raise

    def get_content_data(self, content_id: int) -> dict:
        """Retrieve data for a specific content ID from Meteologica API."""
        api_url = f"{self.meteologica_base_url}/contents/{content_id}/data"
        self.context.logger.info("Retrieving data for content ID %s", content_id)

        try:
            response = requests.get(api_url, params={"token": self.token})

            if response.status_code == 200:
                data = response.json()
                self.context.logger.info("Data retrieved successfully for content ID %s", content_id)
                return data
            else:
                self.context.logger.error("Failed to retrieve data: %s %s", response.status_code, response.text)
                raise Exception(f"Connection failed: {response.status_code} {response.text}")
        except requests.RequestException as e:
            self.context.logger.error("Request failed: %s", e)
            raise

    def save_json_file(self, data: dict[str, Any], volume: FileVolumeIdentifier) -> None:
        """Save JSON content to the specified folder path."""
        # Use the provided volume identifier
        volume_path = self.context.full_file_name(volume)
        self.context.logger.info(f"Volume path: {volume_path}")

        self.context.dbutils.fs.mkdirs(volume_path)
        self.context.logger.info(f"Folder created: {volume_path}")

        if not volume_path.endswith("/"):
            volume_path += "/"

        self.context.logger.info(f"/ added to path: {volume_path}")

        filename = f"{data['content_id']}_{data['update_id']}.json"
        full_path = f"{volume_path}{filename}"

        self.context.logger.info(f"full path created: {full_path}")

        try:
            json_data = json.dumps(data)
            self.context.dbutils.fs.put(full_path, json_data, overwrite=True)
            self.context.logger.info(f"Saved JSON file: {full_path}")
        except Exception as e:
            self.context.logger.error(f"Failed to save file {full_path}: {e}")
            raise

    def check_new_update(self, content_id: int, volume_path: str) -> bool:
        """Check if there is a new update for a specific content ID."""
        updates = self._get_content_updates(content_id)
        sorted_updates = sorted(updates, key=lambda x: x["update_id"])
        self.context.logger.info(f"Latest update for content ID {content_id}: {sorted_updates}")
        updates = self.context.spark.createDataFrame(updates).distinct().orderBy("issue_date", ascending=False)
        most_recent_update_id = updates.first()["update_id"]

        file_name = f"{content_id}_{most_recent_update_id}.json"

        # Check if the file already exists in the specified volume path
        try:
            files = self.context.dbutils.fs.ls(volume_path)
            existing_files = [file.name for file in files]
            self.context.logger.info(f"Existing files in {volume_path}: {existing_files}")
            if file_name in existing_files:
                self.context.logger.info(f"File {file_name} already exists in {volume_path}")
                return False
            else:
                self.context.logger.info(f"File {file_name} does not exist in {volume_path}")
                return True
        except Exception as e:
            self.context.logger.error(f"Failed to check files in {volume_path}: {e}")
            raise

    def execute(self) -> None:
        """Execute the meteologica client task.

        This method is currently a placeholder and needs implementation.
        """
        pass

    def execute_historical(
        self,
        content_id: int,
        yearmonth_from: str,
        yearmonth_to: str,
        content_volume: FileVolumeIdentifier,
    ) -> None:
        """Execute historical data retrieval for a specific content ID.

        Args:
            content_id: The ID of the content to retrieve.
            yearmonth_from: Start year and month in 'YYYYMM' format.
            yearmonth_to: End year and month in 'YYYYMM' format.
            content_volume: File volume identifier for saving data.
        """
        self.context.logger.info(
            f"Fetching historical data for content ID {content_id} from {yearmonth_from} to {yearmonth_to}"
        )

        # Parse yearmonth_from and yearmonth_to into integers
        year_from = int(yearmonth_from[:4])
        year_to = int(yearmonth_to[:4])
        month_from = int(yearmonth_from[-2:])
        month_to = int(yearmonth_to[-2:])

        year_months = [
            f"{year}/{month:02d}"
            for year in range(year_from, year_to + 1)
            for month in range(1, 13)
            if not (year == year_to and month > month_to) and not (year == year_from and month < month_from)
        ]

        for year_month in year_months:
            self.context.logger.info(f"Processing {year_month} for content_id {content_id}")

            try:
                response = self._fetch_historical_data(content_id, year_month)
                self._save_historical_data(response, year_month, content_volume)
            except Exception as e:
                self.context.logger.error(f"Failed to process {year_month} for content_id {content_id}: {e}")
                continue

    # PRIVATE COMPONENTS

    def _fetch_historical_data(self, content_id: int, year_month: str) -> requests.Response:
        """Fetch historical data for a specific content ID and year/month.

        Args:
            content_id: The ID of the content to retrieve.
            year_month: Year and month in 'YYYY/MM' format.

        Returns:
            HTTP response from the API.

        Raises:
            RuntimeError: If API request fails.
        """
        api_url = f"{self.meteologica_base_url}/contents/{content_id}/historical_data/{year_month}"
        self.context.logger.info(f"Fetching historical data from API: {api_url}")

        try:
            response = requests.get(api_url, params={"token": self.token})
            return response
        except requests.RequestException as e:
            self.context.logger.error(f"Request failed for {year_month}: {e}")
            raise RuntimeError(f"Failed to fetch historical data for {year_month}") from e

    def _save_historical_data(
        self, response: requests.Response, year_month: str, content_volume: FileVolumeIdentifier
    ) -> None:
        """Save historical data response to volume storage.

        Args:
            response: HTTP response containing ZIP data.
            year_month: Year and month in 'YYYY/MM' format.
            content_volume: File volume identifier for saving data.

        Raises:
            RuntimeError: If saving data fails.
        """
        if response.status_code != 200:
            self.context.logger.error(f"Failed to fetch data for {year_month}: HTTP {response.status_code}")
            return

        try:
            # Parse the response content
            unzipped_files = self._parse_zipped_response(response)

            if not unzipped_files:
                self.context.logger.warning(f"No data found for {year_month}")
                return

            # Prepare target folder path
            base_path = self.context.full_file_name(content_volume)

            if not base_path.endswith("/"):
                base_path += "/"

            target_folder = f"{base_path}historical/{year_month.replace('/', '_')}/"

            # Ensure folder exists
            self.context.dbutils.fs.mkdirs(target_folder)

            # Save each file from the ZIP
            for file_name, file_content in unzipped_files.items():
                full_path = f"{target_folder}{file_name}"
                json_data = json.dumps(file_content)
                self.context.dbutils.fs.put(full_path, json_data, overwrite=True)
                self.context.logger.info(f"Saved {file_name} to {target_folder}")

        except Exception as e:
            self.context.logger.error(f"Failed to save data for {year_month}: {e}")
            raise RuntimeError(f"Failed to save historical data for {year_month}") from e

    def _parse_zipped_response(self, response: requests.Response) -> dict[str, Any]:
        """Parse a zipped HTTP response and extract JSON files.

        Args:
            response: HTTP response containing ZIP data.

        Returns:
            Dictionary mapping file names to their JSON content.
        """
        unzipped_files = {}

        with zipfile.ZipFile(BytesIO(response.content), "r") as zip_ref:
            for file_name in zip_ref.namelist():
                with zip_ref.open(file_name) as file:
                    unzipped_files[file_name] = json.load(file)

        return unzipped_files

    def _get_content_updates(self, content_id: int) -> dict:
        """Retrieve updates for a specific content ID from Meteologica API."""
        api_url = f"{self.meteologica_base_url}/contents/{content_id}/updates"

        self.context.logger.info("Retrieving updates for content ID %s", content_id)
        try:
            response = requests.get(api_url, params={"token": self.token})

            if response.status_code == 200:
                data = response.json()
                self.context.logger.info("Updates retrieved successfully for content ID %s", content_id)
                return data["updates"]
            else:
                self.context.logger.error("Failed to retrieve updates: %s %s", response.status_code, response.text)
                raise Exception(f"Connection failed: {response.status_code} {response.text}")
        except requests.RequestException as e:
            self.context.logger.error("Request failed: %s", e)
            raise
