from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, Literal

import httpx

from data_platform.etl.extract.http.base_http_api_client import BaseHttpApiClient


@dataclass(kw_only=True)
class SyncHttpApiClient(BaseHttpApiClient):
    """Synchronous HTTP API reader implementation."""

    http_method: Literal["GET", "POST"] = "GET"
    _session: httpx.Client | None = field(init=False, default=None, repr=False)
    task_name: str = field(init=False, default="SyncHttpApiClient")

    def __post_init__(self) -> None:
        """Initialize the synchronous HTTP client."""
        super().__post_init__()
        self._create_session()

    def _create_session(self) -> None:
        """Create a new HTTP session with specified parameters."""
        self._session = httpx.Client(
            timeout=self.timeout_sec,
            verify=self.verify,
            headers=self.headers,
        )

    def refresh_session(self) -> None:
        """Close and recreate the HTTP session (connection pool)."""
        if self._session:
            self._session.close()
        self._create_session()

    def close_session(self) -> None:
        """Close the HTTP session and release resources."""
        if self._session:
            self._session.close()

    def _do_request(self, *, params: dict[str, Any] | None, payload: dict[str, Any] | None = None) -> httpx.Response:
        self._ensure_valid_token()
        verb = self.http_method.upper()

        @self.retry
        def _call() -> httpx.Response:
            if verb == "GET":
                resp = self._session.get(self.endpoint_url, headers=self.headers, params=params)
            elif verb == "POST":
                resp = self._session.post(
                    self.endpoint_url,
                    headers=self.headers,
                    params=params,  # still allow query params
                    json=payload,  # send JSON body by default
                )
            else:
                raise ValueError(f"Unsupported http_method={self.http_method!r}")
            resp.raise_for_status()
            return resp

        return _call()

    def _poll_until_data_sync(
        self,
        call_fn: Callable,  # callable -> HttpResponse
        *,
        chunk: Any | None = None,
    ) -> Any:
        """Synchronously poll until payload is non-empty or timeout."""
        start = time.monotonic()
        while True:
            resp = call_fn()
            data = self._extract_content(resp)
            if not self._is_empty_payload(data):
                return data

            elapsed = time.monotonic() - start
            if elapsed >= self.poll_timeout_sec:
                self.context.logger.warning(f"Polling timeout reached (no data) | chunk={chunk}")
                return data

            self.context.logger.debug(f"No data yet - retrying in {self.poll_interval_sec}s | chunk={chunk}")
            time.sleep(self.poll_interval_sec)

    def _process(self, chunk: Any) -> None:
        api_params = self.build_params(chunk=chunk)
        api_payload = self.build_payload(chunk=chunk)
        if self.poll_on_empty:
            raw = self._poll_until_data_sync(
                lambda: self._do_request(params=api_params, payload=api_payload),
                chunk=chunk,
            )
        else:
            raw = self._extract_content(self._do_request(params=api_params, payload=api_payload))

        record = self.handle_response(raw, chunk=chunk)
        self._save(record, chunk=chunk)

    def execute(self) -> None | list[Any] | Any:
        """Execute the synchronous HTTP API reader.

        Returns:
            None | list[Any] | Any: Check parents docstring for details.
        """
        for it in self.build_param_chunks():
            try:
                self._process(it)
            except Exception as exc:
                self.context.logger.warning(f"chunk {it} failed: {exc}")
                self._failed_chunks.append(it)
        self.context.logger.info(
            f"Sync finished | ok={len(self.build_param_chunks()) - len(self._failed_chunks)}"
            f" ko={len(self._failed_chunks)}"
        )
        if self.raise_exception and self._failed_chunks:
            raise ValueError(f"Some chunks failed during processing: {self._failed_chunks}")

        if self.file_volume is None:
            # Return collected responses if file_volume is not set
            if len(self._collected_responses) == 1:
                self._collected_responses = self._collected_responses[0] if self._collected_responses else []
            return self._collected_responses
        return None
