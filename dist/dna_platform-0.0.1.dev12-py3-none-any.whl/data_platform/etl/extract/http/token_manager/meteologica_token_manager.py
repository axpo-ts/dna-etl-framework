import logging

import requests


class MeteologicaTokenManager:
    """Token manager for Meteologica API authentication.

    Handles token requests and authentication with the Meteologica API service.
    """

    def request_new_token(self, catalog_prefix: str) -> dict:
        """Request a new token from Meteologica API."""
        # to run streams in databricks we can't serialize dbutils, so we import it here
        from databricks.sdk.runtime import dbutils

        logger = logging.getLogger(__name__)

        meteologica_username = dbutils.secrets.get(f"{catalog_prefix}secretscope", "meteologica-api-username")
        meteologica_password = dbutils.secrets.get(f"{catalog_prefix}secretscope", "meteologica-api-password")

        url = "https://api-markets.meteologica.com/api/v1/login"
        payload = {"password": meteologica_password, "user": meteologica_username}
        headers = {"Content-Type": "application/json"}

        logger.info("Authenticating with Meteologica API at %s", url)
        try:
            response = requests.post(url, json=payload, headers=headers, verify=False)
            response.raise_for_status()  # Raise an exception for bad status codes
            token_dict = response.json()
            return token_dict
        except requests.RequestException as e:
            logger.error("Authentication failed: %s", e)
            raise
