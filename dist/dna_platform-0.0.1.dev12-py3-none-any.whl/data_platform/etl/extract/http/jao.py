# data_platform/etl/extract/http/jao.py
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import timedelta
from typing import Any

from data_platform.etl.extract.http.async_http_api_client import AsyncHttpApiClient
from data_platform.etl.extract.http.endpoint import EndpointDescriptor, EndpointExecutorMixin


@dataclass(kw_only=True)
class JaoApiClient(EndpointExecutorMixin, AsyncHttpApiClient):
    """JAO API client for fetching auction and bid data.

    This client supports fetching auction data in chunks and bids for each auction.
    """

    context: Any
    credentials: Any
    file_volume: Any
    datetime_window: tuple[Any, Any] | None = None
    lookback: timedelta = timedelta(days=7)
    full_load: bool = False
    datetime_name_params: tuple[str, str] = ("fromdate", "todate")
    max_workers: int = 3
    timeout_sec: float = 30.0

    _endpoints: dict[str, EndpointDescriptor] = field(init=False, default_factory=dict)
    _base_url: str = "https://api.jao.eu/OWSMP/"

    task_name: str = field(init=False, default="JaoApiClient")

    def __post_init__(self) -> None:
        """Initialize the JAO client with headers and endpoints."""
        self.headers = {**(self.headers or {}), "AUTH_API_KEY": self.credentials.api_key}

        super().__post_init__()
        self._register_endpoints()

    def is_http_status_success(self, status_code: int) -> bool:
        """Check if the HTTP status code indicates success."""
        return status_code == 400

    def _register_endpoints(self) -> None:
        """Register endpoints for auctions and bids."""
        self._endpoints = {
            "auctions": EndpointDescriptor(
                url=f"{self._base_url}getauctions",
                overrides={"chunk_size_days": 7, "lookahead": timedelta(days=30)},
                get_file_name=lambda chunk: f"/{chunk['fromdate']}-{chunk['todate']}/auctions.json",
            ),
            "bids": EndpointDescriptor(
                url=f"{self._base_url}getbids",
                overrides={"lookahead": timedelta(days=2), "chunk_size_days": -1},
                build_param_chunks=self._bids_build_param_chunks,
                handle_response=self._bids_handle_response,
                get_file_name=lambda chunk: f"/{chunk['auctionid']}/bids.json",
            ),
        }

    def _bids_build_param_chunks(self) -> list[dict[str, Any]]:
        """Build items from auction volume scan."""
        # refresh the date window *after* the endpoint overrides were applied
        self._ensure_window()

        auction_vol_path = self._volume_path.replace("bids", "auction/*")
        auctions_df = self.context.spark.read.json(auction_vol_path)

        if not self.full_load:
            auction_ids = (
                auctions_df.filter(  # Filter the ones that are inside this interval and get the IDs
                    (auctions_df.marketPeriodStop <= self._window_end)
                    & (auctions_df.marketPeriodStart >= self._window_start)
                )
                .select("identification")
                .distinct()
                .collect()
            )
            auction_ids = [row.identification for row in auction_ids]
        else:
            auction_ids = [row.identification for row in auctions_df.select("identification").distinct().collect()]

        return [{"auctionid": auction_id, **(self.params or {})} for auction_id in auction_ids]

    def _bids_handle_response(self, response_data: Any, *, chunk: Any | None = None) -> Any:
        """Attach auction ID to each bid."""
        if not chunk or "auctionid" not in chunk:
            raise ValueError("Item with auctionid is required")

        if not isinstance(response_data, list):
            if response_data.get("status") == 400:
                self.context.logger.warning(f"Status 400 for chunk {chunk}: {response_data['message']}")
                return []
        for bid in response_data:
            bid["auctionID"] = chunk["auctionid"]

        return response_data

    def get_auctions(self, **ovr: Any) -> Any:
        """Fetch auction data with optional overrides."""
        return self._execute_endpoint("auctions", **ovr)

    def get_bids(self, **ovr: Any) -> Any:
        """Fetch bids data with optional overrides."""
        return self._execute_endpoint("bids", **ovr)
