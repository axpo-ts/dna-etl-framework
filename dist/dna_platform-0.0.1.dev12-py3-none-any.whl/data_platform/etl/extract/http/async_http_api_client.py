from __future__ import annotations

import asyncio
import time
from collections.abc import Awaitable
from dataclasses import dataclass, field
from typing import Any, Literal, TypeVar, cast

import httpx
import nest_asyncio

from data_platform.etl.extract.http.base_http_api_client import BaseHttpApiClient, HttpResponse


def _run_coroutine_blocking(coro: Awaitable[TypeVar]) -> None:
    """Run an *async* coroutine from **synchronous** code and return its result.

    Scenarios
    ---------
    • **Regular Python script** (no event-loop running)
      - Internally calls `asyncio.run(coro)` which *creates* a new loop,
        runs the coroutine to completion, then closes the loop.

    • **Databricks / Jupyter / any environment with an already-running loop**
      - Detects the active loop with `asyncio.get_running_loop()`.
      - Uses `asyncio.run_coroutine_threadsafe()` to schedule `coro` on that loop
        and **blocks the current thread** until `coro` finishes (`fut.result()`).

    The calling code therefore behaves like a normal blocking function in both
    environments, even though the underlying I/O remains asynchronous.
    """
    nest_asyncio.apply()
    loop = asyncio.get_event_loop()
    if loop.is_running():
        # Databricks Notebook environment has a already loop
        result = loop.create_task(coro)
        loop.run_until_complete(result)
    else:
        # Standard Python environment
        asyncio.run(coro)


@dataclass(kw_only=True)
class AsyncHttpApiClient(BaseHttpApiClient):
    """Asynchronous HTTP API reader implementation."""

    http_method: Literal["GET", "POST"] = "GET"
    max_workers: int = 10
    _session: httpx.AsyncClient | None = field(init=False, default=None, repr=False)
    _lock: asyncio.Lock = field(init=False, default_factory=asyncio.Lock, repr=False)
    task_name: str = field(init=False, default="AsyncHttpApiClient")

    def __post_init__(self) -> None:
        """Initialize the asynchronous HTTP client."""
        super().__post_init__()
        self._create_session()

    def _create_session(self) -> None:
        limits = httpx.Limits(
            max_connections=self.max_workers,
            max_keepalive_connections=self.max_workers,
        )
        self._session = httpx.AsyncClient(
            http2=True,
            limits=limits,
            verify=self.verify,
            headers=self.headers,
        )

    async def _aclose(self) -> None:
        """Close the underlying AsyncClient (non-blocking)."""
        async with self._lock:
            if self._session is not None:
                await self._session.aclose()
                self._session = None

    async def _refresh_session(self) -> None:
        """Refresh the client without blocking the event-loop caller."""
        async with self._lock:
            await self._aclose()
            self._create_session()

    # ──────────────────────────────────────────────────────────────────
    # public helpers
    # ──────────────────────────────────────────────────────────────────

    def refresh_session(self) -> None:
        """Refresh the HTTP client and **block** until done.

        Call from synchronous code: `client.refresh_session()`.
        """
        _run_coroutine_blocking(self._refresh_session())

    def close_session(self) -> None:
        """Close the HTTP client and **block** until it is fully shut down."""
        _run_coroutine_blocking(self._aclose())

    # ────────────────────────────────────────────────
    # async polling helper
    # ────────────────────────────────────────────────
    async def _poll_until_data_async(
        self,
        client: httpx.AsyncClient,
        *,
        chunk: Any,
    ) -> Any:
        start = time.monotonic()
        while True:
            resp = await self._do_request_async(client=client, chunk=chunk)
            data = self._extract_content(resp)
            if not self._is_empty_payload(data):
                return data

            elapsed = time.monotonic() - start
            if elapsed >= self.poll_timeout_sec:
                self.context.logger.warning(f"Polling timeout reached (no data) | chunk={chunk}")
                return data

            self.context.logger.info(f"No data yet - retrying in {self.poll_interval_sec}s | chunk={chunk}")
            await asyncio.sleep(self.poll_interval_sec)

    async def _do_request_async(self, client: httpx.AsyncClient, *, chunk: dict[str, Any] | None) -> HttpResponse:
        self._ensure_valid_token()
        verb = self.http_method.upper()

        @self.retry  # type: ignore[misc]
        async def _call() -> httpx.Response:
            api_params = self.build_params(chunk=chunk)
            self.context.logger.debug(f"Requesting {self.endpoint_url} with params: {api_params}")
            if verb == "GET":
                resp = await client.get(
                    self.endpoint_url, headers=self.headers, params=api_params, timeout=self.timeout_sec
                )
            elif verb == "POST":
                resp = await client.post(self.endpoint_url, headers=self.headers, json=api_params)
            else:
                raise ValueError(f"Unsupported http_method={self.http_method!r}")
            if self.is_http_status_success(resp.status_code):
                # we don't raise an error here, but return the response
                return resp

            resp.raise_for_status()
            return resp

        return cast(HttpResponse, await _call())

    def is_http_status_success(self, status_code: int) -> bool:
        """Check if the HTTP status code indicates success."""
        return 200 <= status_code < 300

    async def _process_async(self, client: httpx.AsyncClient, *, chunk: Any) -> None:
        if self.poll_on_empty:
            raw = await self._poll_until_data_async(client=client, chunk=chunk)
        else:
            raw = self._extract_content(await self._do_request_async(client=client, chunk=chunk))

        record = self.handle_response(raw, chunk=chunk)
        self._save(record, chunk=chunk)

    async def _run(self) -> None:
        chunks = self.build_param_chunks()
        if self._session is None:
            self._session = self._create_session()
        client = self._session
        sem = asyncio.Semaphore(self.max_workers)
        self.context.logger.info(f"Async processing {len(chunks)} chunks with max_workers={self.max_workers}")

        async def worker(it: Any) -> None:
            async with sem:
                try:
                    await self._process_async(client, chunk=it)
                except Exception as exc:
                    self.context.logger.warning(f"chunk {it} failed: {exc}")
                    self._failed_chunks.append(it)
                    raise exc

        await asyncio.gather(*(worker(it) for it in chunks), return_exceptions=True)

        self.context.logger.info(f"Async finished | attempted={len(chunks)} failed={len(self._failed_chunks)}")
        if self.raise_exception and self._failed_chunks:
            raise ValueError(f"Some chunks failed during processing: {self._failed_chunks}")

    def execute(self) -> None | list[Any] | Any:
        """Run the HTTP reader and return the collected responses.

        (or None when file_volume is set).

        Returns:
            None | list[Any] | Any: Check parents docstring for details.
        """
        coro = self._run()  # the real async work

        _run_coroutine_blocking(coro)
        return self._collected_responses if self.file_volume is None else None
